# TODO: issues/101.md Ecosystem Cleanup

## Tasklist 1: Provider and Text Foundations

- [ ] Implement `twat_genai` plan from `issues/103-twat_genai.md`: shared provider models, Chutes engines, OpenAI image, Gemini/Nano Banana, Fal preservation, tests, docs.
- [ ] Implement `twat_llm` plan from `issues/103-twat_llm.md`: text-heavy LLM boundary, stable adapter for `twat_text`, tests, docs.
- [ ] Implement `twat_text` plan from `issues/103-twat_text.md`: deterministic text utilities plus mocked `twat_llm` powered operations, CLI, tests, docs.
- [ ] Confirm reference scripts `imgquotio.py` and `imgnanobanatrans.py` are represented through `twat_genai` APIs rather than duplicated in domain packages.
- [ ] Run package-level tests/lint/type-check for `twat_genai`, `twat_llm`, and `twat_text`.

## Tasklist 2: Media Domain Packages

- [ ] Implement `twat_image` plan from `issues/103-twat_image.md`: fix package layout, deterministic image utilities, `twat_genai` wrappers, tests, docs.
- [ ] Implement `twat_video` plan from `issues/103-twat_video.md`: replace font-organizer package with real video package, ffmpeg boundary, reusable video operations, `twat_genai` wrappers, tests, docs.
- [ ] Implement `twat_audio` plan from `issues/103-twat_audio.md`: preserve resampling, add deterministic audio helpers, coordinate speech split, tests, docs.
- [ ] Implement `twat_speech` plan from `issues/103-twat_speech.md`: transcription/subtitle/TTS/dubbing orchestration with `twat_genai` and `twat_audio`, tests, docs.
- [ ] Document which `reference/bin-img-vid` scripts remain one-offs and why.
- [ ] Run package-level tests/lint/type-check for `twat_image`, `twat_video`, `twat_audio`, and `twat_speech`.

## Tasklist 3: Complex Support Packages

- [ ] Implement `twat_font` plan from `issues/103-twat_font.md`: canonicalize font organizer and preserve unique `twat_video` font behavior before video replacement.
- [ ] Implement `twat_fs` plan from `issues/103-twat_fs.md`: normalize plugin contract/docs/tests without breaking provider API.
- [ ] Implement `twat_search` plan from `issues/103-twat_search.md`: normalize plugin contract/docs/tests and document embedded scraper boundary.
- [ ] Implement `twat_coding` plan from `issues/103-twat_coding.md`: normalize plugin contract/docs/tests while preserving pystubnik CLI.
- [ ] Run package-level tests/lint/type-check for `twat_font`, `twat_fs`, `twat_search`, and `twat_coding`.

## Tasklist 4: Host and Lightweight Packages

- [ ] Implement host plan from `issues/103-host.md`: `twat --list`, `twat --help`, tests, README.
- [ ] Implement `twat_os` plan from `issues/103-twat_os.md`: keep as reference package and verify docs/tests.
- [ ] Implement `twat_mp` plan from `issues/103-twat_mp.md`: normalize docs/tests/exports.
- [ ] Implement `twat_ez` plan from `issues/103-twat_ez.md`: normalize docs/tests/exports.
- [ ] Implement `twat_hatch` plan from `issues/103-twat_hatch.md`: normalize docs/tests/exports.
- [ ] Implement `twat_task` plan from `issues/103-twat_task.md`: normalize docs/tests/exports.
- [ ] Implement `twat_labs` plan from `issues/103-twat_labs.md`: document experimental scope and verify plugin contract.
- [ ] Run root host tests and package-level tests/lint/type-check for these packages.

## Tasklist 5: Consolidation and QA

- [ ] Review all changed `pyproject.toml` files for package/import/entry-point consistency against `issues/102-current.md`.
- [ ] Install host and cleaned plugins in editable mode in a fresh environment or documented equivalent.
- [ ] Run `twat --help`, `twat --list`, and `twat <entry> --help` for every plugin entry point.
- [ ] Run package test suites for all plugin repos and root host tests.
- [ ] Run lint/type-check commands per package, documenting any pre-existing unrelated failures.
- [ ] Review README files for boundary consistency: `twat_llm` text-heavy LLM, `twat_genai` generative media providers, domain packages as user-facing surfaces.
- [ ] Verify no reusable code remains only in `reference/bin-img-vid` without a planned/package home; document one-offs left in reference.
- [ ] Produce final consolidation report with changed packages, verification commands, failures, and follow-up issues.
