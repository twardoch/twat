# Changelog

All notable changes to the `twat` project are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project uses [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.7.6] - 2025-02-15

### Changed

- Updated dependencies in `pyproject.toml`
- Improved README.md documentation
- Refined package configuration

## [1.7.5] - 2025-02-15

### Added

- README.md documentation improvements
- Enhanced package initialization

### Changed

- Refactored `src/twat/__init__.py`
- Updated path handling in `src/twat/paths.py`
- Adjusted package dependencies

## [1.7.0] - 2025-02-13

### Added

- New .gitignore patterns

### Changed

- Restructured project layout
- Streamlined development workflow

## [1.6.2] - 2025-02-06

### Added

- Extended `pyproject.toml` configuration
- Added package metadata
- Improved dependency definitions

## [1.6.1] - 2025-02-06

### Changed

- Refactored initialization code in `src/__init__.py` and `src/twat/__init__.py`
- Improved path resolution in `src/twat/paths.py`
- Expanded test coverage

### Fixed

- Path resolution errors
- Initialization bugs

## [1.6.0] - 2025-02-06

### Added

- GitHub repository setup
- Plugin system implementation
- PEP 621-compliant packaging

### Changed

- Updated documentation
- Refined package structure

## [1.1.0] - 2025-02-03

### Added

- Core functionality in `src/__init__.py`
- Initial test suite in `tests/test_package.py`
- Enhanced `pyproject.toml` configuration

### Changed

- Improved .gitignore settings
- Updated README with additional details

## [1.0.1] - 2025-02-03

### Fixed

- `pyproject.toml` configuration issues
- Repository ignore patterns

## [1.0.0] - 2025-02-03

### Added

- Initial release
- Basic package structure
- Core module
- Package initialization logic
- Version management

[1.7.6]: https://github.com/twardoch/twat/compare/v1.7.5...v1.7.6  
[1.7.5]: https://github.com/twardoch/twat/compare/v1.7.0...v1.7.5  
[1.7.0]: https://github.com/twardoch/twat/compare/v1.6.2...v1.7.0  
[1.6.2]: https://github.com/twardoch/twat/compare/v1.6.1...v1.6.2  
[1.6.1]: https://github.com/twardoch/twat/compare/v1.6.0...v1.6.1  
[1.6.0]: https://github.com/twardoch/twat/compare/v1.1.0...v1.6.0  
[1.1.0]: https://github.com/twardoch/twat/compare/v1.0.1...v1.1.0  
[1.0.1]: https://github.com/twardoch/twat/compare/v1.0.0...v1.0.1  
[1.0.0]: https://github.com/twardoch/twat/releases/tag/v1.0.0