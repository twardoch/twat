#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["av", "ffmpeg-python", "fire", "rich"]
# ///
# this_file: vidmergebygap1.py

### THIS CODE RUNS

import asyncio
import concurrent.futures
from pathlib import Path

import av
import ffmpeg
import fire
from rich.console import Console
from rich.progress import Progress

console = Console()


def probe_video(video_path):
    try:
        probe = ffmpeg.probe(video_path)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )
        audio_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "audio"),
            None,
        )

        return {
            "width": int(video_stream["width"]),
            "height": int(video_stream["height"]),
            "video_codec": video_stream["codec_name"],
            "audio_codec": audio_stream["codec_name"] if audio_stream else None,
            "pix_fmt": video_stream["pix_fmt"],
            "sample_rate": int(audio_stream["sample_rate"]) if audio_stream else None,
            "duration": float(probe["format"]["duration"]),
        }
    except ffmpeg.Error as e:
        console.print(
            f"[bold red]Error probing video {video_path}:[/bold red] {e.stderr.decode()}"
        )
        raise


def generate_silent_video(duration, color, video_info, output_path):
    print(">>>>", video_info)
    silent_video = ffmpeg.input(
        f"color=c={color}:s={video_info['width']}x{video_info['height']}:d={duration}",
        f="lavfi",
    )
    silent_audio = ffmpeg.input(
        f"anullsrc=channel_layout=stereo:sample_rate={video_info['sample_rate']}:d={duration}",
        f="lavfi",
    )
    (
        ffmpeg.output(
            silent_video,
            silent_audio,
            output_path,
            vcodec=video_info["video_codec"],
            acodec=video_info["audio_codec"],
            t=duration,
            pix_fmt=video_info["pix_fmt"],
        )
        .overwrite_output()
        .run(capture_stdout=True, capture_stderr=True)
    )


async def extract_frame(video_path, position, output_path):
    container = av.open(str(video_path))
    stream = container.streams.video[0]

    if position == -1:
        position = float(stream.duration * stream.time_base) - 0.1

    container.seek(int(position / float(stream.time_base)))
    for frame in container.decode(video=0):
        frame.to_image().save(output_path)
        break

    container.close()


async def create_intro_outro(frame_path, duration, video_info, output_path):
    frame_input = ffmpeg.input(frame_path, loop=1, t=duration)
    silent_audio = ffmpeg.input(
        f"anullsrc=channel_layout=stereo:sample_rate={video_info['sample_rate']}:d={duration}",
        f="lavfi",
    )
    output = ffmpeg.output(
        frame_input,
        silent_audio,
        str(output_path),  # Convert output_path to string
        vcodec=video_info["video_codec"],
        acodec=video_info["audio_codec"],
        t=duration,
        pix_fmt=video_info["pix_fmt"],
    )
    output = output.overwrite_output()
    await asyncio.to_thread(output.run, capture_stdout=True, capture_stderr=True)


async def process_video(
    video_path,
    intro_duration,
    gap_duration,
    color,
    video_info,
    temp_dir,
    progress,
    task,
):
    base_name = Path(video_path).stem
    output_path = temp_dir / f"{base_name}-merged.mp4"

    gap_video = temp_dir / "gap.mp4"
    if not gap_video.exists():
        await asyncio.to_thread(
            generate_silent_video, gap_duration, color, video_info, str(gap_video)
        )

    intro_frame = temp_dir / f"{base_name}-intro.png"
    outro_frame = temp_dir / f"{base_name}-outro.png"

    await asyncio.gather(
        extract_frame(video_path, 0, intro_frame),
        extract_frame(video_path, -1, outro_frame),
    )

    intro_video = temp_dir / f"{base_name}-intro.mp4"
    outro_video = temp_dir / f"{base_name}-outro.mp4"

    await asyncio.gather(
        create_intro_outro(intro_frame, intro_duration, video_info, intro_video),
        create_intro_outro(outro_frame, intro_duration, video_info, outro_video),
    )

    # Concatenate gap, intro, original video, outro, and gap
    gap_input = ffmpeg.input(str(gap_video))
    intro_input = ffmpeg.input(str(intro_video))
    video_input = ffmpeg.input(str(video_path))
    outro_input = ffmpeg.input(str(outro_video))

    (
        ffmpeg.concat(
            gap_input.video,
            gap_input.audio,
            intro_input.video,
            intro_input.audio,
            video_input.video,
            video_input.audio,
            outro_input.video,
            outro_input.audio,
            gap_input.video,
            gap_input.audio,
            v=1,
            a=1,
        )
        .output(
            str(output_path),
            vcodec=video_info["video_codec"],
            acodec=video_info["audio_codec"],
            pix_fmt=video_info["pix_fmt"],
        )
        .overwrite_output()
        .run(capture_stdout=True, capture_stderr=True)
    )

    progress.update(task, advance=1)
    return output_path


async def merge_videos(
    input_dir: str,
    output: str,
    intro: float = 2.0,
    gap: float = 2.0,
    color: str = "000000",
):
    console.print("[bold green]Starting video merge process[/bold green]")
    console.print(f"Input directory: {input_dir}")
    console.print(f"Output file: {output}")
    console.print(f"Intro duration: {intro} seconds")
    console.print(f"Gap duration: {gap} seconds")
    console.print(f"Gap color: #{color}")

    input_path = Path(input_dir)
    output_path = Path(output)

    if not input_path.is_dir():
        console.print(
            f"[bold red]Error:[/bold red] The input directory {input_dir} does not exist."
        )
        return

    video_files = sorted(input_path.glob("*.mp4"))
    if not video_files:
        console.print(
            f"[bold red]Error:[/bold red] No MP4 files found in the directory {input_dir}."
        )
        return

    console.print(
        f"[bold green]Found {len(video_files)} MP4 files in {input_dir}.[/bold green]"
    )

    # Probe the first video
    video_info = await asyncio.to_thread(probe_video, str(video_files[0]))

    # Create temp directory in the same folder as the output file
    temp_dir = output_path.with_suffix(".tmp")
    temp_dir.mkdir(exist_ok=True)

    with Progress() as progress:
        task = progress.add_task("[cyan]Processing videos...", total=len(video_files))

        # Process videos in parallel
        with concurrent.futures.ThreadPoolExecutor():
            futures = [
                asyncio.ensure_future(
                    process_video(
                        str(video_file),
                        intro,
                        gap,
                        color,
                        video_info,
                        temp_dir,
                        progress,
                        task,
                    )
                )
                for video_file in video_files
            ]
            processed_videos = await asyncio.gather(*futures)

    # Concatenate all processed videos
    console.print("[yellow]Concatenating final video...[/yellow]")
    try:
        inputs = []
        for video in processed_videos:
            input_file = ffmpeg.input(str(video))
            inputs.extend([input_file["v"], input_file["a"]])

        (
            ffmpeg.concat(*inputs, v=1, a=1)
            .output(
                str(output_path),
                vcodec=video_info["video_codec"],
                acodec=video_info["audio_codec"],
                pix_fmt=video_info["pix_fmt"],
            )
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
    except ffmpeg.Error as e:
        console.print("[bold red]Error during final video concatenation:[/bold red]")
        console.print(f"[red]STDOUT:[/red]\n{e.stdout.decode()}")
        console.print(f"[red]STDERR:[/red]\n{e.stderr.decode()}")
        raise

    console.print("[bold green]Video merge completed successfully![/bold green]")
    console.print(f"[bold green]Output video saved to {output}[/bold green]")
    console.print(
        f"[bold yellow]Temporary files are kept in the '{temp_dir}' folder for inspection.[/bold yellow]"
    )


def run_merge_videos(
    input_dir: str,
    output: str,
    intro: float = 2.0,
    gap: float = 2.0,
    color: str = "000000",
):
    asyncio.run(merge_videos(input_dir, output, intro, gap, color))


if __name__ == "__main__":
    fire.Fire(run_merge_videos)
