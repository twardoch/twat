# TODO

## Phase 2 - Future Improvements
- [x] Add --help examples to scripts lacking documentation (Session 9 - all scripts done)
- [x] Consider consolidating duplicate scripts (vidcrop1/2, vidmergebygap1)
  - vidcrop1.py = original simple version, vidcrop2.py = intermediate, vidcrop.py = current optimized
  - vidmergebygap1.py = simpler version ("THIS CODE RUNS"), vidmergebygap.py = enhanced with thumbnails
  - Fixed incorrect this_file markers in vidcrop1.py and vidcrop2.py
  - Decision: Keep as evolution snapshots; main scripts (vidcrop.py, vidmergebygap.py) are active versions
- [ ] Add integration tests for critical scripts
- [x] Delete "vidsqueeze copy.py" (macOS Finder copy artifact, older than vidsqueeze.py)
