#!/usr/bin/env -S uv run -s
# /// script
# requires-python = ">=3.11"
# dependencies = ["ffmpeg-python", "opencv-python", "numpy", "send2trash", "fire", "pyyaml", "loguru", "pymediainfo", "rich"]
# ///
# this_file: vidsqueeze.py
"""
VidSqueeze: Efficient Video File Optimizer
=========================================

this_file: vidsqueeze.py

VidSqueeze is a command-line tool and Python script for optimizing video files by reducing their file size while maintaining perceptual quality. It is designed for batch or single-file processing, supporting a variety of video formats and codecs. The script is robust, safe, and highly configurable, making it suitable for both end-users and developers.

Purpose & Functionality
-----------------------
- **Primary Goal:** Reduce video file sizes by re-encoding with modern codecs and optimal settings, while ensuring the output is visually indistinguishable from the original.
- **Quality Assurance:** Uses frame count and frame content comparison (Mean Squared Error, MSE) to verify that the optimized video is visually equivalent to the original.
- **Safety:** Original files are never deleted unless explicitly requested. By default, originals are moved to trash or kept as backups.
- **Batch Processing:** Can process entire directories recursively, or single files.
- **Configurable:** Supports YAML config files and CLI overrides for codec, CRF, presets, minimum size reduction, and more.
- **Logging:** Uses rich, colorized logging and progress bars for clear feedback. Verbose mode provides detailed debug output.

Main Features
-------------
- Supports modern codecs: h265 (HEVC), h264 (AVC), AV1
- Customizable CRF (quality), preset (speed/quality tradeoff), and audio codec
- Skips files that are already optimal or too small
- Keeps or trashes originals based on user flags
- Optionally saves comparison frames and failed optimizations for inspection
- Handles errors gracefully, with clear user guidance and robust file operations
- Modular, extensible design for easy maintenance and enhancement
- Configurable MSE threshold for frame comparison to balance quality validation with codec-specific differences

Usage
-----
Run from the command line:

    python -m vidsqueeze [OPTIONS] <input_path>
    # or, if installed as a script:
    vidsqueeze [OPTIONS] <input_path>

Where `<input_path>` is a video file or directory containing videos.

Key CLI Options (see --help for full list):
- `--safe`: Move original files to trash after optimization (default: False)
- `--keep_original`: Keep original files with '--before-squeeze' suffix (overrides --safe)
- `--keep_optimized`: Keep failed optimized files with '--after-squeeze' suffix
- `--keep_frames`: Save extracted comparison frames for manual inspection
- `--codec`: Target codec ('h264', 'h265', 'av1')
- `--crf`: Constant Rate Factor (quality setting)
- `--preset`: Codec preset (speed/quality tradeoff)
- `--min_size_reduction`: Minimum fractional size reduction required (e.g., 0.1 for 10%)
- `--mse_threshold`: Maximum allowed Mean Squared Error for frame comparison (default: 13.0)
- `--config_path`: Path to a YAML config file
- `--verbose`: Enable detailed debug logging
- `--try_all`: Try optimizing even if video already uses the target codec
- `--alt`: Use ffprobe instead of pymediainfo for analysis (slower but may be more compatible)

Design & Logic Overview
-----------------------
- **VideoOptimizer class:** Core logic for finding, analyzing, optimizing, and verifying videos.
- **Frame Comparison:** Extracts and compares frames at the start and end of videos to ensure visual fidelity (MSE threshold configurable).
- **Atomic File Replacement:** Uses safe renaming and trashing to avoid data loss. Attempts to restore originals if replacement fails.
- **Configuration:** Loads defaults, merges with YAML config, and applies CLI overrides.
- **Rich Logging:** Uses the `rich` library for progress bars, panels, and colorized logs.

Dependencies
------------
- ffmpeg-python
- opencv-python
- numpy
- send2trash
- fire
- rich
- pyyaml
- loguru
- pymediainfo (for faster metadata extraction)

See the `# dependencies` section at the top of this file for the full list.

Edge Cases & Safety
-------------------
- Skips files that are too small or already optimal
- Handles missing or corrupt files gracefully
- Cleans up temporary files and directories
- Provides clear error messages and logs for troubleshooting
- Optionally keeps failed outputs and comparison frames for manual review

Where/How Used
--------------
- Intended for use as a CLI tool, but can be imported as a module
- Main entry point is the `vidsqueeze` function (see bottom of file)
- Designed for personal, archival, or batch video optimization workflows

For more details, see the README.md and in-code docstrings.
"""

import logging
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, TypedDict

import cv2  # For frame comparison  # type: ignore[import]
import ffmpeg  # type: ignore[import]
import fire  # type: ignore[import]
import numpy as np  # For frame comparison calculations
import yaml
from loguru import logger  # Add loguru
from pymediainfo import MediaInfo  # For faster metadata extraction

# Removed MediaInfo.close_library registration - method no longer exists in current pymediainfo API

from send2trash import send2trash  # type: ignore[import]

# --- Constants ---
RENAME_SUFFIX = "--before-squeeze"
MIN_FILE_SIZE_MB = 1  # Minimum file size in MB to consider for optimization
BYTES_PER_MB = 1024 * 1024
DEFAULT_AUDIO_CODEC = "copy"
DEFAULT_MOV_FLAGS = "+faststart"
METADATA_MAP = "0"  # Copy global metadata from input 0
FFMPEG_LOG_LEVEL_VERBOSE = "verbose"
FFMPEG_LOG_LEVEL_NORMAL = "error"
FFMPEG_OVERWRITE_OUTPUT = "-y"
# VMAF/SSIM keys removed
CODEC_NAME_KEY = "codec_name"
WIDTH_KEY = "width"
HEIGHT_KEY = "height"
DURATION_KEY = "duration"
BIT_RATE_KEY = "bit_rate"
AVG_FRAME_RATE_KEY = "avg_frame_rate"
NB_FRAMES_KEY = "nb_frames"  # Key for frame count
FORMAT_KEY = "format"
STREAMS_KEY = "streams"
CODEC_TYPE_KEY = "codec_type"
VIDEO_CODEC_TYPE = "video"

# Frame comparison constants
FRAME_COMPARISON_COUNT = 3  # Number of frames to compare at start and end
FRAME_END_OFFSET = 3  # How many frames from the very end to offset the end comparison
FRAME_MSE_THRESHOLD = (
    13.0  # Maximum allowed Mean Squared Error between frames (lower is stricter)
)

# Codec mapping for comparison and selection
CODEC_LIBS = {
    "h265": "libx265",
    "h264": "libx264",
    "av1": "libsvtav1",
}
CODEC_NAMES = {v: k for k, v in CODEC_LIBS.items()}  # Reverse mapping: lib -> name

# Codecs considered less efficient than others (for _should_optimize logic)
CODEC_HIERARCHY = {
    "h265": ["h264", "mpeg4", "vp8", "vp9", "mpeg2video"],
    "av1": ["h264", "h265", "vp9", "mpeg4", "mpeg2video"],
    "h264": ["mpeg2video", "mpeg4"],
}


# --- Type Definitions for Configuration ---
class CodecSettings(TypedDict):
    lib: str
    crf: int
    preset: str | int  # String for h264/h265, int for AV1


class OptimizationHeuristics(TypedDict, total=False):
    min_size_reduction_percent: float
    min_file_size_mb: int
    high_bitrate_threshold_mbps: float
    frame_count_tolerance: int
    frame_comparison_mse_threshold: float
    skip_first_frame_comparison: bool
    flexible_frame_matching: bool
    min_size_reduction_fraction: float | None  # Added during init


class VidSqueezeConfig(TypedDict, total=False):
    video_extensions: list[str]
    codec_settings: dict[str, CodecSettings]
    default_codec: str
    audio_codec: str
    optimization_heuristics: OptimizationHeuristics


# Default configuration (can be overridden by file or CLI args)
DEFAULT_CONFIG = {
    "video_extensions": [".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".wmv"],
    "codec_settings": {
        "h265": {
            "lib": CODEC_LIBS["h265"],
            "crf": 22,  # Default changed from 28 for higher quality
            "preset": "slow",  # Default changed from medium for better compression
        },
        "h264": {
            "lib": CODEC_LIBS["h264"],
            "crf": 22,  # Keep this standard high-quality default
            "preset": "slow",
        },
        "av1": {
            "lib": CODEC_LIBS["av1"],
            "crf": 30,  # Keep AV1 default for now
            "preset": "8",  # AV1 uses numerical presets
        },
    },
    "default_codec": "h265",
    "audio_codec": DEFAULT_AUDIO_CODEC,
    # Quality thresholds removed, replaced by frame comparison logic
    "optimization_heuristics": {
        "min_size_reduction_percent": 10.0,
        "min_file_size_mb": MIN_FILE_SIZE_MB,
        "high_bitrate_threshold_mbps": 10.0,  # Threshold to re-encode same codec
        "frame_count_tolerance": 2,  # Allowable difference in frame counts
        "frame_comparison_mse_threshold": FRAME_MSE_THRESHOLD,  # MSE threshold for frame diff
        "skip_first_frame_comparison": True,  # Skip first frame comparison if other frames match
        "flexible_frame_matching": True,  # Enable comparing 1st/2nd frames flexibly
    },
}

# --- Helper Functions ---


def _merge_config(base: dict[str, Any], override: dict[str, Any]) -> None:
    """
    Recursively merge override dictionary into base dictionary.
    Modifies the 'base' dictionary in place.

    Args:
        base: The dictionary to merge into.
        override: The dictionary providing overriding values.
    """
    for key, value in override.items():
        if isinstance(value, dict) and key in base and isinstance(base[key], dict):
            _merge_config(base[key], value)
        else:
            base[key] = value


def format_size(size_bytes: int) -> str:
    """Convert bytes to a human-readable string (KB, MB, GB)."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < BYTES_PER_MB:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < BYTES_PER_MB * 1024:
        return f"{size_bytes / BYTES_PER_MB:.2f} MB"
    else:
        return f"{size_bytes / (BYTES_PER_MB * 1024):.2f} GB"


def calculate_mse(image_a: np.ndarray, image_b: np.ndarray) -> float:
    """
    Calculates the Mean Squared Error (MSE) between two images.
    Lower MSE indicates higher similarity.

    Args:
        image_a: First image (NumPy array).
        image_b: Second image (NumPy array).

    Returns:
        The MSE value as a float. Returns infinity if images have different shapes.
    """
    if image_a.shape != image_b.shape:
        # No filename context here easily, keep generic
        logger.warning(
            f"Cannot calculate MSE: Images have different shapes {image_a.shape} vs {image_b.shape}"
        )
        return float("inf")  # Indicate incompatibility

    err = np.sum((image_a.astype("float") - image_b.astype("float")) ** 2)
    err /= float(
        image_a.shape[0] * image_a.shape[1] * image_a.shape[2]
    )  # Normalize by number of pixels and channels
    return err


# --- Core Class ---


class VideoOptimizer:
    """
    Optimizes videos by reducing file size while maintaining perceptual quality
    using frame count consistency and sample frame comparison.

    Handles finding, analyzing, transcoding, quality-checking, and replacing
    video files based on configuration and specified thresholds.
    """

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        codec: str | None = None,
        crf: int | None = None,
        preset: str | None = None,
        min_size_reduction: float
        | None = None,  # Input as fraction (e.g., 0.1 for 10%)
        safe: bool = False,
        keep_original: bool = False,
        verbose: bool = False,
        try_all: bool = False,
        keep_optimized: bool = False,
        keep_frames: bool = False,  # New flag for keeping frames
        mse_threshold: float | None = None,  # New parameter for MSE threshold
        force_mp4: bool = False,  # New parameter to force MP4 container
        alt: bool = False,  # Use ffprobe instead of pymediainfo for analysis
    ):
        self.verbose = verbose  # Store verbose state
        logger.remove()  # type: ignore # Suppress linter error due to missing loguru stubs
        if self.verbose:
            logger.add(  # type: ignore # Suppress linter error
                sys.stderr,
                level="DEBUG",
                format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
            )
            logger.info("Verbose logging enabled.")
        else:
            logger.add(sys.stderr, level="INFO", format="<level>{message}</level>")  # type: ignore # Suppress linter error

        self.config: VidSqueezeConfig = (
            DEFAULT_CONFIG.copy() if config is None else config
        )

        self.safe = keep_original or safe
        self.keep_original = keep_original
        # self.verbose already set
        self.try_all = try_all
        self.keep_optimized = keep_optimized
        self.keep_frames = keep_frames
        self.force_mp4 = force_mp4
        self.alt = alt  # Store whether to use alternative (ffprobe) analysis

        # self.loglevel for ffmpeg is still based on self.verbose, which is fine.
        self.loglevel = (
            FFMPEG_LOG_LEVEL_VERBOSE if self.verbose else FFMPEG_LOG_LEVEL_NORMAL
        )

        # Old RichHandler configuration loops are removed.

        # Determine target codec settings
        codec_key = codec or self.config.get("default_codec", "h265")
        if codec_key not in self.config.get("codec_settings", {}):
            logger.critical(
                f"Unsupported codec specified or found in config: {codec_key}"
            )
            sys.exit(1)
        self.codec_key = codec_key
        # Make a copy to avoid modifying the original config dict
        self.codec_info = self.config["codec_settings"][codec_key].copy()  # type: ignore[index]

        # Apply specific overrides for codec settings
        if crf is not None:
            self.codec_info["crf"] = crf
        if preset is not None:
            self.codec_info["preset"] = preset

        # Quality thresholds removed

        # Apply optimization heuristic overrides
        # Make a copy to avoid modifying the original config dict
        self.optimization = self.config.get("optimization_heuristics", {}).copy()  # type: ignore[union-attr]
        if min_size_reduction is not None:
            # Store the fractional value directly
            self.optimization["min_size_reduction_fraction"] = min_size_reduction
        else:
            # Calculate fraction from percentage if not overridden
            self.optimization["min_size_reduction_fraction"] = (
                self.optimization.get("min_size_reduction_percent", 10.0) / 100.0
            )
        # Ensure frame comparison threshold is present, using constant if needed
        if "frame_comparison_mse_threshold" not in self.optimization:
            self.optimization["frame_comparison_mse_threshold"] = FRAME_MSE_THRESHOLD

        # Apply MSE threshold override if provided
        if mse_threshold is not None:
            self.optimization["frame_comparison_mse_threshold"] = mse_threshold

        # Video extensions to search for
        self.video_extensions = self.config.get("video_extensions", [])

        # Results tracking
        self.results: dict[str, list[str]] = {
            "optimized": [],
            "skipped": [],
            "failed": [],
        }

        # --- Sanity Checks ---
        self._check_ffmpeg_availability()  # Critical check, exits if failed

        logger.debug("Optimizer Initialized:")
        logger.debug(
            f"  Target Codec: {self.codec_key} (lib: {self.codec_info['lib']}, CRF: {self.codec_info['crf']}, Preset: {self.codec_info['preset']})"
        )
        # Quality threshold log removed
        logger.debug(
            f"  Frame Comparison MSE Threshold: {self.optimization['frame_comparison_mse_threshold']:.1f} (higher = more permissive)"
        )
        logger.debug(
            f"  Min Size Reduction: {self.optimization['min_size_reduction_fraction']:.1%}"
        )
        logger.debug(
            f"  Keep Original: {self.keep_original}, Safe Mode (Trash): {self.safe}"
        )
        logger.debug(f"  Try All Codecs: {self.try_all}")
        logger.debug(f"  Keep Optimized (on fail): {self.keep_optimized}")
        logger.debug(f"  Keep Frames (on fail): {self.keep_frames}")  # Log new flag
        logger.debug(f"  Force MP4 Container: {self.force_mp4}")  # Log new flag
        logger.debug(
            f"  Use Alternative Analysis (ffprobe): {self.alt}"
        )  # Log new flag
        logger.debug(f"  Verbose Logging: {self.verbose}")
        logger.debug(f"  Video Extensions: {', '.join(self.video_extensions)}")

    def _check_ffmpeg_availability(self) -> None:
        """
        Check if FFmpeg executable is available and ffmpeg-python library can interact.
        Exits the script if checks fail.
        """
        # 1. Check if ffmpeg executable is in PATH
        ffmpeg_path = shutil.which("ffmpeg")
        if not ffmpeg_path:
            logger.critical(
                "FFmpeg executable not found in system PATH. "
                "Please install FFmpeg (https://ffmpeg.org/download.html) "
                "and ensure its directory is included in your PATH environment variable."
            )
            sys.exit(1)
        else:
            logger.debug(f"Found FFmpeg executable at: {ffmpeg_path}")

        # 2. Check if ffmpeg-python library can run ffprobe (basic interaction test)
        try:
            # Use subprocess to run ffmpeg -version as a simple command that should succeed if ffmpeg works
            subprocess.run(
                [ffmpeg_path, "-version"],
                capture_output=True,
                check=True,  # Will raise CalledProcessError on non-zero exit
                text=True,  # Decode stdout/stderr as text
                errors="ignore",  # Ignore decoding errors
            )
            # No need to check returncode explicitly if check=True
            logger.debug(
                "ffmpeg-python library interaction successful (ran ffmpeg -version)."
            )

        except subprocess.CalledProcessError as e:
            # Error during the subprocess call itself
            stderr_str = e.stderr.strip()
            logger.critical(
                f"FFmpeg executable failed to execute '-version'. Error: {stderr_str}"
            )
            sys.exit(1)
        except FileNotFoundError:
            # Should be caught by shutil.which, but handle defensively
            logger.critical(
                "FFmpeg executable check inconsistency. FileNotFoundError during interaction."
            )
            sys.exit(1)
        except Exception as e:
            # Catch unexpected errors during the check
            logger.critical(
                f"Unexpected error checking FFmpeg library interaction: {e}",
                exc_info=self.verbose,
            )
            sys.exit(1)

    def optimize(self, input_path: str | Path) -> dict[str, list[str]]:
        self.results = {"optimized": [], "skipped": [], "failed": []}
        input_path = Path(input_path)

        if not input_path.exists():
            logger.error(f"Input path does not exist: {input_path}")
            return self.results

        videos = self._find_videos(input_path)

        if not videos:
            logger.info(f"No videos found matching extensions in {input_path}")
            return self.results

        logger.info(f"Found {len(videos)} video file(s) to process.")

        total_videos = len(videos)
        for i, video_path in enumerate(videos):
            logger.info(f"Processing video {i + 1}/{total_videos}: {video_path.name}")
            success, status_or_error = self._process_single_video(video_path)

            if success:
                self.results["optimized"].append(str(video_path.name))
            elif status_or_error == "skipped":
                self.results["skipped"].append(str(video_path.name))
            else:
                self.results["failed"].append(str(video_path.name))
                logger.warning(
                    f"[{video_path.name}] Failed processing: {status_or_error}. See logs above for details."
                )
        self._print_summary()
        return self.results

    def _find_videos(self, path: Path) -> list[Path]:
        videos = []
        if path.is_file():
            if path.suffix.lower() in self.video_extensions:
                videos.append(path)
            else:
                logger.warning(
                    f"Input file {path.name} does not have a recognized video extension ({path.suffix}). Skipping."
                )
        elif path.is_dir():
            logger.debug(f"Searching for videos in directory: {path}")
            found_files = set()
            for ext in self.video_extensions:
                for item in path.rglob("*"):
                    if item.is_file() and item.suffix.lower() == ext.lower():
                        if item not in found_files:
                            videos.append(item)
                            found_files.add(item)
            logger.debug(f"Found {len(videos)} potential video files.")
        else:
            logger.error(f"Input path {path} is not a valid file or directory.")
        unique_videos = sorted(list(set(videos)))
        logger.debug(f"Unique video files identified: {len(unique_videos)}")
        return unique_videos

    def _process_single_video(self, video_path: Path) -> tuple[bool, str]:
        filename = video_path.name
        logger.info(f"[{filename}] Processing video.")
        temp_path_obj: Path | None = None
        original_size = 0
        original_info: dict[str, Any] | None = None
        try:
            logger.debug(f"[{filename}] Analyzing eligibility...")
            should_process, reason, original_info, original_size = (
                self._check_eligibility(video_path)
            )
            if not should_process:  # ... (rest of this block is fine)
                logger.info(f"[{filename}] Skipping: {reason}")
                return False, "skipped"
            if not original_info:
                logger.error(
                    f"[{filename}] Internal error: Eligibility check passed but no video info found."
                )
                return False, "failed_analysis"

            suffix = ".mp4" if self.force_mp4 else video_path.suffix or ".mp4"
            try:
                fd, temp_path_str = tempfile.mkstemp(
                    suffix=suffix, prefix=f"vidsqueeze_{filename}_temp_"
                )
                os.close(fd)
                temp_path_obj = Path(temp_path_str)
                logger.debug(
                    f"[{filename}] Using temporary file for processing: {temp_path_obj}"
                )

                logger.debug(f"[{filename}] Compressing video...")
                transcode_success = self._compress_video(video_path, temp_path_obj)
                if not transcode_success:
                    return False, "failed_transcode"

                logger.debug(f"[{filename}] Verifying compressed output...")
                verify_success, verify_reason, compressed_info = (
                    self._verify_transcoding_output(
                        video_path, temp_path_obj, original_info, original_size
                    )
                )
                if not verify_success:  # ... (rest of this block is fine)
                    if verify_reason in ["skipped_size", "skipped_metadata"]:
                        logger.info(
                            f"[{filename}] Skipping after verification: {verify_reason}"
                        )
                        return False, "skipped"
                    else:
                        return False, verify_reason
                if not compressed_info:
                    logger.error(
                        f"[{filename}] Internal error: Verification passed but no compressed info."
                    )
                    return False, "failed_compressed_analysis"

                # Removed progress.update for Quality Check here
                logger.debug(f"[{filename}] Performing quality check...")
                quality_pass, quality_details = self._check_frame_consistency(
                    video_path, temp_path_obj, original_info, compressed_info
                )
                if (
                    not quality_pass
                ):  # ... (logic for keep_optimized etc. is fine, uses logger)
                    if self.keep_optimized and temp_path_obj:
                        if self._save_failed_optimized(video_path, temp_path_obj):
                            temp_path_obj = None
                            return False, "skipped_kept_optimized"
                        else:
                            return False, "failed_save_optimized"
                    else:
                        return False, "skipped"

                # Removed progress.update for Replacing here
                logger.debug(f"[{filename}] Replacing original file...")
                replace_success = self._replace_file(video_path, temp_path_obj)
                if not replace_success:
                    return False, "failed_replace"

                try:
                    compressed_size = video_path.stat().st_size
                except OSError as e_stat:
                    logger.warning(
                        f"[{filename}] Could not stat final file after replacement: {e_stat}"
                    )
                    compressed_size = 0
                size_reduction = (
                    (1.0 - (compressed_size / original_size))
                    if original_size > 0
                    else 0.0
                )
                logger.info(  # Removed Rich [green] tags
                    f"✓ Optimized {filename}: "
                    f"{format_size(original_size)} → {format_size(compressed_size)} "
                    f"({size_reduction:.1%} reduction). "
                    f"Quality check passed ({quality_details})"
                )
                temp_path_obj = None
                return True, "optimized"
            finally:
                if temp_path_obj and temp_path_obj.exists():
                    logger.debug(
                        f"[{filename}] Cleaning up temporary file: {temp_path_obj}"
                    )
                    try:
                        temp_path_obj.unlink()
                    except OSError as e_unlink:
                        logger.warning(
                            f"[{filename}] Could not delete temporary file {temp_path_obj}: {e_unlink}"
                        )
        except Exception as e:
            logger.error(
                f"[{filename}] Unexpected error during processing: {str(e)}",
                exc_info=self.verbose,
            )
            return False, "failed_exception"

    def _check_eligibility(
        self, video_path: Path
    ) -> tuple[bool, str, dict[str, Any] | None, int]:
        """
        Analyze video and decide if optimization should proceed. Checks size and codec.

        Args:
            video_path: Path to the video file.

        Returns:
            Tuple (should_process, reason, analysis_info, file_size)
            - should_process: True if the video should be optimized.
            - reason: Explanation if skipped, or justification if processing.
            - analysis_info: Dictionary with ffprobe results (including frame count), or None on failure.
            - file_size: Size of the video file in bytes. Returns 0 if stat fails.
        """
        filename = video_path.name
        try:
            file_size = video_path.stat().st_size
        except FileNotFoundError:
            return False, "File not found", None, 0
        except OSError as e:
            return False, f"Cannot access file stats: {e}", None, 0

        # Basic size check
        min_size_bytes = (
            self.optimization.get("min_file_size_mb", MIN_FILE_SIZE_MB) * BYTES_PER_MB
        )
        if file_size < min_size_bytes:
            return (
                False,
                f"File too small ({format_size(file_size)} < {format_size(min_size_bytes)})",
                None,
                file_size,
            )

        # Fast analysis for codec and basic properties (without frame counting)
        logger.debug(
            f"[{filename}] Performing fast video analysis for eligibility checks."
        )
        video_info = self._analyze_video_minimal(video_path)
        if not video_info:
            # Error logged in _analyze_video_minimal
            return False, "Failed to analyze video", None, file_size

        # Check codec and decide based on target and 'try_all' flag
        current_codec_lib = video_info.get(
            CODEC_NAME_KEY, "unknown"
        )  # ffprobe often gives lib name
        current_codec_name = CODEC_NAMES.get(
            current_codec_lib, current_codec_lib
        )  # Map lib to common name if possible

        target_codec_lib = self.codec_info["lib"]
        target_codec_name = CODEC_NAMES.get(target_codec_lib, target_codec_lib)

        # --- Optimization Logic ---
        # 1. Already target codec?
        if (
            current_codec_name == target_codec_name
            or current_codec_lib == target_codec_lib
        ):
            display_codec = (
                current_codec_name
                if current_codec_name != current_codec_lib
                else current_codec_lib
            )
            if self.try_all:
                # Check if bitrate is high enough to warrant re-encoding even with same codec
                bitrate_bps_val = video_info.get(BIT_RATE_KEY)
                bitrate_bps = int(bitrate_bps_val) if bitrate_bps_val is not None else 0

                high_bitrate_bps = (
                    self.optimization.get("high_bitrate_threshold_mbps", 10.0)
                    * 1024
                    * 1024
                )
                if bitrate_bps > high_bitrate_bps:
                    reason = f"Target codec ({display_codec}), but bitrate ({bitrate_bps / 1e6:.1f} Mbps) > threshold ({high_bitrate_bps / 1e6:.1f} Mbps) and --try-all set."
                    logger.debug(f"[{filename}] Eligibility: {reason}")
                    return True, reason, video_info, file_size
                else:
                    bitrate_str = (
                        f"{bitrate_bps / 1e6:.1f} Mbps" if bitrate_bps > 0 else "N/A"
                    )
                    reason = f"Already uses target codec ({display_codec}), bitrate ({bitrate_str}) <= threshold and --try-all set. Skipping re-encode."
                    return False, reason, video_info, file_size
            else:  # Not try_all
                return (
                    False,
                    f"Already uses target codec ({display_codec})",
                    video_info,
                    file_size,
                )

        # 2. Is target codec generally better than current codec based on hierarchy?
        better_codecs = CODEC_HIERARCHY.get(target_codec_name, [])
        if current_codec_name in better_codecs:
            reason = f"Current codec ({current_codec_name}) can likely be improved by target ({target_codec_name})"
            logger.debug(f"[{filename}] Eligibility: {reason}")
            return True, reason, video_info, file_size

        # 3. Fallback: If codecs differ and no specific rule matched, try optimizing.
        # This handles cases not explicitly in the hierarchy (e.g., older/rarer codecs).
        reason = (
            f"Attempting optimization from {current_codec_name} to {target_codec_name}"
        )
        logger.debug(f"[{filename}] Eligibility: {reason}")
        return True, reason, video_info, file_size

    def _analyze_video_minimal(self, video_path: Path) -> dict[str, Any] | None:
        """
        Extract minimal video stream information using pymediainfo (fast) or ffprobe (if --alt flag used).
        This is a faster method for initial eligibility checks.

        Args:
            video_path: Path to the video file.

        Returns:
            Dictionary containing key video properties (codec, dimensions, duration etc.),
            but NO frame count. Returns None if analysis fails.
        """
        filename = video_path.name

        # Try MediaInfo first unless --alt flag is set
        if not self.alt:
            mediainfo_result = self._analyze_video_mediainfo(video_path)
            if mediainfo_result:
                return mediainfo_result
            logger.debug(
                f"[{filename}] MediaInfo analysis failed or --alt flag set. Using ffprobe."
            )
        else:
            logger.debug(f"[{filename}] --alt flag set. Using ffprobe for analysis.")

        # Fallback to ffprobe if MediaInfo fails or alt flag is set
        try:
            logger.debug(
                f"[{filename}] Running minimal ffprobe analysis (no frame counting)."
            )

            # Fast probe without count_frames - just basic metadata
            probe = ffmpeg.probe(
                str(video_path),
                select_streams="v:0",  # Select only the first video stream
                show_entries="stream=codec_name,width,height,avg_frame_rate,bit_rate,duration:format=duration,bit_rate",
                loglevel=self.loglevel,  # Keep ffprobe quieter unless error
            )

            format_info = probe.get(FORMAT_KEY, {})
            # Since we selected v:0, streams should contain at most one video stream
            video_stream = next(iter(probe.get(STREAMS_KEY, [])), None)

            if not video_stream:
                logger.warning(
                    f"[{filename}] No video stream found (or stream data missing) during minimal analysis."
                )
                return None

            info = {
                CODEC_NAME_KEY: video_stream.get(CODEC_NAME_KEY),
                WIDTH_KEY: int(video_stream.get(WIDTH_KEY, 0))
                if video_stream.get(WIDTH_KEY) is not None
                else None,
                HEIGHT_KEY: int(video_stream.get(HEIGHT_KEY, 0))
                if video_stream.get(HEIGHT_KEY) is not None
                else None,
                # Duration: Prefer format duration, fallback to stream duration
                DURATION_KEY: None,  # Calculated below
                BIT_RATE_KEY: None,  # Will be calculated/retrieved below
                AVG_FRAME_RATE_KEY: None,  # Will be calculated below
                # NB_FRAMES_KEY not included in minimal analysis
            }

            # --- Get Duration (robustly) ---
            duration_str = format_info.get(DURATION_KEY, video_stream.get(DURATION_KEY))
            try:
                if duration_str:
                    info[DURATION_KEY] = float(duration_str)
                else:
                    info[DURATION_KEY] = 0.0
            except (ValueError, TypeError):
                logger.warning(
                    f"[{filename}] Could not parse duration '{duration_str}'. Setting to 0."
                )
                info[DURATION_KEY] = 0.0

            # --- Calculate Frame Rate (store the calculated float value) ---
            avg_frame_rate_str = video_stream.get(AVG_FRAME_RATE_KEY, "0/1")
            try:
                if "/" in avg_frame_rate_str:
                    num, den = map(int, avg_frame_rate_str.split("/"))
                    if den > 0:
                        info[AVG_FRAME_RATE_KEY] = num / den
                    else:
                        info[AVG_FRAME_RATE_KEY] = None
                elif avg_frame_rate_str and avg_frame_rate_str != "0":
                    # Handle float strings
                    try:
                        info[AVG_FRAME_RATE_KEY] = float(avg_frame_rate_str)
                    except ValueError:
                        info[AVG_FRAME_RATE_KEY] = None
                else:
                    info[AVG_FRAME_RATE_KEY] = None
            except (ValueError, TypeError, ZeroDivisionError):
                logger.warning(
                    f"[{filename}] Could not parse frame rate '{avg_frame_rate_str}'. Skipping."
                )
                info[AVG_FRAME_RATE_KEY] = None  # Ensure it's None on failure

            # --- Determine Bit Rate ---
            stream_bit_rate = video_stream.get(BIT_RATE_KEY)
            format_bit_rate = format_info.get(BIT_RATE_KEY)
            final_bit_rate = None
            if stream_bit_rate and stream_bit_rate.isdigit():
                final_bit_rate = int(stream_bit_rate)
            elif format_bit_rate and format_bit_rate.isdigit():
                final_bit_rate = int(format_bit_rate)

            # If bitrate still unknown, calculate from file size and duration
            if final_bit_rate is None:
                duration = info[DURATION_KEY]
                if duration and duration > 0:
                    try:
                        file_size = video_path.stat().st_size
                        final_bit_rate = int((file_size * 8) / duration)
                        logger.debug(
                            f"[{filename}] Calculated overall bitrate: {final_bit_rate / 1e6:.2f} Mbps"
                        )
                    except OSError:
                        logger.warning(
                            f"[{filename}] Could not get file size to calculate bitrate."
                        )
                else:
                    logger.warning(
                        f"[{filename}] Could not determine bitrate (missing stream/format bitrate and invalid duration)"
                    )
            info[BIT_RATE_KEY] = final_bit_rate

            # Final checks for essential info
            if info[WIDTH_KEY] is None or info[HEIGHT_KEY] is None:
                logger.warning(f"[{filename}] Could not determine video dimensions.")
                # Decide if this is critical? Maybe not, proceed but log.

            logger.debug(f"[{filename}] ffprobe minimal analysis results: {info}")
            return info

        except ffmpeg.Error as e:
            stderr = (
                e.stderr.decode("utf-8", errors="ignore").strip()
                if hasattr(e, "stderr") and e.stderr
                else str(e)
            )
            logger.error(f"[{filename}] Minimal ffprobe analysis failed: {stderr}")
            return None
        except Exception as e:
            logger.error(
                f"[{filename}] Unexpected error during minimal video analysis: {str(e)}",
                exc_info=self.verbose,
            )
            return None

    def _analyze_video(self, video_path: Path) -> dict[str, Any] | None:
        """
        Extract complete video stream information using ffprobe, including frame count.
        This is a more expensive operation that should only be used when frame count is needed.

        Args:
            video_path: Path to the video file.

        Returns:
            Dictionary containing key video properties (codec, dimensions, duration, frame count etc.),
            or None if analysis fails.
        """
        filename = video_path.name
        try:
            logger.debug(
                f"[{filename}] Running complete ffprobe analysis with frame counting."
            )
            # Selectively probe for specific stream and format entries for efficiency
            # Added nb_frames and count_frames to get frame count

            start_time = time.time()
            probe = ffmpeg.probe(
                str(video_path),
                select_streams="v:0",  # Select only the first video stream
                show_entries="stream=codec_name,width,height,avg_frame_rate,bit_rate,duration,nb_frames:format=duration,bit_rate",
                count_frames=None,  # Add count_frames flag to ensure nb_frames is calculated if missing
                loglevel=self.loglevel,  # Keep ffprobe quieter unless error
            )
            elapsed = time.time() - start_time
            logger.debug(f"[{filename}] Frame counting completed in {elapsed:.2f}s")

            format_info = probe.get(FORMAT_KEY, {})
            # Since we selected v:0, streams should contain at most one video stream
            video_stream = next(iter(probe.get(STREAMS_KEY, [])), None)

            if not video_stream:
                logger.warning(
                    f"[{filename}] No video stream found (or stream data missing) during complete analysis."
                )
                return None

            info = {
                CODEC_NAME_KEY: video_stream.get(CODEC_NAME_KEY),
                WIDTH_KEY: int(video_stream.get(WIDTH_KEY, 0))
                if video_stream.get(WIDTH_KEY) is not None
                else None,
                HEIGHT_KEY: int(video_stream.get(HEIGHT_KEY, 0))
                if video_stream.get(HEIGHT_KEY) is not None
                else None,
                # Duration: Prefer format duration, fallback to stream duration
                DURATION_KEY: None,  # Calculated below
                BIT_RATE_KEY: None,  # Will be calculated/retrieved below
                AVG_FRAME_RATE_KEY: None,  # Will be calculated below
                NB_FRAMES_KEY: None,  # Will be retrieved below
            }

            # --- Get Duration (robustly) ---
            duration_str = format_info.get(DURATION_KEY, video_stream.get(DURATION_KEY))
            try:
                if duration_str:
                    info[DURATION_KEY] = float(duration_str)
                else:
                    info[DURATION_KEY] = 0.0
            except (ValueError, TypeError):
                logger.warning(
                    f"[{filename}] Could not parse duration '{duration_str}'. Setting to 0."
                )
                info[DURATION_KEY] = 0.0

            # --- Get Frame Count ---
            # nb_frames might be 'N/A' or missing, especially for some containers/streams
            nb_frames_str = video_stream.get(NB_FRAMES_KEY)
            if nb_frames_str and nb_frames_str.isdigit():
                info[NB_FRAMES_KEY] = int(nb_frames_str)
            else:
                # Fallback: Calculate from duration and frame rate if possible
                duration = info[DURATION_KEY]
                avg_fps = None
                avg_frame_rate_str = video_stream.get(AVG_FRAME_RATE_KEY, "0/1")
                try:
                    if "/" in avg_frame_rate_str:
                        num, den = map(int, avg_frame_rate_str.split("/"))
                        if den > 0:
                            avg_fps = num / den
                    elif avg_frame_rate_str and avg_frame_rate_str != "0":
                        # Handle potential float strings
                        try:
                            avg_fps = float(avg_frame_rate_str)
                        except ValueError:
                            avg_fps = None

                    if duration and duration > 0 and avg_fps and avg_fps > 0:
                        calculated_frames = math.ceil(
                            duration * avg_fps
                        )  # Use ceil to be safe
                        info[NB_FRAMES_KEY] = calculated_frames
                        logger.debug(
                            f"[{filename}] Calculated frame count: {calculated_frames} (from duration {duration:.2f}s * fps {avg_fps:.2f})"
                        )
                    else:
                        logger.warning(
                            f"[{filename}] Could not determine frame count. nb_frames was '{nb_frames_str}'. Duration={duration}, FPS_str='{avg_frame_rate_str}'."
                        )
                        info[NB_FRAMES_KEY] = None  # Mark as unknown
                except (ValueError, TypeError, ZeroDivisionError):
                    logger.warning(
                        f"[{filename}] Error parsing frame rate '{avg_frame_rate_str}' while calculating frame count."
                    )
                    info[NB_FRAMES_KEY] = None

            # --- Calculate Frame Rate (store the calculated float value) ---
            avg_frame_rate_str = video_stream.get(AVG_FRAME_RATE_KEY, "0/1")
            try:
                if "/" in avg_frame_rate_str:
                    num, den = map(int, avg_frame_rate_str.split("/"))
                    if den > 0:
                        info[AVG_FRAME_RATE_KEY] = num / den
                    else:
                        info[AVG_FRAME_RATE_KEY] = None
                elif avg_frame_rate_str and avg_frame_rate_str != "0":
                    # Handle float strings
                    try:
                        info[AVG_FRAME_RATE_KEY] = float(avg_frame_rate_str)
                    except ValueError:
                        info[AVG_FRAME_RATE_KEY] = None
                else:
                    info[AVG_FRAME_RATE_KEY] = None
            except (ValueError, TypeError, ZeroDivisionError):
                logger.warning(
                    f"[{filename}] Could not parse frame rate '{avg_frame_rate_str}'. Skipping."
                )
                info[AVG_FRAME_RATE_KEY] = None  # Ensure it's None on failure

            # --- Determine Bit Rate ---
            stream_bit_rate = video_stream.get(BIT_RATE_KEY)
            format_bit_rate = format_info.get(BIT_RATE_KEY)
            final_bit_rate = None
            if stream_bit_rate and stream_bit_rate.isdigit():
                final_bit_rate = int(stream_bit_rate)
            elif format_bit_rate and format_bit_rate.isdigit():
                final_bit_rate = int(format_bit_rate)

            # If bitrate still unknown, calculate from file size and duration
            if final_bit_rate is None:
                duration = info[DURATION_KEY]
                if duration and duration > 0:
                    try:
                        file_size = video_path.stat().st_size
                        final_bit_rate = int((file_size * 8) / duration)
                        logger.debug(
                            f"[{filename}] Calculated overall bitrate: {final_bit_rate / 1e6:.2f} Mbps"
                        )
                    except OSError:
                        logger.warning(
                            f"[{filename}] Could not get file size to calculate bitrate."
                        )
                else:
                    logger.warning(
                        f"[{filename}] Could not determine bitrate (missing stream/format bitrate and invalid duration)"
                    )
            info[BIT_RATE_KEY] = final_bit_rate

            # Final checks for essential info
            if info[WIDTH_KEY] is None or info[HEIGHT_KEY] is None:
                logger.warning(f"[{filename}] Could not determine video dimensions.")
                # Decide if this is critical? Maybe not, proceed but log.

            logger.debug(f"[{filename}] Complete analysis results: {info}")
            return info

        except ffmpeg.Error as e:
            stderr = (
                e.stderr.decode("utf-8", errors="ignore").strip()
                if hasattr(e, "stderr") and e.stderr
                else str(e)
            )
            logger.error(f"[{filename}] ffprobe complete analysis failed: {stderr}")
            return None
        except Exception as e:
            logger.error(
                f"[{filename}] Unexpected error analyzing video: {str(e)}",
                exc_info=self.verbose,
            )
            return None

    def _compress_video(self, input_path: Path, output_path: Path) -> bool:
        filename = input_path.name
        cmd_args = []  # Initialize cmd_args here, outside the try block
        try:
            start_time = time.time()
            ffmpeg_cmd = (
                ffmpeg.input(str(input_path))
                .output(
                    str(output_path),
                    # Video options
                    vcodec=self.codec_info["lib"],
                    crf=self.codec_info["crf"],
                    preset=self.codec_info["preset"],
                    **{"tag:v": "hvc1"},  # Add hvc1 tag for Apple compatibility
                    # Audio options
                    acodec=self.config.get("audio_codec", DEFAULT_AUDIO_CODEC),
                    # Container/Muxing options
                    movflags=DEFAULT_MOV_FLAGS,  # For MP4/MOV, helps with streaming
                    # Metadata options
                    map_metadata=METADATA_MAP,  # Copy global metadata
                    # map_chapters=METADATA_MAP # Copy chapters (use dict for kwargs)
                    **{
                        "map_chapters": METADATA_MAP
                    },  # Attempt to copy chapters if present
                )
                # Global options
                .global_args("-loglevel", self.loglevel)
                .global_args(FFMPEG_OVERWRITE_OUTPUT)  # Overwrite output if it exists
                .global_args("-hide_banner")  # Cleaner logs
            )

            cmd_args = ffmpeg_cmd.get_args()
            logger.debug(
                f"[{filename}] Running FFmpeg command: ffmpeg {' '.join(cmd_args)}"
            )

            # Execute FFmpeg command
            stdout, stderr = ffmpeg_cmd.run(capture_stdout=True, capture_stderr=True)

            elapsed = time.time() - start_time
            logger.debug(f"[{filename}] FFmpeg process completed in {elapsed:.2f}s")

            # Log output only if verbose
            if self.verbose:
                stdout_str = stdout.decode("utf-8", errors="ignore").strip()
                stderr_str = stderr.decode("utf-8", errors="ignore").strip()
                if stdout_str:
                    logger.debug(f"[{filename}] FFmpeg stdout:\n{stdout_str}")
                if stderr_str:
                    # Stderr often contains progress, log as info when verbose so it's always visible
                    logger.debug(f"[{filename}] FFmpeg output:\n{stderr_str}")

            return True

        except ffmpeg.Error as e:
            stderr_str = (
                e.stderr.decode("utf-8", errors="ignore").strip()
                if hasattr(e, "stderr") and e.stderr
                else "Unknown FFmpeg error"
            )
            logger.error(f"[{filename}] FFmpeg compression failed: {stderr_str}")
            if self.verbose and cmd_args:  # cmd_args is now guaranteed to be defined
                logger.error(f"[{filename}] Failed command args: {' '.join(cmd_args)}")
            return False
        except Exception as e:
            logger.error(
                f"[{filename}] Unexpected error during compression setup or execution: {str(e)}",
                exc_info=self.verbose,
            )
            return False

    def _verify_transcoding_output(
        self,
        original_path: Path,
        compressed_path: Path,
        original_info: dict[str, Any],
        original_size: int,
    ) -> tuple[bool, str, dict[str, Any] | None]:
        """
        Check the compressed file: existence, size reduction, analysis, metadata.

        Args:
            original_path: Path to the original video.
            compressed_path: Path to the newly compressed video.
            original_info: Analysis results of the original video.
            original_size: Size of the original video in bytes.

        Returns:
            Tuple (success: bool, reason: str, compressed_info: Optional[Dict])
            - success: True if all checks pass.
            - reason: 'verified', 'skipped_size', 'skipped_metadata', or specific error code
                      like 'failed_empty_output', 'failed_stat_compressed', 'failed_compressed_analysis'.
            - compressed_info: Analysis results of the compressed video if successful, else None.
        """
        filename = original_path.name
        # 1. Check if compressed file exists and is not empty
        try:
            if not compressed_path.exists():
                logger.warning(
                    f"[{filename}] Compression finished but output file is missing: {compressed_path}"
                )
                return False, "failed_missing_output", None
            compressed_size = compressed_path.stat().st_size
            if compressed_size == 0:
                logger.warning(
                    f"[{filename}] Compression produced an empty file: {compressed_path}"
                )
                return False, "failed_empty_output", None
        except OSError as e:
            logger.warning(
                f"[{filename}] Cannot access compressed file stats {compressed_path}: {e}"
            )
            return False, "failed_stat_compressed", None

        # 2. Check for sufficient size reduction
        if original_size <= 0:
            logger.warning(
                f"[{filename}] Original file size is zero or negative. Cannot calculate reduction."
            )
            size_reduction_fraction = 0.0
        else:
            size_reduction_fraction = 1.0 - (compressed_size / original_size)

        min_reduction = self.optimization.get("min_size_reduction_fraction", 0.1)

        logger.debug(
            f"[{filename}] Size comparison: {format_size(original_size)} -> {format_size(compressed_size)} (Reduction: {size_reduction_fraction:.1%})"
        )

        if size_reduction_fraction < min_reduction:
            logger.info(
                f"[{filename}] Insufficient size reduction: {size_reduction_fraction:.1%} "
                f"(Required: {min_reduction:.1%})"
            )
            return False, "skipped_size", None  # Skipped, not failed

        # 3. Analyze the compressed video (use minimal analysis first since we don't need frame count yet)
        logger.debug(
            f"[{filename}] Analyzing compressed video (minimal analysis first)."
        )
        compressed_info = self._analyze_video_minimal(compressed_path)
        if not compressed_info:
            # Error logged in _analyze_video_minimal
            return False, "failed_compressed_analysis", None

        # Print detailed file information in verbose mode
        if self.verbose:
            # Format and display comprehensive file information
            original_width = original_info.get(WIDTH_KEY, "unknown")
            original_height = original_info.get(HEIGHT_KEY, "unknown")
            original_codec = original_info.get(CODEC_NAME_KEY, "unknown")
            original_bitrate = original_info.get(BIT_RATE_KEY, 0)
            original_duration = original_info.get(DURATION_KEY, 0)
            original_frames = original_info.get(NB_FRAMES_KEY, "unknown")
            original_fps = original_info.get(AVG_FRAME_RATE_KEY, "unknown")

            compressed_width = compressed_info.get(WIDTH_KEY, "unknown")
            compressed_height = compressed_info.get(HEIGHT_KEY, "unknown")
            compressed_codec = compressed_info.get(CODEC_NAME_KEY, "unknown")
            compressed_bitrate = compressed_info.get(BIT_RATE_KEY, 0)
            compressed_duration = compressed_info.get(DURATION_KEY, 0)
            compressed_frames = (
                "will be checked later"  # Not available yet in minimal analysis
            )
            compressed_fps = compressed_info.get(AVG_FRAME_RATE_KEY, "unknown")

            # Calculate bitrates in Mbps
            orig_mbps = (
                f"{original_bitrate / 1_000_000:.2f} Mbps"
                if original_bitrate
                else "unknown"
            )
            comp_mbps = (
                f"{compressed_bitrate / 1_000_000:.2f} Mbps"
                if compressed_bitrate
                else "unknown"
            )

            # Format durations as hours:minutes:seconds
            def format_duration(seconds):
                if not seconds:
                    return "unknown"
                h = int(seconds // 3600)
                m = int((seconds % 3600) // 60)
                s = seconds % 60
                return f"{h:02d}:{m:02d}:{s:06.3f}"

            orig_duration_fmt = format_duration(original_duration)
            comp_duration_fmt = format_duration(compressed_duration)

            # Create comprehensive comparison table
            logger.info(f"[{filename}] Detailed file comparison:")
            logger.info(f"  {'Property':<15} {'Original':<20} {'Compressed':<20}")
            logger.info(f"  {'-' * 15:<15} {'-' * 20:<20} {'-' * 20:<20}")
            logger.info(
                f"  {'File Size':<15} {format_size(original_size):<20} {format_size(compressed_size):<20}"
            )
            logger.info(
                f"  {'Resolution':<15} {f'{original_width}x{original_height}':<20} {f'{compressed_width}x{compressed_height}':<20}"
            )
            logger.info(f"  {'Codec':<15} {original_codec:<20} {compressed_codec:<20}")
            logger.info(f"  {'Bitrate':<15} {orig_mbps:<20} {comp_mbps:<20}")
            logger.info(
                f"  {'Duration':<15} {orig_duration_fmt:<20} {comp_duration_fmt:<20}"
            )
            logger.info(
                f"  {'Frame Count':<15} {original_frames:<20} {compressed_frames:<20}"
            )
            logger.info(f"  {'Frame Rate':<15} {original_fps:<20} {compressed_fps:<20}")
            logger.info(
                f"  {'Reduction':<15} {'':<20} {f'{size_reduction_fraction:.2%}':<20}"
            )

        # 4. Verify key metadata consistency (excluding frame count, checked in quality check)
        metadata_match, metadata_issues = self._verify_metadata(
            filename,
            original_info,
            compressed_info,  # Pass filename here
        )
        if not metadata_match:
            logger.warning(
                f"[{filename}] Metadata mismatch detected: {metadata_issues}. "
                "This might indicate a problem with the transcode. Skipping."
            )
            return (
                False,
                "skipped_metadata",
                compressed_info,
            )  # Skipped due to metadata concerns

        logger.debug(f"[{filename}] Metadata verification passed.")
        return True, "verified", compressed_info

    def _verify_metadata(
        self,
        filename: str,
        original_info: dict[str, Any],
        compressed_info: dict[str, Any],
    ) -> tuple[bool, str]:
        """
        Compare key metadata fields (duration, dimensions, frame rate)
        between original and compressed videos. Frame count is checked separately.

        Args:
            filename: Name of the original file (for logging).
            original_info: Analysis dict for the original video.
            compressed_info: Analysis dict for the compressed video.

        Returns:
            Tuple (match: bool, issues: str). 'issues' is a comma-separated string of problems if match is False.
        """
        issues = []
        # Increase tolerance slightly for more flexibility
        tolerance = 0.02  # Relative tolerance for float comparisons (2%, was 1%)

        # Get values safely, providing defaults
        orig_dur = original_info.get(DURATION_KEY, 0.0) or 0.0
        comp_dur = compressed_info.get(DURATION_KEY, 0.0) or 0.0
        orig_w = original_info.get(WIDTH_KEY, 0) or 0
        orig_h = original_info.get(HEIGHT_KEY, 0) or 0
        comp_w = compressed_info.get(WIDTH_KEY, 0) or 0
        comp_h = compressed_info.get(HEIGHT_KEY, 0) or 0
        orig_rate = original_info.get(AVG_FRAME_RATE_KEY, 0.0) or 0.0
        comp_rate = compressed_info.get(AVG_FRAME_RATE_KEY, 0.0) or 0.0

        # Detailed Debug Logging (always happens if debug is enabled)
        logger.debug(f"[{filename}] Metadata Comparison:")
        logger.debug(
            f"  Duration: Original={orig_dur:.3f}s, Compressed={comp_dur:.3f}s (Diff={abs(orig_dur - comp_dur):.3f}s)"
        )
        logger.debug(
            f"  Dimensions: Original={orig_w}x{orig_h}, Compressed={comp_w}x{comp_h}"
        )
        logger.debug(
            f"  Frame Rate: Original={orig_rate:.3f} fps, Compressed={comp_rate:.3f} fps (Tolerance: {tolerance:.1%})"
        )
        # Frame count comparison is separate in _check_frame_consistency

        # Compare Duration (allow slightly larger tolerance: 0.5s absolute or 1% relative - keep this tighter)
        duration_tolerance_abs = 0.5
        duration_tolerance_rel = 0.01  # Keep duration tolerance strict
        # Check types just in case analysis returned something weird
        if isinstance(orig_dur, (int, float)) and isinstance(comp_dur, (int, float)):
            if abs(orig_dur - comp_dur) > max(
                duration_tolerance_abs, orig_dur * duration_tolerance_rel
            ):
                issues.append(f"Duration ({orig_dur:.2f}s vs {comp_dur:.2f}s)")
        else:
            issues.append(
                f"Invalid duration values for comparison ({orig_dur} vs {comp_dur})"
            )

        # Compare Dimensions (expect exact match)
        # ... (dimension comparison unchanged)
        if not (
            isinstance(orig_w, int)
            and isinstance(orig_h, int)
            and isinstance(comp_w, int)
            and isinstance(comp_h, int)
        ) or (orig_w <= 0 or orig_h <= 0 or comp_w <= 0 or comp_h <= 0):
            issues.append(
                f"Invalid dimensions ({orig_w}x{orig_h} vs {comp_w}x{comp_h})"
            )
        elif orig_w != comp_w or orig_h != comp_h:
            issues.append(f"Resolution ({orig_w}x{orig_h} vs {comp_w}x{comp_h})")

        # Compare Frame Rate (if available and valid in both, use updated tolerance)
        if isinstance(orig_rate, (int, float)) and isinstance(comp_rate, (int, float)):
            # Use relative tolerance (now 2%) for typical frame rates, absolute for near-zero
            if orig_rate > 1e-6:  # Check if rate is reasonably positive
                # Use the updated tolerance variable here
                if abs(orig_rate - comp_rate) > (orig_rate * tolerance):
                    issues.append(
                        f"Frame rate ({orig_rate:.3f} vs {comp_rate:.3f}) differing by more than {tolerance:.1%}"
                    )
            elif (
                abs(orig_rate - comp_rate)
                > tolerance  # Absolute tolerance for very low rates remains 2%
            ):
                issues.append(
                    f"Frame rate ({orig_rate:.3f} vs {comp_rate:.3f}) differing by more than {tolerance:.3f}"
                )
        # Only add issue if one rate is valid and the other isn't, or if they differ significantly
        elif (orig_rate is not None and orig_rate > 0) or (
            comp_rate is not None and comp_rate > 0
        ):
            # If one is valid and the other is None/zero, report inconsistency
            if not (
                isinstance(orig_rate, (int, float))
                and isinstance(comp_rate, (int, float))
                and orig_rate > 1e-6
                and comp_rate > 1e-6
            ):
                issues.append(
                    f"Frame rate info inconsistent or missing ({orig_rate} vs {comp_rate})"
                )

        return len(issues) == 0, ", ".join(issues)

    def _extract_frames_precisely(
        self,
        video_path: Path,
        frame_indices: list[int],
        output_dir: Path,
        filename_suffix: str = "",
    ) -> bool:
        """
        Extracts specific frames from a video file using FFmpeg, one frame at a time
        for reliable output naming based on the original frame index.
        Output filenames will be like 'frame_00000{filename_suffix}.png'.

        Args:
            video_path: Path to the video file.
            frame_indices: List of 0-based frame indices to extract.
            output_dir: Directory to save the extracted frames (as PNG).
            filename_suffix: String to append before the .png extension (e.g., "-orig", "-opti").

        Returns:
            True if extraction command runs successfully AND all requested frames
            were created, False otherwise.
        """
        filename = video_path.name
        if not frame_indices:
            logger.debug(f"[{filename}] No frame indices provided for extraction.")
            return True  # Nothing to do

        logger.debug(
            f"[{filename}] Requested frame indices for extraction: {frame_indices}"
        )
        output_dir.mkdir(parents=True, exist_ok=True)
        expected_indices = set(frame_indices)
        created_indices = set()

        # --- Loop and Extract One Frame at a Time ---
        for idx in sorted(list(expected_indices)):  # Process in order for cleaner logs
            # Construct filename with suffix
            output_filename = f"frame_{idx:05d}{filename_suffix}.png"
            output_path = output_dir / output_filename
            logger.debug(
                f"[{filename}] Attempting to extract frame {idx} -> {output_path}"
            )
            try:
                ffmpeg_cmd_obj = (
                    ffmpeg.input(str(video_path))
                    .filter("select", f"eq(n,{idx})")  # Select only this frame
                    .output(
                        str(output_path),
                        vframes=1,  # Extract exactly one frame
                        vsync="vfr",  # Necessary with select
                    )
                    .global_args("-loglevel", self.loglevel)
                    .global_args("-hide_banner")
                    .global_args("-y")  # Overwrite if somehow exists
                )
                cmd_args = ffmpeg_cmd_obj.compile()
                logger.debug(
                    f"[{filename}] Frame {idx} extraction command: {' '.join(cmd_args)}"
                )

                ffmpeg_cmd_obj.run(capture_stdout=True, capture_stderr=True)

                # Simple check if the specific file was created
                if output_path.exists() and output_path.stat().st_size > 0:
                    logger.debug(f"[{filename}] Successfully extracted frame {idx}.")
                    created_indices.add(idx)
                else:
                    logger.warning(
                        f"[{filename}] Failed to extract frame {idx} (output file missing or empty: {output_path})."
                    )
                    # Optionally break here if one failure means total failure
                    # break

            except ffmpeg.Error as e:
                stderr = (
                    e.stderr.decode("utf-8", errors="ignore").strip()
                    if hasattr(e, "stderr") and e.stderr
                    else str(e)
                )
                logger.error(f"[{filename}] Failed to extract frame {idx}: {stderr}")
                # Optionally break here
                # break
            except Exception as e:
                logger.error(
                    f"[{filename}] Unexpected error extracting frame {idx}: {e}",
                    exc_info=self.verbose,
                )
                # Optionally break here
                # break

        # --- Final Verification ---
        logger.debug(
            f"[{filename}] Created frame indices: {sorted(list(created_indices))}"
        )

        if created_indices == expected_indices:
            logger.debug(
                f"[{filename}] Successfully extracted all {len(expected_indices)} requested frames."
            )
            return True
        else:
            missing = sorted(list(expected_indices - created_indices))
            # 'extra' shouldn't happen with this method, but check defensively
            extra = sorted(list(created_indices - expected_indices))
            logger.warning(
                f"[{filename}] Frame extraction mismatch after individual attempts: Expected {len(expected_indices)} frames (indices {sorted(list(expected_indices))}), found {len(created_indices)} (indices {sorted(list(created_indices))})."
            )
            if missing:
                logger.warning(f"[{filename}]   Missing frame indices: {missing}")
            if extra:
                logger.warning(
                    f"[{filename}]   Unexpected frame indices found: {extra}"
                )
            return False  # Return False as not all expected frames were found correctly

    def _check_frame_consistency(
        self,
        orig_path: Path,
        comp_path: Path,
        orig_info: dict[str, Any],
        comp_info: dict[str, Any],
    ) -> tuple[bool, str]:
        """
        Performs quality check by comparing frame counts and sample frames.

        1. Compares total frame counts between original and compressed videos.
        2. Extracts N frames from the start and N frames from near the end of both videos.
           If keep_frames is True, saves these to a persistent subfolder.
        3. Compares corresponding frame pairs using Mean Squared Error (MSE).
        4. Implements flexible frame matching for start frames (0, 1).

        Args:
            orig_path: Path to the original video.
            comp_path: Path to the compressed video.
            orig_info: Analysis dict for the original video (must contain NB_FRAMES_KEY).
            comp_info: Analysis dict for the compressed video (must contain NB_FRAMES_KEY).

        Returns:
            Tuple (quality_pass: bool, details: str).
            - quality_pass: True if frame counts are close and frame comparisons pass MSE threshold.
            - details: String summarizing the checks performed (frame counts, frames compared, MSE results).
        """
        filename = orig_path.name
        logger.debug(f"[{filename}] Starting frame consistency check.")
        details_log = []
        failure_reason = (
            None  # Track specific reason for failure: 'frame_count' or 'mse'
        )
        max_mse_found = 0.0  # Track the highest MSE found
        skip_first_frame = self.optimization.get("skip_first_frame_comparison", True)
        flexible_matching = self.optimization.get("flexible_frame_matching", True)

        # --- Ensure we have frame counts (run full analysis if needed) ---
        # Check if original info has frame count, if not, run full analysis
        if NB_FRAMES_KEY not in orig_info or orig_info[NB_FRAMES_KEY] is None:
            logger.debug(
                f"[{filename}] Original frame count not available, running full analysis."
            )
            full_orig_info = self._analyze_video(orig_path)
            if full_orig_info:
                orig_info[NB_FRAMES_KEY] = full_orig_info[NB_FRAMES_KEY]
                logger.debug(
                    f"[{filename}] Updated original frame count: {orig_info[NB_FRAMES_KEY]}"
                )

        # Check if compressed info has frame count, if not, run full analysis
        if NB_FRAMES_KEY not in comp_info or comp_info[NB_FRAMES_KEY] is None:
            logger.debug(
                f"[{filename}] Compressed frame count not available, running full analysis."
            )
            full_comp_info = self._analyze_video(comp_path)
            if full_comp_info:
                comp_info[NB_FRAMES_KEY] = full_comp_info[NB_FRAMES_KEY]
                logger.debug(
                    f"[{filename}] Updated compressed frame count: {comp_info[NB_FRAMES_KEY]}"
                )

        # --- 1. Compare Frame Counts ---
        orig_frames = orig_info.get(NB_FRAMES_KEY)
        comp_frames = comp_info.get(NB_FRAMES_KEY)
        frame_count_tolerance = self.optimization.get("frame_count_tolerance", 2)

        if orig_frames is None or comp_frames is None:
            logger.warning(
                f"[{filename}] Cannot compare frame counts: Original={orig_frames}, Compressed={comp_frames}. Skipping count check, proceeding to content check if possible."
            )
            details_log.append(
                f"Frame Counts: Unknown (Orig: {orig_frames}, Comp: {comp_frames})"
            )
            # Allow proceeding to frame content comparison even if counts are unknown
            # The content check itself requires a valid frame count from original
        else:
            count_diff = abs(orig_frames - comp_frames)
            count_check_passed = count_diff <= frame_count_tolerance
            log_level = logging.DEBUG if count_check_passed else logging.WARNING
            logger.log(
                log_level,
                f"[{filename}] Frame Count Check: Original={orig_frames}, Compressed={comp_frames} (Diff={count_diff}, Tolerance={frame_count_tolerance}) -> {'PASS' if count_check_passed else 'FAIL'}",
            )
            details_log.append(
                f"Frame Counts: Orig={orig_frames}, Comp={comp_frames} ({'PASS' if count_check_passed else 'FAIL'})"
            )
            if not count_check_passed:
                # If counts differ significantly, fail quality check immediately
                failure_reason = "frame_count"
                return False, ", ".join(
                    details_log
                ) + " - Frame count mismatch exceeds tolerance"

        # --- 2. Prepare for Frame Content Comparison ---
        # We need a valid original frame count to select comparison frames
        if orig_frames is None:
            logger.warning(
                f"[{filename}] Original frame count unknown. Cannot perform frame content comparison."
            )
            details_log.append("Frame Content: Skipped (unknown original frame count)")
            # If we got here, count check was skipped or passed (if compressed count was also None)
            # Pass the overall check if we only skipped content comparison due to missing count info
            return True, ", ".join(details_log)

        # Check if there are enough frames for the comparison pattern
        # Need at least N at start, N near end, plus the offset between them
        min_frames_needed = (
            FRAME_COMPARISON_COUNT * 2 + FRAME_END_OFFSET + 1
        )  # +1 because indices are 0-based
        if orig_frames < min_frames_needed:
            logger.warning(
                f"[{filename}] Not enough frames ({orig_frames}) for full start/end comparison (need {min_frames_needed}). Skipping frame content check."
            )
            # If counts matched (or were tolerable), and size reduction was good, pass here.
            details_log.append(f"Frame Content: Skipped (only {orig_frames} frames)")
            return True, ", ".join(details_log)  # Pass if frame count was okay

        # Determine frame indices to extract
        start_indices = list(range(FRAME_COMPARISON_COUNT))
        # Ensure end indices don't go below zero if video is extremely short but passed min_frames_needed check
        end_start_index = max(
            0, orig_frames - FRAME_END_OFFSET - FRAME_COMPARISON_COUNT
        )
        end_indices = list(
            range(
                end_start_index,
                max(
                    FRAME_COMPARISON_COUNT, orig_frames - FRAME_END_OFFSET
                ),  # Ensure range end is valid
            )
        )
        # Combine, remove duplicates (if overlap happens on short videos), and sort
        frame_indices_to_check = sorted(list(set(start_indices + end_indices)))

        # Ensure we don't try to check more frames than exist (e.g., if FRAME_END_OFFSET is large)
        frame_indices_to_check = [
            idx for idx in frame_indices_to_check if idx < orig_frames
        ]

        if not frame_indices_to_check:
            logger.warning(
                f"[{filename}] No valid frame indices calculated for content comparison. Skipping."
            )
            details_log.append("Frame Content: Skipped (no valid indices)")
            return True, ", ".join(details_log)  # Pass if frame count was okay

        # --- Determine Output Directory for Frames ---
        # *** MODIFICATION START ***
        frame_output_dir: Path | None = None
        temp_dir_for_cleanup: str | None = None  # Store path if temp dir was created
        cleanup_dir = False  # Flag to indicate if cleanup is needed

        if self.keep_frames:
            # Create persistent subfolder in the original video's location
            frame_output_dir_candidate = orig_path.parent / orig_path.stem
            logger.info(
                f"[{filename}] Saving comparison frames to: {frame_output_dir_candidate}"
            )
            try:
                frame_output_dir_candidate.mkdir(parents=True, exist_ok=True)
                frame_output_dir = frame_output_dir_candidate
            except OSError as e_mkdir:
                logger.error(
                    f"[{filename}] Failed to create persistent frame directory: {e_mkdir}. Cannot perform frame comparison."
                )
                details_log.append("Frame Content: Failed (cannot create output dir)")
                return False, ", ".join(details_log)
        else:
            # Use a single temporary directory
            try:
                temp_dir_for_cleanup = tempfile.mkdtemp(
                    prefix=f"vidsqueeze_{filename}_frames_"
                )
                frame_output_dir = Path(temp_dir_for_cleanup)
                cleanup_dir = True  # Mark for cleanup
            except OSError as e_tmpdir:
                logger.error(
                    f"[{filename}] Failed to create temporary frame directory: {e_tmpdir}. Cannot perform frame comparison."
                )
                details_log.append("Frame Content: Failed (cannot create temp dir)")
                return False, ", ".join(details_log)

        # Ensure the directory object is not None before proceeding
        if frame_output_dir is None:
            logger.error(
                f"[{filename}] Internal error: Frame directory object not assigned."
            )
            details_log.append("Frame Content: Failed (internal dir error)")
            return False, ", ".join(details_log)
        # *** MODIFICATION END ***

        # Wrap frame extraction and comparison in try/finally for cleanup
        comparison_passed = False
        try:
            # --- 3. Extract Frames ---
            # Pass the determined Path objects and appropriate suffixes
            logger.debug(
                f"[{filename}] Attempting to extract frames for comparison: {frame_indices_to_check}"
            )
            # Initialize mismatched_frames_details here to ensure it's always defined
            mismatched_frames_details: list[
                str
            ] = []  # FIRST initialization WITH type hint

            extract_orig_ok = self._extract_frames_precisely(
                orig_path, frame_indices_to_check, frame_output_dir, "-orig"
            )
            extract_comp_ok = self._extract_frames_precisely(
                comp_path, frame_indices_to_check, frame_output_dir, "-opti"
            )

            if not extract_orig_ok or not extract_comp_ok:
                logger.error(
                    f"[{filename}] Failed to extract frames for comparison from one or both videos."
                )
                details_log.append("Frame Content: Failed (extraction error)")
                # comparison_passed remains False
            else:
                # --- 4. Compare Extracted Frames ---
                mse_threshold = self.optimization.get(
                    "frame_comparison_mse_threshold", FRAME_MSE_THRESHOLD
                )
                comparison_results_summary = []
                max_mse_found = 0.0  # Initialize max_mse_found at this level
                first_frame_failed = (
                    False  # Flag to track if only the first frame failed
                )
                other_frames_passed = (
                    True  # Flag to track if all non-first frames passed
                )

                logger.debug(
                    f"[{filename}] Comparing {len(frame_indices_to_check)} frame pairs using MSE threshold {mse_threshold:.4f}"
                )

                # Flexible comparison strategy: create a mapping of frames to compare
                comparison_pairs = []

                # If using flexible matching for first/second frames
                if (
                    flexible_matching and len(frame_indices_to_check) >= 4
                ):  # Need at least 2 frames at start and end
                    # For first frames, try multiple combinations:
                    # orig 0 -> comp 0, orig 0 -> comp 1, orig 1 -> comp 0, orig 1 -> comp 1
                    comparison_pairs.extend(
                        [
                            (0, 0, "0→0"),  # (orig_idx, comp_idx, label)
                            (0, 1, "0→1"),
                            (1, 0, "1→0"),
                            (1, 1, "1→1"),
                        ]
                    )

                    # For remaining frames, do direct comparison
                    for idx in frame_indices_to_check[2:]:
                        comparison_pairs.append((idx, idx, f"{idx}→{idx}"))
                else:
                    # Standard direct comparison
                    for idx in frame_indices_to_check:
                        comparison_pairs.append((idx, idx, f"{idx}→{idx}"))

                # Track successful matches for flexible comparisons
                successful_matches: dict[int, list[tuple[int, float]]] = {}
                failed_matches: dict[int, list[tuple[int, float]]] = {}
                mismatched_frames_details = []  # SECOND initialization/clear WITHOUT type hint

                # Create a detailed frame comparison table for verbose mode
                if self.verbose:
                    logger.info(f"[{filename}] Detailed frame comparison results:")
                    logger.info(
                        f"  {'Frame Pair':<15} {'MSE Value':<12} {'Result':<10} {'Threshold':<10}"
                    )
                    logger.info(
                        f"  {'-' * 15:<15} {'-' * 12:<12} {'-' * 10:<10} {'-' * 10:<10}"
                    )

                for orig_idx, comp_idx, label in comparison_pairs:
                    # Check that files exist for both frames
                    orig_frame_path = (
                        frame_output_dir / f"frame_{orig_idx:05d}-orig.png"
                    )
                    comp_frame_path = (
                        frame_output_dir / f"frame_{comp_idx:05d}-opti.png"
                    )

                    if not orig_frame_path.exists() or not comp_frame_path.exists():
                        error_msg = f"Missing frame file for {label} comparison (Orig exists: {orig_frame_path.exists()}, Comp exists: {comp_frame_path.exists()})."
                        logger.warning(f"[{filename}] {error_msg}")
                        mismatched_frames_details.append(
                            f"Frames {label}: Missing File"
                        )
                        if self.verbose:
                            logger.info(
                                f"  {label:<15} {'N/A':<12} {'MISSING':<10} {mse_threshold:<10.4f}"
                            )
                        continue

                    try:
                        img_orig = cv2.imread(str(orig_frame_path))  # type: ignore
                        img_comp = cv2.imread(str(comp_frame_path))  # type: ignore

                        if img_orig is None or img_comp is None:
                            error_msg = f"Could not read frame images for {label} comparison (Orig valid: {img_orig is not None}, Comp valid: {img_comp is not None})."
                            logger.warning(f"[{filename}] {error_msg}")
                            mismatched_frames_details.append(
                                f"Frames {label}: Read Error"
                            )
                            if self.verbose:
                                logger.info(
                                    f"  {label:<15} {'N/A':<12} {'READ ERR':<10} {mse_threshold:<10.4f}"
                                )
                            continue

                        # --- Generate and Save Diff Image if keep_frames is True ---
                        if self.keep_frames:
                            try:
                                diff_img_raw = cv2.absdiff(img_orig, img_comp)  # type: ignore
                                diff_factor = 10
                                diff_img_exaggerated = np.clip(
                                    diff_img_raw.astype(np.float32) * diff_factor,
                                    0,
                                    255,
                                ).astype(np.uint8)
                                diff_frame_path = (
                                    frame_output_dir
                                    / f"frame_{orig_idx}-{comp_idx}-diff.png"
                                )
                                cv2.imwrite(str(diff_frame_path), diff_img_exaggerated)  # type: ignore
                                logger.debug(
                                    f"[{filename}] Saved exaggerated difference image: {diff_frame_path.name}"
                                )
                            except Exception as e_diff:
                                logger.warning(
                                    f"[{filename}] Failed to generate or save diff image for {label}: {e_diff}"
                                )

                        mse = calculate_mse(img_orig, img_comp)
                        max_mse_found = max(max_mse_found, mse)
                        comparison_results_summary.append(f"{label}={mse:.2f}")

                        # Add to verbose frame comparison table
                        if self.verbose:
                            result = "PASS" if mse <= mse_threshold else "FAIL"
                            logger.info(
                                f"  {label:<15} {mse:<12.4f} {result:<10} {mse_threshold:<10.4f}"
                            )

                        # Store results for flexible matching
                        if mse <= mse_threshold:
                            # This is a successful match
                            if orig_idx not in successful_matches:
                                successful_matches[orig_idx] = []
                            successful_matches[orig_idx].append((comp_idx, mse))
                        else:
                            # This is a failed match
                            if orig_idx not in failed_matches:
                                failed_matches[orig_idx] = []
                            failed_matches[orig_idx].append((comp_idx, mse))

                            # For direct comparisons, track first frame failures separately
                            if orig_idx == 0 and comp_idx == 0:
                                first_frame_failed = True
                                fail_reason = (
                                    f"MSE {mse:.4f} > Threshold {mse_threshold:.4f}"
                                )
                                logger.info(
                                    f"[{filename}] First frame comparison failed: {fail_reason}"
                                )
                                mismatched_frames_details.append(
                                    f"Frame 0: Failed ({fail_reason})"
                                )
                            elif (
                                orig_idx == comp_idx
                            ):  # Direct comparison of non-first frames
                                other_frames_passed = False
                                fail_reason = (
                                    f"MSE {mse:.4f} > Threshold {mse_threshold:.4f}"
                                )
                                logger.info(
                                    f"[{filename}] Frame {orig_idx} comparison failed: {fail_reason}"
                                )
                                mismatched_frames_details.append(
                                    f"Frame {orig_idx}: Failed ({fail_reason})"
                                )

                    except Exception as e:
                        logger.error(
                            f"[{filename}] Error comparing frames {label}: {e}",
                            exc_info=self.verbose,
                        )
                        mismatched_frames_details.append(f"Frames {label}: Error ({e})")
                        if self.verbose:
                            logger.info(
                                f"  {label:<15} {'N/A':<12} {'ERROR':<10} {mse_threshold:<10.4f}"
                            )

                # --- 5. Evaluate flexible matching results ---
                # For each original frame, check if any comparison succeeded
                frames_with_no_match = []
                for idx in {orig_idx for orig_idx, _, _ in comparison_pairs}:
                    if idx not in successful_matches and idx in failed_matches:
                        frames_with_no_match.append(idx)

                # Special handling for first frame (0) and second frame (1)
                first_frames_all_failed = False
                if flexible_matching:
                    # Check if frames 0 and 1 have ANY successful matches
                    first_frames_matches = [
                        match
                        for idx in [0, 1]
                        if idx in successful_matches
                        for match in successful_matches[idx]
                    ]
                    if len(first_frames_matches) == 0 and (
                        0 in failed_matches or 1 in failed_matches
                    ):
                        first_frames_all_failed = True
                        logger.info(
                            f"[{filename}] All flexible comparisons of first frames failed"
                        )
                    else:
                        logger.debug(
                            f"[{filename}] Found {len(first_frames_matches)} successful matches among first frames"
                        )

                # Print comprehensive comparison summary if verbose
                if self.verbose:
                    logger.info(f"[{filename}] Frame Comparison Summary:")
                    logger.info(f"  MSE Threshold: {mse_threshold:.4f}")
                    logger.info(f"  Maximum MSE Found: {max_mse_found:.4f}")
                    logger.info(f"  First Frame Failed: {first_frame_failed}")
                    logger.info(f"  Other Frames All Passed: {other_frames_passed}")
                    logger.info(f"  Flexible First Frame Matching: {flexible_matching}")
                    logger.info(f"  Skip First Frame Comparison: {skip_first_frame}")
                    logger.info(f"  First Frames All Failed: {first_frames_all_failed}")
                    logger.info(f"  Frames With No Match: {frames_with_no_match}")

                # Special first-frame handling: if only first frame failed but we're skipping first frame checks
                if skip_first_frame and first_frame_failed and other_frames_passed:
                    logger.info(
                        f"[{filename}] Only first frame failed but skip_first_frame_comparison is enabled. Ignoring failure."
                    )
                    mismatched_frames_details = []  # Clear the mismatched frames list
                    comparison_passed = True
                # Flexible matching success: if any flexible match succeeded for first frames
                elif (
                    flexible_matching
                    and not first_frames_all_failed
                    and other_frames_passed
                ):
                    logger.info(
                        f"[{filename}] Flexible frame matching succeeded for first frames. Ignoring first frame failures."
                    )
                    # Remove first frame failures from mismatched_frames_details
                    mismatched_frames_details = [
                        d
                        for d in mismatched_frames_details
                        if not d.startswith("Frame 0:")
                        and not d.startswith("Frames 0→")
                    ]
                    comparison_passed = True
                # Standard success/failure evaluation
                else:
                    comparison_passed = len(mismatched_frames_details) == 0

                summary_str = "; ".join(comparison_results_summary)
                details_log.append(
                    f"Frame Content ({len(frame_indices_to_check)} pairs, MaxMSE={max_mse_found:.2f}, Threshold={mse_threshold:.2f}): {summary_str}"
                )

                if not comparison_passed:
                    logger.warning(
                        f"[{filename}] Frame content comparison failed. Issues: {'; '.join(mismatched_frames_details)}"
                    )
                    # Pass failure reason and max MSE through details_log for later use
                    if first_frame_failed and other_frames_passed:
                        failure_reason = "first_frame_mse"
                    elif not first_frames_all_failed:
                        failure_reason = "mse"
                    details_log.append(
                        f"failure_type={failure_reason} max_mse={max_mse_found:.2f}"
                    )
                else:
                    logger.debug(
                        f"[{filename}] All frame comparisons passed (with flexible matching and/or first frame skipping as configured)."
                    )

        finally:
            # --- Cleanup (only if using temporary directories) ---
            # *** MODIFICATION START ***
            if cleanup_dir and temp_dir_for_cleanup:
                logger.debug(
                    f"[{filename}] Cleaning up temporary frame directory: {temp_dir_for_cleanup}"
                )
                # Use stored string path for cleanup
                if Path(temp_dir_for_cleanup).exists():
                    try:
                        shutil.rmtree(temp_dir_for_cleanup)
                    except OSError as e_cleanup:
                        logger.warning(
                            f"[{filename}] Could not remove temp frame dir {temp_dir_for_cleanup}: {e_cleanup}"
                        )
            elif not cleanup_dir:
                logger.debug(
                    f"[{filename}] Skipping cleanup of frame directory (--keep_frames=True)."
                )
            # *** MODIFICATION END ***

        # Determine final result based on comparison_passed flag
        if not comparison_passed:
            # Append failure reason if not already done (e.g., if extraction failed)
            if (
                not mismatched_frames_details
                and "extraction error" not in details_log[-1]
            ):
                details_log[-1] += " - Comparison failed or skipped"
            return False, ", ".join(details_log)
        else:
            return True, ", ".join(details_log)  # Comparison succeeded

    def _replace_file(self, original_path: Path, optimized_path: Path) -> bool:
        """
        Safely replace the original file with the optimized version using renames.

        Handles renaming the original, moving the optimized file, and cleaning up
        the renamed original based on 'keep_original' and 'safe' flags.
        Attempts to revert changes if the move operation fails.

        NOTE: Atomicity depends on OS and filesystem. Assumes rename is atomic
              if src and dest are on the same filesystem.

        Args:
            original_path: Path to the original file.
            optimized_path: Path to the temporary optimized file.

        Returns:
            True if replacement was successful, False otherwise. If False, it attempts
            to leave the system state with the original file intact and the
            optimized file potentially remaining at optimized_path.
        """
        filename = original_path.name
        renamed_original_path = original_path.with_name(
            f"{original_path.stem}{RENAME_SUFFIX}{original_path.suffix}"
        )

        # Determine the final destination path, considering force_mp4
        if self.force_mp4:
            # If forcing MP4, prepare a path with the stem from original but .mp4 extension
            final_path = original_path.with_name(f"{original_path.stem}.mp4")
            if final_path != original_path:
                logger.debug(
                    f"[{filename}] Format conversion: {original_path.suffix} -> .mp4"
                )
        else:
            # No format conversion, use the original path
            final_path = original_path

        logger.debug(f"[{filename}] Attempting atomic replacement.")
        logger.debug(
            f"[{filename}]   Step 1: Rename original {original_path} -> {renamed_original_path}"
        )

        # 1. Rename original
        try:
            original_path.rename(renamed_original_path)
            logger.debug(f"[{filename}]   Successfully renamed original.")
        except OSError as e:
            logger.error(
                f"[{filename}]   Failed to rename original file {original_path} to {renamed_original_path}: {e}. "
                f"Optimization aborted. Original file should remain untouched."
            )
            logger.warning(
                f"[{filename}]   The optimized version is available at: {optimized_path}"
            )
            return False

        # 2. Move optimized file into place
        logger.debug(
            f"[{filename}]   Step 2: Move optimized {optimized_path} -> {final_path}"
        )
        try:
            optimized_path.rename(final_path)
            if not final_path.exists():
                raise OSError(
                    f"Rename operation reported success, but destination {final_path} not found."
                )
            logger.debug(
                f"[{filename}]   Successfully moved optimized file into place."
            )

        except OSError as e:
            logger.error(
                f"[{filename}]   Failed to move optimized file {optimized_path} to {final_path}: {e}."
            )
            logger.error(
                f"[{filename}]   Attempting to restore original file by renaming {renamed_original_path} back."
            )
            try:
                renamed_original_path.rename(original_path)
                logger.info(
                    f"[{filename}]   Successfully restored original file: {original_path}"
                )
                logger.error(
                    f"[{filename}]   Replacement failed. Original file restored."
                )
                logger.warning(
                    f"[{filename}]   The optimized file may still exist at {optimized_path}"
                )
            except OSError as e_restore:
                logger.critical(
                    f"[{filename}]   CRITICAL ERROR: Failed to move optimized file AND failed to restore original "
                    f"from {renamed_original_path} back to {original_path}: {e_restore}."
                )
                logger.critical(f"[{filename}]   Manual intervention required!")
                logger.critical(
                    f"[{filename}]   Renamed original (backup): {renamed_original_path}"
                )
                logger.critical(
                    f"[{filename}]   Optimized version (if exists): {optimized_path}"
                )
            return False

        # 3. Handle the renamed original (backup) file according to flags
        logger.debug(
            f"[{filename}]   Step 3: Handle backup file: {renamed_original_path}"
        )
        try:
            if self.keep_original:
                logger.info(
                    f"[{filename}]   Keeping original file backup as: {renamed_original_path}"
                )
            elif self.safe:
                logger.debug(
                    f"[{filename}]   Moving backup to trash: {renamed_original_path}"
                )
                send2trash(str(renamed_original_path))
                logger.info(f"[{filename}]   Moved original file backup to trash.")
            else:
                logger.debug(
                    f"[{filename}]   Deleting backup file permanently: {renamed_original_path}"
                )
                renamed_original_path.unlink()
                logger.info(f"[{filename}]   Deleted original file backup.")

        except FileNotFoundError:
            logger.warning(
                f"[{filename}]   Renamed original file {renamed_original_path} not found during cleanup step. "
                "It might have been moved or deleted externally."
            )
        except Exception as e_cleanup:
            action = (
                "keep" if self.keep_original else ("trash" if self.safe else "delete")
            )
            logger.error(
                f"[{filename}]   Error during backup file cleanup ('{action}' action) for {renamed_original_path}: {e_cleanup}"
            )

        # Handle the optimized file if keep_optimized is set and the replacement failed
        logger.debug(f"[{filename}]   Step 4: Handle optimized file: {optimized_path}")
        try:
            if self.keep_optimized:
                after_squeeze_path = final_path.with_name(
                    f"{final_path.stem}--after-squeeze{final_path.suffix}"
                )
                logger.debug(
                    f"[{filename}]   Renaming optimized file to: {after_squeeze_path}"
                )
                optimized_path.rename(after_squeeze_path)
                logger.info(
                    f"[{filename}]   Kept optimized file as: {after_squeeze_path}"
                )
            else:
                logger.debug(
                    f"[{filename}]   Deleting optimized file: {optimized_path}"
                )
                optimized_path.unlink()
                logger.info(f"[{filename}]   Deleted optimized file.")
        except FileNotFoundError:
            logger.warning(
                f"[{filename}]   Optimized file {optimized_path} not found during cleanup step. "
                "It might have been moved or deleted externally."
            )
        except Exception as e_cleanup:
            logger.error(
                f"[{filename}]   Error during optimized file cleanup for {optimized_path}: {e_cleanup}"
            )

        logger.debug(f"[{filename}] Replacement process completed successfully.")
        return True

    def _save_failed_optimized(self, original_path: Path, optimized_path: Path) -> bool:
        """
        Saves the optimized file with an '--after-squeeze' suffix when quality checks fail
        and keep_optimized is True. Leaves the original file untouched.

        Args:
            original_path: Path to the original file (used for naming).
            optimized_path: Path to the temporary optimized file that failed checks.

        Returns:
            True if saving was successful, False otherwise.
        """
        filename = original_path.name
        # If force_mp4 is enabled, use .mp4 extension for the after-squeeze file
        suffix = ".mp4" if self.force_mp4 else original_path.suffix
        after_squeeze_path = original_path.with_name(
            f"{original_path.stem}--after-squeeze{suffix}"
        )
        logger.info(
            f"[{filename}] Quality check failed, but keeping optimized file as: {after_squeeze_path}"
        )

        try:
            # Ensure the temporary optimized file exists before trying to rename
            if not optimized_path.exists():
                logger.error(
                    f"[{filename}] Cannot save failed optimized file: Temporary file {optimized_path} not found."
                )
                return False

            optimized_path.rename(after_squeeze_path)
            logger.debug(
                f"[{filename}] Successfully renamed {optimized_path} to {after_squeeze_path}"
            )
            return True
        except OSError as e:
            logger.error(
                f"[{filename}] Failed to rename temporary optimized file {optimized_path} to {after_squeeze_path}: {e}"
            )
            logger.warning(
                f"[{filename}] The failed optimized file may still exist at: {optimized_path}"
            )
            return False
        except Exception as e:
            logger.error(
                f"[{filename}] Unexpected error saving failed optimized file {optimized_path}: {e}",
                exc_info=self.verbose,
            )
            return False

    def _print_summary(self) -> None:
        optimized_count = len(self.results["optimized"])
        skipped_count = len(self.results["skipped"])
        failed_count = len(self.results["failed"])
        total_count = optimized_count + skipped_count + failed_count

        if total_count == 0:
            logger.warning(
                "No video files were processed or found matching criteria."
            )  # Removed Rich [yellow] tag
            return

        # Replaced Rich Panel with multi-line log messages. Removed Rich [bold cyan] etc.
        logger.info("VidSqueeze Summary")
        logger.info(f"  Optimized: {optimized_count}")
        logger.info(f"  Skipped:   {skipped_count}")
        logger.info(f"  Failed:    {failed_count}")
        logger.info("  ---------")
        logger.info(f"  Total:     {total_count}")

        if failed_count > 0:
            logger.warning(
                f"{failed_count} video(s) could not be processed. See details above."
            )
            if self.verbose or failed_count <= 10:
                logger.warning("Files that could not be processed:")
                for f in self.results["failed"]:
                    logger.warning(f"  - {f}")
            else:
                logger.warning(
                    f"Run with --verbose to see the list of {failed_count} files that could not be processed."
                )
            logger.warning(
                "Original videos were not modified. If you think this is a bug, try running with --verbose for more details."
            )
        if skipped_count > 0 and self.verbose:
            logger.debug(
                "Videos that were skipped (already optimal or failed quality checks):"
            )
            for f in self.results["skipped"]:
                logger.debug(f"  - {f}")

    def _analyze_video_mediainfo(self, video_path: Path) -> dict[str, Any] | None:
        """
        Extract video stream information using pymediainfo (faster than ffprobe).

        Args:
            video_path: Path to the video file.

        Returns:
            Dictionary containing key video properties (codec, dimensions, duration etc.),
            or None if analysis fails.
        """
        filename = video_path.name
        try:
            logger.debug(f"[{filename}] Attempting MediaInfo analysis.")
            media_info_obj = MediaInfo.parse(str(video_path))
            video_track = next(
                (t for t in media_info_obj.tracks if t.track_type == "Video"), None
            )

            if not video_track:
                logger.warning(f"[{filename}] MediaInfo: No video track found.")
                return None

            info = {
                CODEC_NAME_KEY: video_track.codec_id
                or video_track.format,  # Try to get a usable codec identifier
                WIDTH_KEY: int(video_track.width) if video_track.width else None,
                HEIGHT_KEY: int(video_track.height) if video_track.height else None,
                DURATION_KEY: float(video_track.duration) / 1000.0
                if video_track.duration
                else None,
                BIT_RATE_KEY: int(video_track.bit_rate)
                if video_track.bit_rate
                else None,
                AVG_FRAME_RATE_KEY: float(video_track.frame_rate)
                if video_track.frame_rate
                else None,
                # Frame count might be available but we'll skip it for minimal analysis
                # NB_FRAMES_KEY: int(video_track.frame_count) if video_track.frame_count else None,
            }

            # If no specific bit rate found in video track, try overall
            if info[BIT_RATE_KEY] is None:
                general_track = next(
                    (t for t in media_info_obj.tracks if t.track_type == "General"),
                    None,
                )
                if general_track and general_track.overall_bit_rate:
                    info[BIT_RATE_KEY] = int(general_track.overall_bit_rate)

            # Post-process codec name to match our expected format
            if isinstance(info[CODEC_NAME_KEY], str):
                codec_name = info[CODEC_NAME_KEY].lower()
                if "avc" in codec_name or "h264" in codec_name or "x264" in codec_name:
                    info[CODEC_NAME_KEY] = "h264"
                elif (
                    "hevc" in codec_name or "h265" in codec_name or "x265" in codec_name
                ):
                    info[CODEC_NAME_KEY] = "h265"
                elif "av1" in codec_name or "av01" in codec_name:
                    info[CODEC_NAME_KEY] = "av1"
                # Add more mappings as needed

            # Calculate bitrate from filesize and duration if still missing
            if (
                info[BIT_RATE_KEY] is None
                and info[DURATION_KEY]
                and info[DURATION_KEY] > 0
            ):
                try:
                    file_size = video_path.stat().st_size
                    info[BIT_RATE_KEY] = int((file_size * 8) / info[DURATION_KEY])
                    logger.debug(
                        f"[{filename}] MediaInfo: Calculated overall bitrate: {info[BIT_RATE_KEY] / 1e6:.2f} Mbps"
                    )
                except OSError:
                    logger.warning(
                        f"[{filename}] MediaInfo: Could not get file size to calculate bitrate."
                    )

            logger.debug(f"[{filename}] MediaInfo analysis successful: {info}")
            return info

        except Exception as e:
            logger.warning(
                f"[{filename}] MediaInfo analysis failed: {str(e)}. Falling back to ffprobe."
            )
            return None


# --- Configuration Loading ---


def load_config(config_path: str | None = None) -> dict[str, Any]:
    """
    Load configuration from a YAML file, merging it with defaults.

    Args:
        config_path: Optional path to a YAML configuration file.

    Returns:
        A configuration dictionary (defaults merged with user config).
    """
    config = DEFAULT_CONFIG.copy()  # Start with defaults
    if config_path:
        config_file = Path(config_path)
        if config_file.is_file():
            logger.debug(f"Attempting to load configuration from: {config_path}")
            try:
                with open(config_file, encoding="utf-8") as f:
                    user_config = yaml.safe_load(f)
                if user_config and isinstance(user_config, dict):
                    _merge_config(config, user_config)
                    logger.info(
                        f"Successfully loaded and merged config from {config_path}"
                    )
                elif user_config is None:
                    logger.warning(
                        f"Config file {config_path} is empty. Using defaults."
                    )
                else:
                    logger.warning(
                        f"Config file {config_path} does not contain a valid YAML dictionary. Using defaults."
                    )
            except yaml.YAMLError as e:
                logger.error(
                    f"Error parsing YAML config file {config_path}: {e}. Using defaults."
                )
            except OSError as e:
                logger.error(
                    f"Error reading config file {config_path}: {e}. Using defaults."
                )
            except Exception as e:
                logger.error(
                    f"Unexpected error loading config from {config_path}: {e}. Using defaults.",
                    exc_info=True,  # Show traceback for unexpected errors
                )
        else:
            logger.warning(
                f"Config file specified but not found or not a file: {config_path}. Using defaults."
            )
    else:
        logger.debug("No config file specified. Using default configuration.")
    return config


# --- CLI Interface ---


def vidsqueeze(
    input_path: str,
    safe: bool = False,
    keep_original: bool = False,
    keep_optimized: bool = False,
    keep_frames: bool = False,  # New flag
    codec: str | None = None,
    crf: int | None = None,
    preset: str | None = None,
    min_size_reduction: float | None = None,
    config_path: str | None = None,
    verbose: bool = False,
    try_all: bool = False,
    mse_threshold: float | None = None,  # Add MSE threshold parameter
    mp4: bool = False,  # New parameter to force MP4 container
    alt: bool = False,  # New parameter to use ffprobe instead of pymediainfo
) -> None:
    """
    Optimize videos by reducing file size while maintaining perceptual quality
    using frame count/content checks.

    Args:
        input_path: Path to a video file or directory containing videos.
        safe: If True (and keep_original=False), move original files to trash.
        keep_original: If True, keep the original file renamed with '--before-squeeze'. Overrides --safe.
        keep_optimized: If True, keep the optimized file with '--after-squeeze' suffix if not acceptable.
        keep_frames: If True, save extracted comparison frames to a subfolder named after the video.
        codec: Video codec to use ('h264', 'h265', 'av1'). Overrides config.
        crf: Constant Rate Factor (lower = better quality, larger file). Overrides config.
        preset: Encoding preset (e.g., 'medium', 'slow', '8'). Overrides config.
        min_size_reduction: Minimum fractional file size reduction (0.0 to 1.0) required (e.g., 0.1 for 10%). Overrides config.
        config_path: Path to a custom YAML configuration file.
        verbose: Enable verbose DEBUG logging, including FFmpeg command output.
        try_all: If True, attempt optimization even if video already uses the target codec.
        mse_threshold: Maximum allowed Mean Squared Error for frame comparison (default: 5.0)
        mp4: If True, force the output to use MP4 container format regardless of input format.
        alt: If True, use ffprobe instead of pymediainfo for analysis (slower but more compatible).

    Returns:
        Prints a dictionary with lists of 'optimized', 'skipped', and 'failed' video filenames
        via Fire. Exits with non-zero status on critical errors.
    """
    # Setup logging level based on verbose flag *before* loading config or initializing

    # Load configuration first
    config = load_config(config_path)

    # Display verbose mode status prominently
    if verbose:
        logger.info(
            "[bold cyan]VERBOSE MODE ENABLED[/bold cyan]: Detailed logging will be shown."
        )

    # Instantiate and run the optimizer
    optimizer = None  # Initialize optimizer to None
    try:
        optimizer = VideoOptimizer(
            config=config,
            codec=codec,
            crf=crf,
            preset=preset,
            min_size_reduction=min_size_reduction,
            safe=safe,
            keep_original=keep_original,
            verbose=verbose,
            try_all=try_all,
            keep_optimized=keep_optimized,
            keep_frames=keep_frames,  # Pass the new flag
            mse_threshold=mse_threshold,  # Pass the MSE threshold
            force_mp4=mp4,  # Pass the MP4 flag
            alt=alt,  # Pass the alternative analysis flag
        )

        # Extra verbose mode confirmation after initialization
        if verbose:
            logger.info(
                "[bold green]VideoOptimizer initialized with verbose logging[/bold green]"
            )
            logger.info(
                "[bold yellow]Watch for detailed frame comparison results during quality checks[/bold yellow]"
            )

        results = optimizer.optimize(input_path)
        # Fire automatically prints the returned dictionary 'results'
        # Check if any files failed and exit with status 1 if they did
        if results and results.get("failed"):
            sys.exit(1)
        # Exit normally otherwise

    except SystemExit as e:
        sys.exit(e.code if e.code is not None else 1)  # Propagate exit code
    except Exception as e:
        logger.critical(
            f"Unhandled exception during optimizer initialization or execution: {e}",
            exc_info=True,  # Always show traceback for critical unhandled exceptions
        )
        sys.exit(1)


def main():
    """CLI entry point using python-fire."""
    fire.Fire(vidsqueeze)


if __name__ == "__main__":
    main()
