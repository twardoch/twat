# img/ - Video & Image Processing Tools

A collection of CLI tools for video and image processing. All scripts are self-contained with inline dependencies via [PEP 723](https://peps.python.org/pep-0723/) - just run them directly with `uv`.

## Quick Start

```bash
# Run any script directly (uv handles dependencies automatically)
./vidcrop.py input.mp4 --help
./scanify.py image.png --help
```

## Scripts Overview

### Image Processing

| Script | Purpose |
|--------|---------|
| `imgpngop.sh` | Resize image to 1024px width, convert to PNG, optimize with pngquant+optipng |
| `scanify.py` | Add scanner-like effects (noise, vignette, color cast) to images |

### Video Dubbing (Audio Replacement)

Multiple implementations using different backends - choose based on what's installed:

| Script | Backend | Best For |
|--------|---------|----------|
| `viddub.sh` | ffmpeg CLI | Fastest, no Python overhead |
| `viddub-ffm.py` | ffmpeg-python | Pythonic API, better error handling |
| `viddub-m.py` | moviepy | High-level API, heavier deps |
| `viddub-av.py` | PyAV | Low-level, best for streaming |

### Video Cropping & Processing

| Script | Purpose |
|--------|---------|
| `vidcrop.py` | Advanced video cropping with black bar detection (full-featured) |
| `vidcrop1.py` | Simple video cropping |
| `vidcrop2.py` | Video cropping with subtitle detection |
| `vidmaskhalf.py` | Apply mask to half of video frame |
| `vidhwscale.py` | Hardware-accelerated video scaling |

### Video Timing & Speed

| Script | Purpose |
|--------|---------|
| `vidfps` | Change video FPS without re-encoding |
| `vidpredub.py` | Retime video to match audio duration |
| `vidinout.py` | Trim video with fade in/out effects |
| `vidframedrop.py` | Drop frames to reduce file size |

### Video Concatenation

| Script | Purpose |
|--------|---------|
| `vidglue` | Merge videos with seamless frame-matching transitions |
| `vidmergebygap.py` | Merge videos with gap detection and title cards |
| `vidmergebygap1.py` | Simpler version of vidmergebygap |
| `vid3split.py` | Split video into 3 equal parts |

### Video Effects

| Script | Purpose |
|--------|---------|
| `vidkenburns.py` | Create Ken Burns slideshow from images |
| `vidreverb.py` | Add reverb/audio effects to video |
| `vidgrainer.py` | Add film grain effect |
| `vidhalfsharpen.sh` | Sharpen half of video frame |

### Video Analysis & Utilities

| Script | Purpose |
|--------|---------|
| `vidstartendframe.sh` | Extract first and last frame as PNG |
| `vidrenmatch.py` | Rename videos to match reference files |
| `vidmenubar.py` | Add macOS-style menu bar overlay |
| `vidimportaudio` | Import audio track into video |

### Batch Processing

Scripts ending in `all` process entire directories:

| Script | Processes |
|--------|-----------|
| `vidfpsall.sh` | Run vidfps on all videos in directory |
| `vidstartendframeall.sh` | Extract frames from all videos |
| `vidhalfsharpenall.sh` | Sharpen all videos |
| `vidren2jpgall` | Rename and extract frames from all videos |
| `vidsqueeze.sh` | Compress all videos |

## Common Patterns

### All Python scripts use:
- `fire` for CLI argument parsing
- `rich` for pretty output
- `loguru` for logging (with `--verbose` flag)

### All shell scripts have:
- `set -euo pipefail` for fail-fast behavior
- `this_file` markers for easy navigation

## Requirements

- [uv](https://github.com/astral-sh/uv) - Python package manager (handles all deps automatically)
- `ffmpeg` - Most scripts require ffmpeg in PATH
- `fd` - Batch scripts use fd for file discovery

## Installation

No installation needed! Scripts are self-contained. Just ensure `uv` and `ffmpeg` are available:

```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install ffmpeg (macOS)
brew install ffmpeg fd
```
