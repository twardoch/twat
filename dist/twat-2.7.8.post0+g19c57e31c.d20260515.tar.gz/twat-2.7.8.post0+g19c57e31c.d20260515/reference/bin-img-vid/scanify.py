#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["pillow", "numpy", "fire", "rich"]
# ///
# this_file: scanify.py

"""
Scanify: Make images look like they were printed and re-scanned.

Applies randomized distortions to simulate the print-scan process:
- Geometric: slight rotation (imperfect document placement)
- Optical: blur, noise, brightness/contrast shifts
- Compression: JPEG artifacts
- Color: subtle warm/cool cast from scanner/paper
"""

import random
from pathlib import Path
from typing import Optional, Tuple

import fire
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from rich import print as rprint


def add_gaussian_noise(image: Image.Image, sigma: float) -> Image.Image:
    """
    Add Gaussian noise to simulate scanner sensor noise.

    Args:
        image: PIL Image in RGB mode
        sigma: Standard deviation of noise (typically 2-5)

    Returns:
        Noisy image
    """
    img_array = np.array(image, dtype=np.float32)
    noise = np.random.normal(0, sigma, img_array.shape)
    noisy = np.clip(img_array + noise, 0, 255).astype(np.uint8)
    return Image.fromarray(noisy)


def add_color_cast(image: Image.Image, strength: float) -> Image.Image:
    """
    Add subtle color cast (warm/cool tint) from scanner light or paper yellowing.

    Args:
        image: PIL Image in RGB mode
        strength: Cast intensity (0.0 to 0.1, typically 0.01-0.03)

    Returns:
        Image with color cast
    """
    if strength <= 0:
        return image

    img_array = np.array(image, dtype=np.float32)

    # Randomly choose warm (reddish/yellowish) or cool (bluish) cast
    if random.choice([True, False]):
        # Warm cast (paper yellowing, warm scanner light)
        cast = np.array([strength * 255, strength * 255 * 0.6, 0])
    else:
        # Cool cast (fluorescent scanner light)
        cast = np.array([0, strength * 255 * 0.5, strength * 255])

    casted = np.clip(img_array + cast, 0, 255).astype(np.uint8)
    return Image.fromarray(casted)


def add_vignette(image: Image.Image, strength: float = 0.1) -> Image.Image:
    """
    Add subtle vignetting (darkening at edges) from scanner optics.

    Args:
        image: PIL Image in RGB mode
        strength: Vignette strength (0.0 to 0.3)

    Returns:
        Image with vignette
    """
    if strength <= 0:
        return image

    img_array = np.array(image, dtype=np.float32)
    h, w = img_array.shape[:2]

    # Create radial gradient mask
    y, x = np.ogrid[:h, :w]
    center_y, center_x = h / 2, w / 2

    # Distance from center, normalized
    dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
    max_dist = np.sqrt(center_x**2 + center_y**2)
    dist_normalized = dist / max_dist

    # Vignette mask (1.0 at center, reduced at edges)
    vignette_mask = 1 - (dist_normalized * strength)
    vignette_mask = np.clip(vignette_mask, 1 - strength, 1)

    # Apply vignette
    if len(img_array.shape) == 3:  # RGB
        vignette_mask = vignette_mask[:, :, np.newaxis]

    vignetted = np.clip(img_array * vignette_mask, 0, 255).astype(np.uint8)
    return Image.fromarray(vignetted)


def generate_variant_params(base_ranges: dict, variant_idx: int) -> dict:
    """
    Generate varied parameters for a mix variant.

    Creates non-uniform degradation by randomly emphasizing different effects.
    Some variants will have strong blur but weak noise, others vice versa, etc.

    Args:
        base_ranges: Dict with base parameter ranges
        variant_idx: Variant number for seeding variation patterns

    Returns:
        Dict with randomized parameter ranges for this variant
    """
    # Use variant index to create different "profiles"
    rng = random.Random(variant_idx * 1000)

    # Randomly choose which effects to emphasize (non-uniform degradation)
    profiles = [
        # Profile 0: Heavy rotation & blur
        {
            'rotation': (-3.5, 3.5),
            'blur': (1.0, 2.5),
            'noise': (1.0, 2.5),
            'quality': (80, 90),
            'cast': 0.01,
            'vignette': 0.05,
        },
        # Profile 1: Heavy noise & low quality
        {
            'rotation': (-0.8, 0.8),
            'blur': (0.2, 0.6),
            'noise': (5.0, 9.0),
            'quality': (65, 80),
            'cast': 0.015,
            'vignette': 0.03,
        },
        # Profile 2: Strong color cast & vignette
        {
            'rotation': (-1.2, 1.2),
            'blur': (0.4, 1.0),
            'noise': (2.0, 4.0),
            'quality': (85, 92),
            'cast': 0.06,
            'vignette': 0.20,
        },
        # Profile 3: Minimal effects (subtle)
        {
            'rotation': (-0.3, 0.3),
            'blur': (0.1, 0.4),
            'noise': (0.5, 1.5),
            'quality': (90, 98),
            'cast': 0.005,
            'vignette': 0.02,
        },
        # Profile 4: Extreme blur (out of focus)
        {
            'rotation': (-2.0, 2.0),
            'blur': (2.0, 4.0),
            'noise': (1.5, 3.5),
            'quality': (75, 88),
            'cast': 0.025,
            'vignette': 0.12,
        },
        # Profile 5: Heavy compression artifacts
        {
            'rotation': (-1.0, 1.0),
            'blur': (0.3, 0.9),
            'noise': (2.5, 5.0),
            'quality': (55, 75),
            'cast': 0.02,
            'vignette': 0.06,
        },
        # Profile 6: Balanced degradation (default-like but varied)
        {
            'rotation': (-2.2, 2.2),
            'blur': (0.5, 1.5),
            'noise': (3.0, 6.0),
            'quality': (78, 90),
            'cast': 0.03,
            'vignette': 0.10,
        },
    ]

    # Pick a profile with some randomness
    profile = rng.choice(profiles)

    # Add some random variation to the profile itself
    def vary_range(r: Tuple[float, float], factor: float = 0.3) -> Tuple[float, float]:
        """Add ±factor variation to a range."""
        mid = (r[0] + r[1]) / 2
        spread = (r[1] - r[0]) / 2
        new_spread = spread * rng.uniform(1 - factor, 1 + factor)
        return (mid - new_spread, mid + new_spread)

    # Apply variation to make each variant unique even within same profile
    result = {
        'rotation': vary_range(profile['rotation'], 0.4),
        'blur': vary_range(profile['blur'], 0.3),
        'noise': vary_range(profile['noise'], 0.3),
        'quality': (
            max(50, int(profile['quality'][0] + rng.uniform(-10, 5))),
            min(100, int(profile['quality'][1] + rng.uniform(-5, 5)))
        ),
        'cast': max(0, profile['cast'] * rng.uniform(0.7, 1.5)),
        'vignette': max(0, profile['vignette'] * rng.uniform(0.7, 1.5)),
        'brightness': (0.90, 1.10),  # Wider range for variety
        'contrast': (0.90, 1.10),
    }

    return result


def process_image(
    img: Image.Image,
    rotation: Tuple[float, float],
    blur: Tuple[float, float],
    noise: Tuple[float, float],
    brightness: Tuple[float, float],
    contrast: Tuple[float, float],
    quality: Tuple[int, int],
    cast: float,
    vignette: float,
    verbose: bool = True,
) -> Tuple[Image.Image, int]:
    """
    Process a single image with scan effects.

    Returns:
        Tuple of (processed image, jpeg quality used)
    """
    # 1. Random rotation (document not perfectly aligned on scanner bed)
    angle = random.uniform(*rotation)
    if verbose:
        rprint(f"[green]  ↻ Rotating: {angle:+.2f}°[/green]")
    img = img.rotate(
        angle,
        expand=True,  # Expand canvas to avoid cropping
        fillcolor='white',  # Paper background
        resample=Image.BICUBIC
    )

    # 2. Slight blur (scanner optics, slight defocus)
    blur_radius = random.uniform(*blur)
    if verbose:
        rprint(f"[green]  ⊙ Blurring: radius={blur_radius:.2f}[/green]")
    img = img.filter(ImageFilter.GaussianBlur(blur_radius))

    # 3. Add sensor noise
    noise_sigma = random.uniform(*noise)
    if verbose:
        rprint(f"[green]  ⊛ Adding noise: σ={noise_sigma:.2f}[/green]")
    img = add_gaussian_noise(img, noise_sigma)

    # 4. Brightness variation (scanner light intensity)
    brightness_factor = random.uniform(*brightness)
    if verbose:
        rprint(f"[green]  ◐ Brightness: {brightness_factor:.3f}×[/green]")
    enhancer = ImageEnhance.Brightness(img)
    img = enhancer.enhance(brightness_factor)

    # 5. Contrast variation (scanner sensor response)
    contrast_factor = random.uniform(*contrast)
    if verbose:
        rprint(f"[green]  ◑ Contrast: {contrast_factor:.3f}×[/green]")
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(contrast_factor)

    # 6. Color cast (paper tint, scanner light color temperature)
    if cast > 0:
        if verbose:
            rprint(f"[green]  ◨ Color cast: {cast:.3f}[/green]")
        img = add_color_cast(img, cast)

    # 7. Vignetting (scanner optics, light falloff at edges)
    if vignette > 0:
        if verbose:
            rprint(f"[green]  ◉ Vignette: {vignette:.3f}[/green]")
        img = add_vignette(img, vignette)

    # 8. JPEG compression (compression artifacts from scan-to-file)
    jpeg_quality = random.randint(*quality)
    if verbose:
        rprint(f"[green]  ⊞ JPEG quality: {jpeg_quality}[/green]")

    return img, jpeg_quality


def scanify(
    input: str,
    output: Optional[str] = None,
    rotation: Tuple[float, float] = (-1.8, 1.8),
    blur: Tuple[float, float] = (0.3, 0.8),
    noise: Tuple[float, float] = (2.0, 4.5),
    brightness: Tuple[float, float] = (0.95, 1.05),
    contrast: Tuple[float, float] = (0.95, 1.05),
    quality: Tuple[int, int] = (85, 95),
    cast: float = 0.02,
    vignette: float = 0.08,
    mix: Optional[int] = None,
    seed: Optional[int] = None,
) -> None:
    """
    Transform an image to look like it was printed and re-scanned.

    Args:
        input: Path to input image
        output: Path to output image (default: adds '-scan' suffix)
        rotation: Min/max rotation in degrees (default: ±1.8°)
        blur: Min/max Gaussian blur radius (default: 0.3-0.8)
        noise: Min/max noise intensity/sigma (default: 2.0-4.5)
        brightness: Min/max brightness factor (default: 0.95-1.05)
        contrast: Min/max contrast factor (default: 0.95-1.05)
        quality: Min/max JPEG quality (default: 85-95)
        cast: Color cast strength, 0 to disable (default: 0.02)
        vignette: Vignette strength, 0 to disable (default: 0.08)
        mix: Create N variants with varied settings (default: None/disabled)
        seed: Random seed for reproducibility (optional)

    Examples:
        scanify.py --input document.png
        scanify.py --input photo.jpg --output scanned.jpg
        scanify.py --input test.png --mix 5
        scanify.py --input test.png --rotation=-0.5,0.5 --noise=1,2
        scanify.py --input doc.pdf.png --seed=42
        scanify.py --input batch.png --mix 20
    """
    # Set random seed if provided
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    input_path = Path(input)

    if not input_path.exists():
        rprint(f"[red]✗ Error: Input file not found: {input}[/red]")
        return

    rprint(f"[cyan]◉ Loading: {input_path}[/cyan]")

    try:
        img_original = Image.open(input_path)
    except Exception as e:
        rprint(f"[red]✗ Error loading image: {e}[/red]")
        return

    # Convert to RGB (handle RGBA, grayscale, palette, etc.)
    if img_original.mode != 'RGB':
        rprint(f"[yellow]  Converting from {img_original.mode} to RGB[/yellow]")
        if img_original.mode == 'RGBA':
            # Composite onto white background
            background = Image.new('RGB', img_original.size, 'white')
            background.paste(img_original, mask=img_original.split()[3])
            img_original = background
        else:
            img_original = img_original.convert('RGB')

    # Store original size for reference
    original_size = img_original.size
    rprint(f"[dim]  Size: {original_size[0]}×{original_size[1]}[/dim]")

    # Handle mix mode: create multiple variants
    if mix is not None and mix > 0:
        if output is not None:
            rprint(f"[yellow]⚠ Warning: --output ignored in --mix mode[/yellow]")

        rprint(f"[cyan]◉ Creating {mix} variants with varied settings[/cyan]\n")

        base_ranges = {
            'rotation': rotation,
            'blur': blur,
            'noise': noise,
            'brightness': brightness,
            'contrast': contrast,
            'quality': quality,
            'cast': cast,
            'vignette': vignette,
        }

        for i in range(mix):
            # Generate variant-specific parameters
            variant_params = generate_variant_params(base_ranges, i)

            # Create unique output path
            output_path = input_path.with_stem(f"{input_path.stem}-scan-{i+1:03d}")
            output_path = output_path.with_suffix('.jpg')

            rprint(f"[cyan]▸ Variant {i+1}/{mix}:[/cyan]")

            # Process with fresh copy of original
            img = img_original.copy()
            img, jpeg_quality = process_image(
                img,
                rotation=variant_params['rotation'],
                blur=variant_params['blur'],
                noise=variant_params['noise'],
                brightness=variant_params['brightness'],
                contrast=variant_params['contrast'],
                quality=variant_params['quality'],
                cast=variant_params['cast'],
                vignette=variant_params['vignette'],
                verbose=True,
            )

            # Ensure output directory exists
            output_path.parent.mkdir(parents=True, exist_ok=True)

            # Save
            try:
                img.save(output_path, 'JPEG', quality=jpeg_quality, optimize=True)
                file_size = output_path.stat().st_size / 1024  # KB
                rprint(f"[cyan]✓ Saved: {output_path.name} ({file_size:.1f} KB)[/cyan]\n")
            except Exception as e:
                rprint(f"[red]✗ Error saving variant {i+1}: {e}[/red]\n")
                continue

        rprint(f"[cyan]✓ Created {mix} variants[/cyan]")
        return

    # Single image mode
    if output is None:
        output_path = input_path.with_stem(f"{input_path.stem}-scan")
        output_path = output_path.with_suffix('.jpg')
    else:
        output_path = Path(output)

    img, jpeg_quality = process_image(
        img_original,
        rotation=rotation,
        blur=blur,
        noise=noise,
        brightness=brightness,
        contrast=contrast,
        quality=quality,
        cast=cast,
        vignette=vignette,
        verbose=True,
    )

    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Save with JPEG compression
    try:
        img.save(output_path, 'JPEG', quality=jpeg_quality, optimize=True)
        file_size = output_path.stat().st_size / 1024  # KB
        rprint(f"[cyan]✓ Saved: {output_path} ({file_size:.1f} KB)[/cyan]")
    except Exception as e:
        rprint(f"[red]✗ Error saving image: {e}[/red]")
        return


def main():
    """CLI entry point."""
    fire.Fire(scanify)


if __name__ == '__main__':
    main()
