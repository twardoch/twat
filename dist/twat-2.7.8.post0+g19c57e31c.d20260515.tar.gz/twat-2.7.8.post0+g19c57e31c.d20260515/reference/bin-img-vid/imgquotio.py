#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire>=0.6", "openai>=1.50", "python-slugify>=8", "rich>=13", "httpx>=0.27"]
# ///
# this_file: imgquotio.py

from __future__ import annotations

import base64
import contextlib
import mimetypes
import os
import sys
import traceback
from pathlib import Path

import fire
import httpx
import openai
from rich.console import Console
from slugify import slugify

console = Console()

_MODEL_ALIASES = {
    "gpt": "gpt-image-2",
    "nano": "gemini-3.1-flash-image",
}


def _resolve_model(model: str) -> str:
    return _MODEL_ALIASES.get(model, model)


def _uses_chat_completions(resolved_model: str) -> bool:
    """True for models the CLIPROXY exposes only via /v1/chat/completions
    (Gemini image models return images in choices[].message.images[]).
    """
    return not resolved_model.startswith("gpt-image")


def _encode_image_data_url(path: str) -> str:
    p = Path(path)
    mime = mimetypes.guess_type(p.name)[0] or "image/png"
    b64 = base64.b64encode(p.read_bytes()).decode()
    return f"data:{mime};base64,{b64}"


def _decode_image_url(url: str) -> bytes:
    if url.startswith("data:"):
        _, _, payload = url.partition(",")
        return base64.b64decode(payload)
    return httpx.get(url, timeout=60).content


def _pick_extension(data: bytes, output_format: str | None) -> str:
    if output_format:
        return f".{output_format.lstrip('.')}"
    if data[:4] == b"\x89PNG":
        return ".png"
    if data[:3] == b"\xff\xd8\xff":
        return ".jpeg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return ".png"


def _default_output_name(prompt: str) -> str:
    slug = slugify(prompt, max_length=60, word_boundary=True, save_order=True)
    segments = slug.split("-")[:6]
    return "-".join(segments)


def _write_bytes(
    data: bytes,
    output: str | None,
    index: int,
    n: int,
    prompt: str,
    output_format: str | None,
) -> Path:
    ext = _pick_extension(data, output_format)

    if output is not None:
        out_path = Path(output)
        if n > 1:
            out_path = out_path.with_stem(f"{out_path.stem}-{index}")
    else:
        base = _default_output_name(prompt)
        name = f"{base}-{index}{ext}" if n > 1 else f"{base}{ext}"
        out_path = Path.cwd() / name

    out_path.write_bytes(data)
    return out_path


def _write_image(
    img,
    output: str | None,
    index: int,
    n: int,
    prompt: str,
    output_format: str | None,
) -> Path:
    if img.b64_json:
        data = base64.b64decode(img.b64_json)
    elif img.url:
        data = httpx.get(img.url, timeout=60).content
    else:
        raise ValueError("Image response has neither b64_json nor url")
    return _write_bytes(data, output, index, n, prompt, output_format)


def cli(
    prompt: str,
    input: str | list | None = None,
    mask: str | None = None,
    output: str | None = None,
    model: str = "gpt",
    n: int = 1,
    size: str | None = None,
    quality: str | None = None,
    response_format: str | None = None,
    output_format: str | None = None,
    output_compression: int | None = None,
    background: str | None = None,
    moderation: str | None = None,
    style: str | None = None,
    user: str | None = None,
    verbose: bool = False,
) -> None:
    """Generate or edit an image via a local OpenAI-compatible CLIPROXY.

    Routing depends on the resolved model:
      - gpt-image-* → /v1/images/generations (no --input) or /v1/images/edits.
      - everything else (e.g. nano / gemini-3.1-flash-image) →
        /v1/chat/completions with text + optional image_url parts; the
        generated image is read from choices[].message.images[].image_url.url.
    Reads CLIPROXY_API_ENDPOINT and CLIPROXY_API_KEY from the environment
    (with sensible Quotio defaults).

    Examples:
        imgquotio.py "two polish medieval warriors"
        imgquotio.py "make it night" --input photo.png
        imgquotio.py "a dragon" --model nano --size 1024x1024 -n 2
        imgquotio.py "blend these" --input '["a.png","b.png"]' --output mix.png

    Args:
        prompt: Text prompt describing the image (or the edit). Required.
        input: Path to an input image, or a list of paths for multi-image edits
            (gpt-image-* only). Presence switches the call to images.edit.
        mask: Optional PNG mask path with transparency marking the edit region.
            Only meaningful for dall-e-2 edits; gpt-image-* infers regions from
            the prompt.
        output: Output file path. If omitted, a slugified prefix of the prompt
            is used in the current directory; for n>1, '-1', '-2', ... are
            appended before the extension.
        model: Model name or alias. 'gpt' -> gpt-image-2, 'nano' ->
            gemini-3.1-flash-image. Any other value is passed through unchanged.
        n: Number of images to generate (1-10 depending on model).
        size: Output dimensions, e.g. '1024x1024', '1024x1536', '1536x1024',
            or 'auto' for gpt-image-*. DALL-E 3 supports portrait/landscape
            variants only.
        quality: 'low' | 'medium' | 'high' | 'auto' for gpt-image-*;
            'standard' | 'hd' for dall-e-3.
        response_format: 'b64_json' or 'url'. Leave unset to let the model
            decide; gpt-image-* always returns b64_json regardless.
        output_format: 'png' | 'webp' | 'jpeg' (gpt-image-* only). Also drives
            the output filename extension when chosen.
        output_compression: 0-100 quality for jpeg/webp output (gpt-image-*).
        background: 'opaque' | 'auto' (gpt-image-2). Note: gpt-image-2 does
            not support transparent backgrounds.
        moderation: 'auto' | 'low' (gpt-image-*).
        style: 'vivid' | 'natural' (dall-e-3 only).
        user: Optional end-user identifier forwarded to the upstream API.
        verbose: Print resolved endpoint, model, kwargs, and full tracebacks
            on error.
    """
    endpoint = os.environ.get("CLIPROXY_API_ENDPOINT", "http://0.0.0.0:18317/v1")
    api_key = os.environ.get(
        "CLIPROXY_API_KEY", "quotio-local-1BD64D2D-C5BF-4496-9A71-9D61DC823DC2"
    )

    client = openai.OpenAI(base_url=endpoint, api_key=api_key, timeout=120.0)
    resolved_model = _resolve_model(model)

    kwargs: dict = {}
    for k, v in [
        ("n", n),
        ("size", size),
        ("quality", quality),
        ("response_format", response_format),
        ("output_format", output_format),
        ("output_compression", output_compression),
        ("background", background),
        ("moderation", moderation),
        ("style", style),
        ("user", user),
    ]:
        if v is not None:
            kwargs[k] = v

    if verbose:
        safe_kwargs = {**kwargs}
        console.print(f"[dim]Endpoint:[/dim] {endpoint}")
        console.print(f"[dim]Model:[/dim] {resolved_model}")
        console.print(f"[dim]Kwargs:[/dim] {safe_kwargs}")

    try:
        with console.status(
            f"[cyan]Calling {resolved_model}…[/cyan]", spinner="dots"
        ):
            if _uses_chat_completions(resolved_model):
                paths = (
                    []
                    if input is None
                    else ([input] if isinstance(input, str) else list(input))
                )
                content_parts: list[dict] = [{"type": "text", "text": prompt}]
                for p in paths:
                    content_parts.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": _encode_image_data_url(p)},
                        }
                    )
                if mask is not None:
                    console.print(
                        "[yellow]Warning:[/yellow] --mask is ignored for "
                        f"{resolved_model} (chat-completions image model)."
                    )
                chat_kwargs: dict = {}
                if n != 1:
                    chat_kwargs["n"] = n
                if user is not None:
                    chat_kwargs["user"] = user
                ignored = {
                    k: v
                    for k, v in kwargs.items()
                    if k
                    not in {"n", "user"}
                }
                if ignored and verbose:
                    console.print(
                        f"[yellow]Ignored (not supported on chat API):[/yellow] {ignored}"
                    )
                messages: list = [{"role": "user", "content": content_parts}]
                chat_response = client.chat.completions.create(
                    model=resolved_model,
                    messages=messages,  # type: ignore[arg-type]
                    **chat_kwargs,
                )
                payload = chat_response.model_dump()
                urls: list[str] = []
                for choice in payload.get("choices") or []:
                    msg = choice.get("message") or {}
                    for img in msg.get("images") or []:
                        url = ((img or {}).get("image_url") or {}).get("url")
                        if url:
                            urls.append(url)
                if not urls:
                    text = ""
                    if payload.get("choices"):
                        text = (payload["choices"][0].get("message") or {}).get(
                            "content"
                        ) or ""
                    raise RuntimeError(
                        f"No images returned by {resolved_model}. "
                        f"Model said: {text!r}"
                    )
                total = len(urls)
                for i, url in enumerate(urls, start=1):
                    data = _decode_image_url(url)
                    out = _write_bytes(
                        data, output, i, total, prompt, output_format
                    )
                    console.print(f"[green]Saved:[/green] {out}")
                return

            if input is None:
                response = client.images.generate(
                    model=resolved_model, prompt=prompt, **kwargs
                )
            else:
                paths = [input] if isinstance(input, str) else list(input)
                stack = contextlib.ExitStack()
                try:
                    handles = [stack.enter_context(open(p, "rb")) for p in paths]
                    img_arg = handles[0] if len(handles) == 1 else handles
                    edit_kwargs = {**kwargs}
                    if mask is not None:
                        edit_kwargs["mask"] = stack.enter_context(open(mask, "rb"))
                    response = client.images.edit(
                        model=resolved_model,
                        image=img_arg,
                        prompt=prompt,
                        **edit_kwargs,
                    )
                finally:
                    stack.close()

    except openai.AuthenticationError as exc:
        console.print(f"[bold red]Authentication error:[/bold red] {exc.message}")
        if verbose:
            traceback.print_exc()
        sys.exit(1)
    except openai.APIConnectionError as exc:
        console.print(f"[bold red]Connection error:[/bold red] {exc}")
        if verbose:
            traceback.print_exc()
        sys.exit(1)
    except openai.APIStatusError as exc:
        console.print(
            f"[bold red]API error {exc.status_code}:[/bold red] {exc.message}"
        )
        if verbose:
            traceback.print_exc()
        sys.exit(1)

    for i, img in enumerate(response.data, start=1):
        out = _write_image(img, output, i, n, prompt, output_format)
        console.print(f"[green]Saved:[/green] {out}")


if __name__ == "__main__":
    fire.Fire(cli)
