#!/usr/bin/env bash
# this_file: vidmp4to5my.sh
set -euo pipefail
cd "$(dirname "$0")"
LOG="$(dirname "$0")/vidmp4to5.json"
if [[ ! -f "$LOG" ]]; then
    ./vidmp4to5.py plan "/Users/adam" "/Volumes/Falstaff4T" "/Volumes/Puck4T-Data/Puck4T-Data2" "/Volumes/Puck4T-Bak" "/Volumes/NymSD2TB" "/Volumes/Sea4T5data" "/Volumes/Sea4T1/_EXTRA" "$@"
else
    echo "Resuming from existing plan: $LOG"
fi
./vidmp4to5.py convert
echo "DONE!"

