# vidsqueeze.md

# VidSqueeze Improvement Plan

This document outlines a plan to enhance the `vidsqueeze.py` script, focusing on performance, robustness, and maintainability.

## 1. Address Linter Errors and Improve Type Safety

The current script has several linter errors, primarily related to missing type stubs and incorrect type inferences.

**Action Items:**

*   **Install Type Stubs:**
    *   For `ffmpeg-python`, `fire`, `send2trash`, and `opencv-python` (cv2), try to find and install corresponding type stubs (e.g., `pip install types-ffmpeg-python types-fire opencv-python-headless`). If stubs are unavailable, consider adding them to a `py.typed` file or using `# type: ignore` judiciously with comments explaining why.
    *   **Code Suggestion (shell command):**
        ```bash
        uv pip install types-ffmpeg-python types-fire types-send2trash types-opencv-python
        # Or for specific ones if some don't exist:
        # uv pip install opencv-python-headless # (often includes stubs)
        ```

*   **Fix Configuration Access Type Errors:**
    *   The errors `Value of type "Any | Collection[str]" is not indexable` and `Item "Collection[str]" of "Any | Collection[str]" has no attribute "copy"` suggest that the type hinting for `self.config` and its nested structures is not precise enough or the access patterns are problematic.
    *   **Strategy:** Define `TypedDict` or `dataclasses` for the configuration structure. This will provide better type checking and autocompletion.
    *   **Code Suggestion (Conceptual - to be integrated into the class):**
        ```python
        from typing import TypedDict, List, Dict

        class CodecSettings(TypedDict):
            lib: str
            crf: int
            preset: str # Or int for AV1

        class OptimizationHeuristics(TypedDict):
            min_size_reduction_percent: float
            min_file_size_mb: int
            high_bitrate_threshold_mbps: float
            frame_count_tolerance: int
            frame_comparison_mse_threshold: float
            skip_first_frame_comparison: bool
            flexible_frame_matching: bool
            min_size_reduction_fraction: float # Added during init

        class VidSqueezeConfig(TypedDict):
            video_extensions: List[str]
            codec_settings: Dict[str, CodecSettings]
            default_codec: str
            audio_codec: str
            optimization_heuristics: OptimizationHeuristics

        # In VideoOptimizer.__init__:
        # self.config: VidSqueezeConfig = config if config else DEFAULT_CONFIG.copy() # Adjust casting/copying
        # Ensure DEFAULT_CONFIG matches this structure.
        # When accessing:
        # self.codec_info = self.config["codec_settings"][codec_key].copy() # Should now be correctly typed
        # self.optimization = self.config["optimization_heuristics"].copy()
        ```
    *   This will involve updating `DEFAULT_CONFIG` to conform to these types and ensuring `_merge_config` handles these typed dictionaries correctly.

*   **Fix `cv2` Member Errors:**
    *   Errors like `Module 'cv2' has no 'imread' member` usually mean type stubs are missing or incorrect, or there's an issue with the `cv2` import itself (e.g. using `opencv-python-headless` which is generally preferred for server-side/headless environments vs full `opencv-python`).
    *   **Action:** Ensure `opencv-python-headless` is used and stubs are present. If errors persist, verify function names and usage against OpenCV documentation. Add `# type: ignore[attr-defined]` as a last resort if the code is known to be correct but the linter is confused.

## 2. Further Optimize Video Analysis

While the tiered approach for `ffprobe` is a good step, we can explore further.

**Action Items:**

*   **Consider `pymediainfo` for Minimal Analysis:**
    *   As discussed, `pymediainfo` can be faster than `ffprobe` for extracting basic metadata.
    *   **Strategy:** Implement `_analyze_video_mediainfo` and use it as the primary method in `_analyze_video_minimal`. Fall back to the current `ffprobe`-based minimal analysis if `pymediainfo` fails or is not available.
    *   Add `pymediainfo` to dependencies.
    *   **Code Suggestion (New method in `VideoOptimizer`):**
        ```python
        # Add 'pymediainfo' to script dependencies
        # import atexit
        # from pymediainfo import MediaInfo
        # MediaInfo.trace_settings() # For debugging pymediainfo if issues arise
        # atexit.register(MediaInfo.close_library) # Ensure MediaInfo library is closed on exit


        def _analyze_video_mediainfo(self, video_path: Path) -> dict[str, Any] | None:
            filename = video_path.name
            try:
                logger.debug(f"[{filename}] Attempting MediaInfo analysis.")
                media_info_obj = MediaInfo.parse(str(video_path))
                video_track = next((t for t in media_info_obj.tracks if t.track_type == 'Video'), None)

                if not video_track:
                    logger.warning(f"[{filename}] MediaInfo: No video track found.")
                    return None

                info = {
                    CODEC_NAME_KEY: video_track.codec_id or video_track.format, # Try to get a usable codec identifier
                    WIDTH_KEY: video_track.width,
                    HEIGHT_KEY: video_track.height,
                    DURATION_KEY: float(video_track.duration) / 1000.0 if video_track.duration else None,
                    BIT_RATE_KEY: int(video_track.overall_bit_rate) if video_track.overall_bit_rate else (int(video_track.bit_rate) if video_track.bit_rate else None),
                    AVG_FRAME_RATE_KEY: float(video_track.frame_rate) if video_track.frame_rate else None,
                    # NB_FRAMES_KEY: int(video_track.frame_count) if video_track.frame_count else None, # MediaInfo often provides this
                }
                # Post-process codec name if needed (e.g., 'V_MPEG4/ISO/AVC' -> 'h264')
                # This might require a mapping similar to CODEC_NAMES or more robust parsing.
                if isinstance(info[CODEC_NAME_KEY], str):
                    if 'avc' in info[CODEC_NAME_KEY].lower() or 'x264' in info[CODEC_NAME_KEY].lower():
                        info[CODEC_NAME_KEY] = 'h264'
                    elif 'hevc' in info[CODEC_NAME_KEY].lower() or 'x265' in info[CODEC_NAME_KEY].lower():
                        info[CODEC_NAME_KEY] = 'h265'
                    elif 'av01' in info[CODEC_NAME_KEY].lower(): # AV1 codec ID often av01
                         info[CODEC_NAME_KEY] = 'av1'
                    # Add more mappings as needed

                logger.debug(f"[{filename}] MediaInfo analysis successful: {info}")
                return info
            except Exception as e:
                logger.warning(f"[{filename}] MediaInfo analysis failed: {str(e)}. Falling back.")
                return None

        # In _analyze_video_minimal:
        # mediainfo_result = self._analyze_video_mediainfo(video_path)
        # if mediainfo_result:
        #     return mediainfo_result
        # # Else, continue with ffprobe minimal analysis
        ```

*   **Refine `_analyze_video` (full analysis):**
    *   Ensure the fallback calculation for `NB_FRAMES_KEY` (duration * fps) is robust and clearly logged when used.
    *   Currently, `_analyze_video` (the full version) is called by `_check_frame_consistency` for both original and compressed files if frame counts are missing. This is correct.

## 3. Enhance Frame Comparison Logic

The `_check_frame_consistency` method is complex and critical for quality assurance.

**Action Items:**

*   **Review `skip_first_frame_comparison` and `flexible_frame_matching`:**
    *   The current logic for these flags is a bit convoluted. Simplify the conditions under which a comparison passes.
    *   **Consideration:** If `flexible_frame_matching` is on, and *any* valid pairing of first/second frames (orig 0/1 vs. comp 0/1) passes, the "first frame" part of the check should pass.
    *   The `skip_first_frame_comparison` should cleanly override any first-frame failures if other frames pass.

*   **Clarity on Frame Indices:**
    *   The calculation of `start_indices` and `end_indices` seems correct. Add comments to explain the logic for `FRAME_END_OFFSET`.

*   **Diff Image Generation:**
    *   The `cv2.absdiff` and exaggeration for diff images is good for `keep_frames`. Ensure it handles cases where frames might have different dimensions (though `_verify_metadata` should catch this earlier). If frames can have different channels (e.g. BGR vs BGRA), `calculate_mse` and `absdiff` might need adjustment or error handling.

## 4. Improve Code Structure and Readability

**Action Items:**

*   **Method Length:**
    *   `_check_frame_consistency` is very long. Consider breaking it down into smaller helper methods, e.g.:
        *   `_get_required_frame_counts(orig_path, comp_path, orig_info, comp_info)` (handles calling `_analyze_video` if needed)
        *   `_prepare_frame_extraction_indices(orig_frames_count)`
        *   `_perform_frame_pair_comparison(frame_output_dir, pairs_to_compare, mse_threshold, keep_frames)`
        *   `_evaluate_comparison_results(results, skip_first_frame, flexible_matching_used)`
    *   `_analyze_video` and `_analyze_video_minimal` share a lot of common parsing logic for stream info. Refactor this into a helper function:
        ```python
        def _parse_ffprobe_stream_info(self, video_stream: dict, format_info: dict, video_path: Path, filename: str, include_frame_count: bool = False) -> dict[str, Any]:
            # ... existing parsing logic for width, height, duration, bitrate, avg_frame_rate
            # if include_frame_count:
            #     # ... logic to get/calculate NB_FRAMES_KEY
            return info

        # In _analyze_video_minimal:
        # ... probe ...
        # return self._parse_ffprobe_stream_info(video_stream, format_info, video_path, filename, include_frame_count=False)

        # In _analyze_video (full):
        # ... probe ...
        # return self._parse_ffprobe_stream_info(video_stream, format_info, video_path, filename, include_frame_count=True)
        ```

*   **Logging:**
    *   Review all `logger` calls for clarity, consistency, and appropriate log levels.
    *   Ensure verbose mode provides truly comprehensive debug information without being overwhelming.
    *   The "Detailed file comparison" table in `_verify_transcoding_output` is good. Ensure it correctly states that `compressed_frames` will be checked later when using tiered analysis.

## 5. Strengthen Error Handling and User Feedback

**Action Items:**

*   **FFmpeg Interaction:**
    *   The current error handling for `ffmpeg.Error` captures stderr, which is good. Ensure that user-facing messages are clear about what failed (e.g., "FFmpeg compression failed", "FFprobe analysis failed").
*   **File Operations:**
    *   The `_replace_file` method has good logic for attempting to restore originals. Review for any unhandled `OSError` exceptions during file renames or deletions.
*   **User Guidance on Failure:**
    *   When a video fails, especially due to quality checks, provide more specific reasons if possible (e.g., "Failed: Frame count mismatch too high", "Failed: MSE too high on critical frames"). The `details_log` in `_check_frame_consistency` can be used for this.

## 6. Dependencies and Setup

*   Add `pymediainfo` to the `dependencies` list at the top of the script if that optimization is implemented.
*   Provide clear instructions if `libmediainfo` (the C library `pymediainfo` wraps) needs to be installed separately on the system.

