#!/bin/bash
# this_file: imgpngop.sh
# Downsize image to 1024px width, convert to PNG, then optimize with pngquant + optipng

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: imgpngop.sh <image> [output.png]" >&2
    exit 1
fi

input="$1"
output="${2:-${input%.*}.png}"

if [[ ! -f "$input" ]]; then
    echo "Error: File not found: $input" >&2
    exit 1
fi

# Resize to 1024px width (proportional) and convert to PNG
magick "$input" -resize '1024x>' "$output"

# Lossy compression with pngquant (overwrites in place)
pngquant --force --ext .png --quality=65-80 "$output"

# Lossless optimization with optipng
optipng -o2 -quiet "$output"

echo "You can look at the optimized image now:"
echo "$output"
