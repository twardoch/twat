#!/usr/bin/env -S uv run
# /// script
# dependencies = ["fire", "rich", "httpx", "python-dotenv", "loguru"]
# ///
# this_file: nowatermark-sora.py
"""
CLI tool to remove Sora 2 watermarks from videos using WaveSpeed or KIE APIs.

Usage:
    ./nowatermark-sora.py wvs --input_path video.mp4
    ./nowatermark-sora.py wvs --url_file https://example.com/video.mp4
    ./nowatermark-sora.py kie --url_sora "https://sora.chatgpt.com/p/s_..."
"""

import json
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlparse, unquote

import fire
import httpx
from dotenv import load_dotenv
from loguru import logger
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

load_dotenv()

import os

console = Console()

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

logger.remove()
_LOG_FORMAT = "<level>{level: <8}</level> | {message}"


def _setup_logging(verbose: bool = False) -> None:
    level = "DEBUG" if verbose else "INFO"
    logger.add(sys.stderr, format=_LOG_FORMAT, level=level, colorize=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds


def _retry_request(client: httpx.Client, method: str, url: str, **kwargs) -> httpx.Response:
    """Execute an HTTP request with retries on transient failures."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = client.request(method, url, **kwargs)
            if resp.status_code in (429, 500, 502, 503, 504) and attempt < MAX_RETRIES:
                wait = RETRY_DELAY * attempt
                logger.warning(f"HTTP {resp.status_code}, retrying in {wait}s (attempt {attempt}/{MAX_RETRIES})")
                time.sleep(wait)
                continue
            resp.raise_for_status()
            return resp
        except httpx.TransportError as exc:
            if attempt < MAX_RETRIES:
                wait = RETRY_DELAY * attempt
                logger.warning(f"Transport error: {exc}, retrying in {wait}s (attempt {attempt}/{MAX_RETRIES})")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError("Unreachable")


def _auto_name(source: str, suffix: str = "_nowm") -> str:
    """Derive an output filename from source URL or path."""
    if source.startswith("http"):
        parsed = urlparse(source)
        name = unquote(Path(parsed.path).stem) or "video"
    else:
        name = Path(source).stem

    # Sanitise: keep only safe chars
    name = re.sub(r"[^\w\s\-.]", "", name)[:80].strip()
    if not name:
        name = "video"
    ts = time.strftime("%H%M%S")
    return f"{name}{suffix}_{ts}.mp4"


def _step(t0: float, msg: str) -> None:
    """Print a timestamped step marker so the user knows we're alive."""
    elapsed = time.time() - t0
    console.print(f"[dim][{elapsed:>6.1f}s][/dim] {msg}")


def _done(t0: float) -> None:
    """Print total elapsed time."""
    elapsed = time.time() - t0
    console.print(f"\n[bold green]Done[/bold green] in {elapsed:.1f}s")


def _download_file(client: httpx.Client, url: str, dest: Path, t0: float | None = None) -> Path:
    """Download a file with progress display."""
    if t0:
        _step(t0, f"Downloading → [cyan]{dest}[/cyan]")
    logger.info(f"Downloading to {dest}")
    with client.stream("GET", url) as resp:
        resp.raise_for_status()
        total = int(resp.headers.get("content-length", 0))
        with open(dest, "wb") as f, Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Downloading…", total=total or None)
            for chunk in resp.iter_bytes(chunk_size=65536):
                f.write(chunk)
                progress.advance(task, len(chunk))
    console.print(f"[green]Saved:[/green] {dest} ({dest.stat().st_size:,} bytes)")
    return dest


# ---------------------------------------------------------------------------
# WaveSpeed command
# ---------------------------------------------------------------------------

def wvs(
    url_file: str | None = None,
    input_path: str | None = None,
    output: str | None = None,
    api_key: str | None = None,
    poll_interval: int = 5,
    timeout: int = 600,
    verbose: bool = False,
) -> None:
    """Remove watermark via WaveSpeed API.

    Provide either --url_file (public video URL) or --input_path (local file to upload).

    Args:
        url_file:      Public URL of the video.
        input_path:    Local path to a video file (will be uploaded first).
        output:        Output filename (auto-generated if omitted).
        api_key:       WaveSpeed API key (defaults to WAVESPEED_API_KEY env var).
        poll_interval: Seconds between status polls.
        timeout:       Max seconds to wait for processing.
        verbose:       Enable debug logging.
    """
    _setup_logging(verbose)

    key = api_key or os.environ.get("WAVESPEED_API_KEY")
    if not key:
        console.print("[red]Error:[/red] No API key. Set WAVESPEED_API_KEY or pass --api_key.")
        raise SystemExit(1)

    if not url_file and not input_path:
        console.print("[red]Error:[/red] Provide --url_file or --input_path.")
        raise SystemExit(1)

    t0 = time.time()
    headers = {"Authorization": f"Bearer {key}"}
    client = httpx.Client(headers=headers, timeout=120)

    # --- Upload local file if needed ---
    video_url = url_file
    source_label = url_file or input_path or "video"
    if input_path:
        p = Path(input_path)
        if not p.is_file():
            console.print(f"[red]Error:[/red] File not found: {input_path}")
            raise SystemExit(1)
        source_label = str(p)
        _step(t0, f"Uploading [cyan]{p.name}[/cyan] ({p.stat().st_size:,} bytes)…")
        logger.debug(f"Upload endpoint: https://api.wavespeed.ai/api/v3/media/upload/binary")
        resp = _retry_request(
            client, "POST",
            "https://api.wavespeed.ai/api/v3/media/upload/binary",
            files={"file": (p.name, open(p, "rb"))},
        )
        data = resp.json()
        logger.debug(f"Upload response: {json.dumps(data, indent=2)}")
        video_url = data.get("data", {}).get("download_url")
        if not video_url:
            console.print(f"[red]Error:[/red] Upload failed: {data}")
            raise SystemExit(1)
        _step(t0, f"[green]Uploaded.[/green] URL: {video_url}")

    # --- Submit watermark removal job ---
    _step(t0, "Submitting watermark removal job…")
    resp = _retry_request(
        client, "POST",
        "https://api.wavespeed.ai/api/v3/wavespeed-ai/video-watermark-remover",
        json={"video": video_url},
    )
    result = resp.json()
    logger.debug(f"Submit response: {json.dumps(result, indent=2)}")
    task_id = result.get("data", {}).get("id") or result.get("id")
    if not task_id:
        console.print(f"[red]Error:[/red] No task ID returned: {result}")
        raise SystemExit(1)
    _step(t0, f"Task ID: [cyan]{task_id}[/cyan]")

    # --- Poll for completion ---
    _step(t0, "Waiting for processing…")
    poll_url = f"https://api.wavespeed.ai/api/v3/predictions/{task_id}/result"
    start = time.time()
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        ptask = progress.add_task("Processing…", total=None)
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                console.print(f"[red]Error:[/red] Timed out after {timeout}s.")
                raise SystemExit(1)

            resp = _retry_request(client, "GET", poll_url)
            data = resp.json().get("data") or resp.json()
            status = data.get("status", "unknown")
            logger.debug(f"Poll [{elapsed:.0f}s]: status={status}")
            progress.update(ptask, description=f"Processing… ({status}, {elapsed:.0f}s)")

            if status == "completed":
                outputs = data.get("outputs", [])
                if not outputs:
                    console.print(f"[red]Error:[/red] Completed but no outputs: {data}")
                    raise SystemExit(1)
                result_url = outputs[0]
                break
            elif status == "failed":
                error = data.get("error", "unknown error")
                console.print(f"[red]Error:[/red] Processing failed: {error}")
                raise SystemExit(1)

            time.sleep(poll_interval)

    # --- Download result ---
    _step(t0, f"Result URL: [cyan]{result_url}[/cyan]")
    dest = Path(output) if output else Path(_auto_name(source_label))
    _download_file(client, result_url, dest, t0)
    client.close()
    _done(t0)


# ---------------------------------------------------------------------------
# KIE command
# ---------------------------------------------------------------------------

def kie(
    url_sora: str = "",
    output: str | None = None,
    api_key: str | None = None,
    poll_interval: int = 3,
    timeout: int = 300,
    verbose: bool = False,
) -> None:
    """Remove watermark via KIE API from a Sora share URL.

    Args:
        url_sora:      Public Sora 2 share URL (https://sora.chatgpt.com/p/…).
        output:        Output filename (auto-generated if omitted).
        api_key:       KIE API key (defaults to KIE_API_KEY env var).
        poll_interval: Seconds between status polls.
        timeout:       Max seconds to wait for processing.
        verbose:       Enable debug logging.
    """
    _setup_logging(verbose)

    key = api_key or os.environ.get("KIE_API_KEY")
    if not key:
        console.print("[red]Error:[/red] No API key. Set KIE_API_KEY or pass --api_key.")
        raise SystemExit(1)

    if not url_sora:
        console.print("[red]Error:[/red] Provide --url_sora with a Sora share URL.")
        raise SystemExit(1)

    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    t0 = time.time()
    client = httpx.Client(headers=headers, timeout=60)

    # --- Submit task ---
    _step(t0, f"Submitting KIE watermark removal for [cyan]{url_sora}[/cyan]")
    payload = {
        "model": "sora-watermark-remover",
        "input": {
            "video_url": url_sora,
        },
    }
    resp = _retry_request(
        client, "POST",
        "https://api.kie.ai/api/v1/jobs/createTask",
        json=payload,
    )
    result = resp.json()
    logger.debug(f"CreateTask response: {json.dumps(result, indent=2)}")
    task_id = (result.get("data") or {}).get("taskId")
    if not task_id:
        console.print(f"[red]Error:[/red] No taskId returned: {result}")
        raise SystemExit(1)
    _step(t0, f"Task ID: [cyan]{task_id}[/cyan]")

    # --- Poll for completion ---
    _step(t0, "Waiting for processing…")
    start = time.time()
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        ptask = progress.add_task("Processing…", total=None)
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                console.print(f"[red]Error:[/red] Timed out after {timeout}s.")
                raise SystemExit(1)

            resp = _retry_request(
                client, "GET",
                f"https://api.kie.ai/api/v1/jobs/recordInfo?taskId={task_id}",
            )
            data = resp.json().get("data") or {}
            state = data.get("state", "unknown")
            logger.debug(f"Poll [{elapsed:.0f}s]: state={state}")
            progress.update(ptask, description=f"Processing… ({state}, {elapsed:.0f}s)")

            if state == "success":
                result_json_str = data.get("resultJson", "{}")
                try:
                    result_json = json.loads(result_json_str)
                except (json.JSONDecodeError, TypeError):
                    result_json = {}
                result_urls = result_json.get("resultUrls", [])
                if not result_urls:
                    console.print(f"[red]Error:[/red] Success but no result URLs: {data}")
                    raise SystemExit(1)
                result_url = result_urls[0]
                break
            elif state == "fail":
                fail_msg = data.get("failMsg", "unknown error")
                console.print(f"[red]Error:[/red] Task failed: {fail_msg}")
                raise SystemExit(1)

            # Adaptive polling: slower after first 2 minutes
            interval = poll_interval if elapsed < 120 else min(poll_interval * 3, 15)
            time.sleep(interval)

    # --- Download result ---
    _step(t0, f"Result URL: [cyan]{result_url}[/cyan]")
    dest = Path(output) if output else Path(_auto_name(url_sora, suffix="_kie_nowm"))
    _download_file(client, result_url, dest, t0)
    client.close()
    _done(t0)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

class NoWatermark:
    """Remove Sora 2 watermarks from videos.

    Commands:
        wvs   Remove watermark via WaveSpeed (local file or URL).
        kie   Remove watermark via KIE (Sora share URL).
    """

    def __init__(self):
        self.wvs = wvs
        self.kie = kie


if __name__ == "__main__":
    fire.Fire(NoWatermark)
