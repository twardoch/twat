# img/ Scripts Improvement Plan

## Overview
Collection of image and video processing CLI tools. Goal: improve consistency, robustness, and documentation.

## Phase 1: Script Standardization ✅ COMPLETE

### 1.1 Python Scripts ✅
- [x] Add `uv run -s` shebang headers with dependency declarations
- [x] Add `this_file` markers with correct relative paths
- [x] Ensure consistent CLI patterns (fire + rich + loguru)

### 1.2 Shell Scripts ✅
- [x] Add `set -euo pipefail` for fail-fast behavior
- [x] Add `this_file` markers
- [x] Fix broken paths (~/bin/video* → ~/bin/img/vid*)
- [x] Standardize output naming

**22 scripts standardized** - see completed list below.

## Phase 2: Documentation & Usability (Current)

### 2.1 Documentation ✅
- [x] Create README.md with script catalog

### 2.2 Future Improvements
- [ ] Add --help examples to scripts lacking documentation
- [ ] Consider consolidating duplicate scripts (vidcrop1/2, vidmergebygap1)
- [ ] Add integration tests for critical scripts

---

## Completed Items

### Phase 1 (2026-01-17)
- imgpngop.sh - output to same path as original
- vidglue - added uv shebang, this_file marker
- vidhalfsharpen.sh - added this_file, set -euo pipefail
- vidreverse - fixed this_file path
- vidfps - fixed this_file path
- vidimportaudio - fixed this_file path
- viddub.sh - added this_file, set -euo pipefail
- vidfpsall.sh - fixed broken path, added safety guards
- vidstartendframe.sh - added this_file, set -euo pipefail
- vidstartendframeall.sh - fixed broken path, added safety guards
- vidhalfsharpenall.sh - fixed broken path
- vidren2jpgall - added safety guards, switched to bash
- vidsqueeze.sh - fixed hardcoded path
- vidkenburns.py - added uv shebang
- viddub-av.py - added uv shebang
- vidpredub.py - added uv shebang
- vidmergebygap.py - added uv shebang
- viddub-ffm.py - added uv shebang
- viddub-m.py - added uv shebang
- vidmergebygap1.py - added uv shebang
- vidreverb.py - fixed this_file path
- scanify.py - fixed shebang consistency

### Phase 2 (2026-01-17)
- README.md - created comprehensive documentation
