#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["ffmpeg-python", "fire", "rich", "loguru"]
# ///
# this_file: vidhwscale.py
"""
vidhwscale.py - Video Hardware Scaling and Cropping Tool

This tool resizes and crops videos using FFmpeg.
It supports both absolute pixel values and percentage-based scaling/cropping.

Arguments:
    --sw/--sh: Scale width/height (pixels or percentage)
    --cw/--ch: Crop width/height (pixels or percentage)
    --fast: Use faster encoding (lower quality)
    --output: Custom output path

Examples:
    # Scale to specific resolution
    vidhwscale.py --input video.mp4 --sw 1280 --sh 720

    # Scale to 50% of original size
    vidhwscale.py --input video.mp4 --sw 50% --sh 50%

    # Scale width to 1280, height proportionally (50% of original)
    vidhwscale.py --input video.mp4 --sw 1280 --sh 50%

    # Scale up slightly then crop to target (for removing letterbox)
    vidhwscale.py --input video.mp4 --sw 103% --ch 1080

    # Scale to 1920 width, then crop to 1600 width (center crop)
    vidhwscale.py --input video.mp4 --sw 1920 --cw 1600

    # Fast encoding for preview/testing
    vidhwscale.py --input video.mp4 --sw 50% --sh 50% --fast

    # Custom output path
    vidhwscale.py --input video.mp4 --sw 1280 --sh 720 --output resized.mp4

Workflow: Scale is applied first, then crop (if specified).
"""

import sys
import ffmpeg
from pathlib import Path
import fire
from rich.console import Console
from loguru import logger

# Set up logging
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
)

console = Console()


def parse_dimension(value: str | int | None, original_dimension: int) -> int:
    """
    Parse dimension value which can be pixels (int) or percentage (float%).

    Args:
        value: Target dimension, either as pixels (int) or percentage (str with %)
        original_dimension: Original dimension in pixels

    Returns:
        Calculated dimension in pixels
    """
    if value is None:
        return original_dimension  # 100% by default

    # Check if it's a percentage
    if isinstance(value, str) and "%" in value:
        percentage = float(value.strip("%")) / 100.0
        return int(original_dimension * percentage)

    # Otherwise treat as absolute pixels
    return int(value)


def get_video_dimensions(input_file: str) -> tuple[int, int]:
    """
    Get the dimensions of the input video.

    Args:
        input_file: Path to the input video file

    Returns:
        Tuple of (width, height) in pixels
    """
    try:
        probe = ffmpeg.probe(input_file)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )

        if video_stream is None:
            raise ValueError("No video stream found in the input file")

        width = int(video_stream["width"])
        height = int(video_stream["height"])
        return width, height
    except ffmpeg.Error as e:
        logger.error(
            f"Error probing video: {e.stderr.decode() if hasattr(e, 'stderr') else str(e)}"
        )
        raise


def scale_video(
    input: str,
    output: str | None = None,
    sw: str | int | None = None,  # scale width
    sh: str | int | None = None,  # scale height
    cw: str | int | None = None,  # crop width
    ch: str | int | None = None,  # crop height
    fast: bool = False,
    verbose: bool = False,
) -> str:
    """
    Scale and/or crop a video file to the specified dimensions.

    Args:
        input: Path to the input video file
        output: Path to the output video file (auto-generated if not provided)
        sw: Target scale width in pixels (int) or percentage (str with %)
        sh: Target scale height in pixels (int) or percentage (str with %)
        cw: Target crop width in pixels (int) or percentage (str with %)
        ch: Target crop height in pixels (int) or percentage (str with %)
        fast: Use faster but lower quality algorithm
        verbose: Enable verbose logging

    Returns:
        Path to the output video file
    """
    if verbose:
        logger.level("DEBUG")

    input_path = Path(input)

    # Validate input file
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input}")

    # Auto-generate output filename if not provided
    if output is None:
        stem = input_path.stem
        suffix = input_path.suffix
        operation_names = []
        if sw is not None or sh is not None:
            operation_names.append("scaled")
        if cw is not None or ch is not None:
            operation_names.append("cropped")
        operations = "_".join(operation_names) if operation_names else "processed"
        output = str(input_path.with_name(f"{stem}_{operations}{suffix}"))

    logger.info(f"Input file: {input}")
    logger.info(f"Output file: {output}")

    # Get original dimensions
    orig_width, orig_height = get_video_dimensions(input)
    logger.info(f"Original dimensions: {orig_width}x{orig_height}")

    # Parse target scaling dimensions - default to original dimensions if not specified
    # These will always be integers after parsing
    target_width = parse_dimension(sw, orig_width)
    target_height = parse_dimension(sh, orig_height)

    logger.info(f"Target scaling dimensions: {target_width}x{target_height}")

    # Parse target cropping dimensions
    final_crop_width: int | None = None
    final_crop_height: int | None = None

    if cw is not None:
        try:
            # Get the crop width in pixels
            temp_crop_width = parse_dimension(cw, target_width)

            # Check if crop width is valid
            if temp_crop_width > target_width:
                logger.warning(
                    f"Crop width ({temp_crop_width}) is larger than scaled width ({target_width}). Using scaled width."
                )
                final_crop_width = target_width
            else:
                final_crop_width = temp_crop_width
        except ValueError as e:
            logger.error(f"Invalid crop width: {e}")
            final_crop_width = target_width

    if ch is not None:
        try:
            # Get the crop height in pixels
            temp_crop_height = parse_dimension(ch, target_height)

            # Check if crop height is valid
            if temp_crop_height > target_height:
                logger.warning(
                    f"Crop height ({temp_crop_height}) is larger than scaled height ({target_height}). Using scaled height."
                )
                final_crop_height = target_height
            else:
                final_crop_height = temp_crop_height
        except ValueError as e:
            logger.error(f"Invalid crop height: {e}")
            final_crop_height = target_height

    # Log the crop dimensions
    crop_info = []
    if final_crop_width is not None:
        crop_info.append(f"width: {final_crop_width}")
    if final_crop_height is not None:
        crop_info.append(f"height: {final_crop_height}")

    logger.info(
        f"Target crop dimensions: {', '.join(crop_info) if crop_info else 'None'}"
    )

    # Choose scaling algorithm
    scaling_algo = "bilinear" if fast else "lanczos"
    logger.info(f"Using scaling algorithm: {scaling_algo}")

    try:
        # Build the filter chain
        filter_chain = []

        # First add scaling
        filter_chain.append(
            f"scale={target_width}:{target_height}:flags={scaling_algo}"
        )

        # Then add cropping if needed (always from center)
        if cw is not None or ch is not None:
            # Default to target dimensions if not specified
            crop_w = final_crop_width if final_crop_width is not None else target_width
            crop_h = (
                final_crop_height if final_crop_height is not None else target_height
            )

            # Calculate crop position (centered)
            x_offset = max(0, int((target_width - crop_w) / 2))
            y_offset = max(0, int((target_height - crop_h) / 2))

            filter_chain.append(f"crop={crop_w}:{crop_h}:{x_offset}:{y_offset}")

        # Join the filter chain with commas
        filter_string = ",".join(filter_chain)

        logger.debug(f"Filter string: {filter_string}")

        # Process the video with ffmpeg
        with console.status("Processing video..."):
            (
                ffmpeg.input(input)
                .output(
                    output,
                    vf=filter_string,
                    acodec="copy",  # Copy audio stream without re-encoding
                )
                .global_args("-loglevel", "error" if not verbose else "info")
                .global_args("-y")  # Overwrite output file if it exists
                .run(capture_stdout=True, capture_stderr=True)
            )

        logger.success(f"Video processed successfully: {output}")
        return output

    except ffmpeg.Error as e:
        logger.error(
            f"FFmpeg error: {e.stderr.decode() if hasattr(e, 'stderr') else str(e)}"
        )
        raise


def main():
    """Run the CLI using the Fire library."""
    try:
        fire.Fire(scale_video)
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
