#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire"]
# ///
"""
vidpredub.py - Retimes video to match audio duration and replaces audio track.

Adjusts video playback speed (by changing FPS) to match a new audio track's duration,
then combines them. Useful for dubbing, voiceover sync, or matching video to narration.

How it works:
1. Gets duration of audio file
2. Calculates new FPS to make video match audio duration
3. Exports video with adjusted FPS + new audio track

Examples:
    # Retime video to match voiceover duration
    vidpredub.py --video-path clip.mp4 --audio-path voiceover.mp3 --output-path dubbed.mp4

    # Match video to audio from another video file
    vidpredub.py --video-path animation.mp4 --audio-path reference.mp4 --output-path synced.mp4

    # Enable verbose logging
    vidpredub.py --video-path in.mp4 --audio-path narration.wav --output-path out.mp4 --verbose

Note: Original video audio is discarded. Video is sped up/slowed down to match audio length.
"""
# this_file: vidpredub.py

import fire
import logging
import subprocess
import sys
import tempfile
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def get_duration(file_path: Path) -> float:
    """
    Get the duration of a media file in seconds.

    Args:
        file_path: Path to the media file

    Returns:
        Duration in seconds

    Raises:
        RuntimeError: If ffprobe fails to get duration
    """
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(file_path),
    ]

    logger.debug(f"Running command: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        duration = float(result.stdout.strip())
        logger.debug(f"Duration of {file_path}: {duration:.2f}s")
        return duration
    except (subprocess.SubprocessError, ValueError) as e:
        logger.error(f"Failed to get duration for {file_path}")
        raise RuntimeError(f"Failed to get duration for {file_path}: {e}")


def get_video_fps(file_path: Path) -> float:
    """
    Get the frame rate of a video file.

    Args:
        file_path: Path to the video file

    Returns:
        Frame rate (frames per second)

    Raises:
        RuntimeError: If ffprobe fails to get frame rate
    """
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=r_frame_rate",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(file_path),
    ]

    logger.debug(f"Running command: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        rate_str = result.stdout.strip()

        # Handle fractional frame rates like "30000/1001"
        if "/" in rate_str:
            num, den = map(int, rate_str.split("/"))
            fps = num / den
        else:
            fps = float(rate_str)

        logger.debug(f"Frame rate of {file_path}: {fps:.2f}fps")
        return fps
    except (subprocess.SubprocessError, ValueError) as e:
        logger.error(f"Failed to get frame rate for {file_path}")
        raise RuntimeError(f"Failed to get frame rate for {file_path}: {e}")


def process_video(
    video_path: Path, audio_path: Path, output_path: Path, verbose: bool = False
) -> None:
    """
    Process video to match audio duration and replace audio track.

    Args:
        video_path: Path to the input video
        audio_path: Path to the input audio
        output_path: Path for the output video
        verbose: Whether to enable verbose logging

    Raises:
        RuntimeError: If processing fails
    """
    if verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Verbose logging enabled")

    try:
        # Get durations
        video_duration = get_duration(video_path)
        audio_duration = get_duration(audio_path)

        # Get original video frame rate
        original_fps = get_video_fps(video_path)

        # Calculate new frame rate to match audio duration
        # If video is longer than audio, increase FPS (speed up video)
        # If video is shorter than audio, decrease FPS (slow down video)
        new_fps = original_fps * (video_duration / audio_duration)

        logger.info(
            f"Original video duration: {video_duration:.2f}s at {original_fps:.2f}fps"
        )
        logger.info(f"Target audio duration: {audio_duration:.2f}s")
        logger.info(f"Adjusted video will use {new_fps:.2f}fps")

        # Create a temporary directory for intermediary files
        with tempfile.TemporaryDirectory() as temp_dir:
            # Step 1: Extract video (no audio) and adjust speed by changing FPS
            temp_dir_path = Path(temp_dir)
            temp_video = temp_dir_path / "temp_video.mp4"

            # Use the atempo filter if the speed change is extreme
            speed_ratio = video_duration / audio_duration
            logger.debug(f"Speed ratio: {speed_ratio:.2f}")

            if 0.5 <= speed_ratio <= 2.0:
                # For moderate speed changes, we can use fps filter directly
                cmd_retime = [
                    "ffmpeg",
                    "-y",
                    "-i",
                    str(video_path),
                    "-an",  # Remove audio
                    "-vf",
                    f"fps={new_fps}",
                    "-c:v",
                    "libx264",
                    "-preset",
                    "medium",
                    "-crf",
                    "18",  # Balance quality and file size
                    str(temp_video),
                ]
                logger.debug("Using fps filter for moderate speed change")
            else:
                # For extreme speed changes, use setpts for better results
                setpts_value = 1.0 / speed_ratio
                cmd_retime = [
                    "ffmpeg",
                    "-y",
                    "-i",
                    str(video_path),
                    "-an",  # Remove audio
                    "-vf",
                    f"setpts={setpts_value}*PTS",
                    "-c:v",
                    "libx264",
                    "-preset",
                    "medium",
                    "-crf",
                    "18",
                    str(temp_video),
                ]
                logger.debug(
                    f"Using setpts filter for extreme speed change: {setpts_value}"
                )

            logger.debug(f"Running command: {' '.join(cmd_retime)}")
            subprocess.run(cmd_retime, check=True)
            logger.info("Video retiming completed")

            # Step 2: Combine retimed video with audio
            cmd_combine = [
                "ffmpeg",
                "-y",
                "-i",
                str(temp_video),  # Retimed video
                "-i",
                str(audio_path),  # Audio source
                "-c:v",
                "copy",  # Copy video stream without re-encoding
                "-c:a",
                "aac",  # Use AAC codec for audio
                "-b:a",
                "192k",  # Audio bitrate
                "-map",
                "0:v:0",  # Take video from first input
                "-map",
                "1:a:0",  # Take audio from second input
                "-shortest",  # End when shortest input ends
                str(output_path),
            ]

            logger.debug(f"Running command: {' '.join(cmd_combine)}")
            subprocess.run(cmd_combine, check=True)
            logger.info("Audio merging completed")

        logger.info(f"Successfully created output video: {output_path}")

    except (subprocess.SubprocessError, RuntimeError) as e:
        logger.error(f"Failed to process video: {e}")
        raise RuntimeError(f"Failed to process video: {e}")


def vidpredub(
    video_path: str | Path,
    audio_path: str | Path,
    output_path: str | Path,
    verbose: bool = False,
) -> None:
    """
    Retime video to match audio duration and replace audio track.

    Args:
        video_path: Path to the input video file
        audio_path: Path to the input audio file (or video with audio)
        output_path: Path for the output video file
        verbose: Enable verbose logging if True
    """
    # Convert string paths to Path objects
    video_path = Path(video_path)
    audio_path = Path(audio_path)
    output_path = Path(output_path)

    # Validate input files exist
    if not video_path.is_file():
        logger.error(f"Video file not found: {video_path}")
        sys.exit(1)

    if not audio_path.is_file():
        logger.error(f"Audio file not found: {audio_path}")
        sys.exit(1)

    # Create output directory if it doesn't exist
    output_dir = output_path.parent
    if not output_dir.exists():
        logger.debug(f"Creating output directory: {output_dir}")
        output_dir.mkdir(parents=True, exist_ok=True)

    try:
        process_video(video_path, audio_path, output_path, verbose)
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    fire.Fire(vidpredub)
