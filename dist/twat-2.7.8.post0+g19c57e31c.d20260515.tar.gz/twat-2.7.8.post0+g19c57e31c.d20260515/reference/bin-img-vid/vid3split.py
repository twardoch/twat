#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "ffmpeg-python", "rich"]
# ///
# this_file: vid3split.py

"""
Split a video into three equal parts using ffmpeg.

This script takes a video file and splits it into three segments of equal duration.
The output files are saved in the same directory as the input file with suffixes:
-1beg, -2mid, and -3end.

Examples:
    # Split a video into three parts (outputs to same directory)
    vid3split.py movie.mp4

    # Split with custom output directory
    vid3split.py movie.mp4 --output-dir ./segments

    # Enable verbose logging
    vid3split.py movie.mp4 --verbose

Output files for 'movie.mp4':
    movie-1beg.mp4  (first third)
    movie-2mid.mp4  (middle third)
    movie-3end.mp4  (last third)
"""

import logging
import shutil
import sys
from pathlib import Path

import ffmpeg
import fire
from rich.console import Console
from rich.logging import RichHandler
from rich.progress import Progress, SpinnerColumn, TextColumn

# Configure rich logging
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(rich_tracebacks=True)],
)
log = logging.getLogger("vid3split")
console = Console()


def check_ffmpeg() -> None:
    """
    Check if ffmpeg is available in the system PATH.

    Raises:
        RuntimeError: If ffmpeg is not found
    """
    if not shutil.which("ffmpeg"):
        raise RuntimeError(
            "ffmpeg not found in PATH. Please install ffmpeg:\n"
            "- macOS: brew install ffmpeg\n"
            "- Linux: apt-get install ffmpeg\n"
            "- Windows: choco install ffmpeg"
        )


def validate_video(video_path: Path) -> None:
    """
    Validate that the file is a supported video format.

    Args:
        video_path: Path to the video file

    Raises:
        ValueError: If file is not a supported video format
    """
    try:
        probe = ffmpeg.probe(str(video_path))
        if not any(stream["codec_type"] == "video" for stream in probe["streams"]):
            raise ValueError(f"No video stream found in file: {video_path}")
    except ffmpeg.Error as e:
        raise ValueError(f"Invalid or corrupted video file: {e.stderr.decode()}")


def get_video_duration(video_path: Path) -> float:
    """
    Get the duration of a video file in seconds.

    Args:
        video_path: Path to the video file

    Returns:
        Duration in seconds

    Raises:
        ffmpeg.Error: If ffprobe fails to get video information
    """
    try:
        probe = ffmpeg.probe(str(video_path))
        duration = float(probe["format"]["duration"])
        log.debug(f"Video duration: {duration:.2f} seconds")
        return duration
    except ffmpeg.Error as e:
        log.error(f"Failed to get video duration: {e.stderr.decode()}")
        raise


def split_video(video_path: str, output_dir: str | None = None) -> None:
    """
    Split a video into three equal parts.

    Args:
        video_path: Path to the input video file
        output_dir: Optional output directory (defaults to input video directory)

    Raises:
        FileNotFoundError: If input video doesn't exist
        ffmpeg.Error: If ffmpeg operations fail
    """
    input_path = Path(video_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Video file not found: {video_path}")

    # Use input video directory if no output dir specified
    output_path = Path(output_dir) if output_dir else input_path.parent
    output_path.mkdir(parents=True, exist_ok=True)

    # Get base name and extension for output files
    stem = input_path.stem
    suffix = input_path.suffix

    try:
        # Validate video before processing
        validate_video(input_path)

        # Get video duration
        duration = get_video_duration(input_path)
        segment_duration = duration / 3

        # Define output segments
        segments = [
            (0, segment_duration, f"{stem}-1beg{suffix}"),
            (segment_duration, segment_duration * 2, f"{stem}-2mid{suffix}"),
            (segment_duration * 2, duration, f"{stem}-3end{suffix}"),
        ]

        # Process each segment with progress indicator
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            for start, end, output_name in segments:
                output_file = output_path / output_name
                task_id = progress.add_task(f"Creating {output_name}...", total=None)

                try:
                    stream = ffmpeg.input(str(input_path), ss=start, t=end - start)
                    stream = ffmpeg.output(
                        stream, str(output_file), acodec="copy", vcodec="copy"
                    )
                    ffmpeg.run(stream, capture_stdout=True, capture_stderr=True)
                    progress.remove_task(task_id)
                except ffmpeg.Error as e:
                    progress.remove_task(task_id)
                    log.error(
                        f"Failed to create segment {output_name}: {e.stderr.decode()}"
                    )
                    raise

        log.info("✨ Video split complete!")

    except Exception as e:
        log.error(f"Failed to split video: {str(e)}")
        raise


def main(video_path: str, output_dir: str | None = None, verbose: bool = False) -> None:
    """
    Split a video into three equal parts using ffmpeg.

    Args:
        video_path: Path to the input video file
        output_dir: Optional output directory (defaults to input video directory)
        verbose: Enable verbose logging
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    try:
        # Check ffmpeg availability first
        check_ffmpeg()
        split_video(video_path, output_dir)
    except Exception as e:
        log.error(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    fire.Fire(main)
