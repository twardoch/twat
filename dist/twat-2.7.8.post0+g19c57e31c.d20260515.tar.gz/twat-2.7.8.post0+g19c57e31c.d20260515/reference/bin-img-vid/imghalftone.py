#!/usr/bin/env -S uv run
# /// script
# dependencies = ["pillow", "numpy", "fire", "loguru"]
# ///
# this_file: halftone.py
"""Linear halftone image converter.

Converts a photograph into parallel lines whose thickness varies with
the source image brightness.
"""

import math
import sys

import fire
import numpy as np
from loguru import logger
from PIL import Image


def _rounded_wave(d: float, period: float, radius: float) -> float:
    """Rounded square wave returning values in [-1, 1].

    radius=0 gives a square wave. radius=period/4 gives a cosine wave.
    Values in between produce a square wave with rounded transitions.
    """
    if period <= 0:
        return 0.0
    radius = min(abs(radius), period / 4)
    phase = d % period
    half = period / 2

    if radius < 1e-6:
        return 1.0 if phase < half else -1.0

    if phase < half - radius:
        return 1.0
    elif phase < half + radius:
        frac = (phase - (half - radius)) / (2 * radius)
        return math.cos(frac * math.pi)
    elif phase < period - radius:
        return -1.0
    else:
        frac = (phase - (period - radius)) / (2 * radius)
        return -math.cos(frac * math.pi)


def halftone(
    src: str,
    dst: str = None,
    min_thickness: float = 0.0,
    max_thickness: float = 4.0,
    angle: float = 45.0,
    interval: float = 8.0,
    wave_height: float = 0.0,
    wave_width: float = 100.0,
    wave_radius: float = 0.0,
    invert: bool = False,
    bg: int = 0,
    fg: int = 255,
    verbose: bool = False,
):
    """Convert an image to linear halftone.

    Lines run at the given angle. Their thickness at each point is
    proportional to the source brightness (bright areas → thick lines).

    All spatial units are pixels. Angle is degrees counterclockwise
    (0 = horizontal lines).

    Args:
        src: Input image path.
        dst: Output path. Default: <src>_halftone.<ext>.
        min_thickness: Stroke thickness for darkest areas.
        max_thickness: Stroke thickness for brightest areas.
        angle: Line angle, degrees counterclockwise. 0 = horizontal.
        interval: Base spacing between lines.
        wave_height: How much the spacing varies (amplitude). 0 = uniform.
                     Must be less than interval to avoid overlap.
        wave_width: Wavelength of the spacing wave (pixels along
                    the perpendicular axis).
        wave_radius: Curviness of the wave shape. 0 = square wave
                     (abrupt interval changes), wave_width/4 = smooth
                     cosine wave.
        invert: If True, dark areas get thick lines instead.
        bg: Background brightness 0-255.
        fg: Line brightness 0-255.
        verbose: Enable debug logging.
    """
    if not verbose:
        logger.remove()
        logger.add(sys.stderr, level="WARNING")

    logger.info("Loading {}", src)
    img = Image.open(src).convert("L")
    px = np.array(img, dtype=np.float64) / 255.0
    h, w = px.shape
    logger.info("Image size: {}x{}", w, h)

    if invert:
        px = 1.0 - px

    if dst is None:
        parts = src.rsplit(".", 1)
        dst = f"{parts[0]}_halftone.{parts[1]}" if len(parts) == 2 else f"{src}_halftone.png"

    # Direction vectors (image coords: y increases downward)
    theta = math.radians(angle)
    nx, ny = math.sin(theta), math.cos(theta)  # perpendicular (spacing axis)

    # Perpendicular distance range across image corners
    corners = [(0, 0), (w - 1, 0), (w - 1, h - 1), (0, h - 1)]
    perp_vals = [cx * nx + cy * ny for cx, cy in corners]
    d_min, d_max = min(perp_vals), max(perp_vals)
    margin = interval * 2 + abs(wave_height) + max_thickness
    logger.debug("Perp range: {:.1f} .. {:.1f}, margin {:.1f}", d_min, d_max, margin)

    # Build line positions with optional wave-modulated spacing
    line_positions: list[float] = []
    d = d_min - margin
    end = d_max + margin
    while d <= end:
        line_positions.append(d)
        if wave_height != 0 and wave_width > 0:
            shift = wave_height * _rounded_wave(d, wave_width, wave_radius)
            step = max(interval + shift, 0.5)  # guard against overlap
        else:
            step = interval
        d += step

    logger.info("Generated {} lines", len(line_positions))
    if not line_positions:
        Image.new("L", (w, h), bg).save(dst)
        print(f"Saved to {dst}")
        return

    line_arr = np.array(sorted(line_positions), dtype=np.float64)

    # Perpendicular distance for every pixel
    yy, xx = np.mgrid[0:h, 0:w]
    d_map = xx.astype(np.float64) * nx + yy.astype(np.float64) * ny

    # Find nearest line via sorted search
    flat = d_map.ravel()
    idx = np.searchsorted(line_arr, flat)
    idx_lo = np.clip(idx - 1, 0, len(line_arr) - 1)
    idx_hi = np.clip(idx, 0, len(line_arr) - 1)
    nearest_dist = np.minimum(
        np.abs(flat - line_arr[idx_lo]),
        np.abs(flat - line_arr[idx_hi]),
    ).reshape(h, w)

    # Half-thickness from brightness
    half_thick = (min_thickness + (max_thickness - min_thickness) * px) / 2.0

    # Antialiased edge (0.5 px feather)
    alpha = np.clip(half_thick - nearest_dist + 0.5, 0.0, 1.0)

    # Composite output
    out_px = np.clip(bg + (fg - bg) * alpha, 0, 255).astype(np.uint8)
    Image.fromarray(out_px, mode="L").save(dst)
    print(f"Saved to {dst}")


if __name__ == "__main__":
    fire.Fire(halftone)
