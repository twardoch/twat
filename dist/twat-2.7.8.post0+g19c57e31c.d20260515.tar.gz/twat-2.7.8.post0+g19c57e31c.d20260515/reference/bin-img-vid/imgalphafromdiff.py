#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "rich", "numpy", "pillow"]
# ///
# this_file: imgalphafromdiff.py

"""
Difference Matting: Extract transparency from two images on black/white backgrounds.

Given the same subject rendered on a pure white and a pure black background,
this script recovers the exact alpha channel using difference matting math:

  - If a pixel is 100% opaque, it looks identical on both backgrounds (distance = 0).
  - If a pixel is 100% transparent, it shows the pure background color (distance = max).
  - Semi-transparent pixels fall linearly between these extremes.

The foreground color is recovered by un-premultiplying the black-background image.

Usage:
    ./imgalphafromdiff.py --white on_white.png --black on_black.png
    ./imgalphafromdiff.py --white on_white.png --black on_black.png --output result.png
"""

from __future__ import annotations

import sys
from pathlib import Path

import fire
import numpy as np
from PIL import Image
from rich import print as rprint

# Maximum Euclidean distance between white (255,255,255) and black (0,0,0).
# sqrt(255^2 + 255^2 + 255^2) ~ 441.67
BG_DISTANCE = np.sqrt(3.0 * 255.0 * 255.0)

# Pixels with alpha below this threshold are treated as fully transparent,
# avoiding division-by-near-zero artifacts in color recovery.
ALPHA_EPSILON = 0.01


def _load_rgb(path: str | Path) -> np.ndarray:
    """Load an image and return it as a float64 RGB array (H, W, 3) in 0-255 range.

    Converts any mode (RGBA, L, P, etc.) to RGB so both inputs are comparable.

    Args:
        path: Path to the image file.

    Returns:
        Numpy array of shape (H, W, 3), dtype float64, values in [0, 255].

    Raises:
        FileNotFoundError: If the image file does not exist.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Image not found: {p}")
    img = Image.open(p).convert("RGB")
    return np.asarray(img, dtype=np.float64)


def extract_alpha_two_pass(
    white_img: np.ndarray,
    black_img: np.ndarray,
) -> np.ndarray:
    """Compute RGBA output from matched white-background and black-background images.

    Implements difference matting:
      1. Per-pixel Euclidean distance between the two observations.
      2. alpha = 1 - (distance / BG_DISTANCE), clamped to [0, 1].
      3. Foreground color recovered from the black-background image via
         un-premultiplication: C_fg = C_black / alpha  (since BG is 0,0,0).

    Args:
        white_img: RGB array (H, W, 3) of the subject on pure white.
        black_img: RGB array (H, W, 3) of the subject on pure black.

    Returns:
        RGBA uint8 array (H, W, 4) with recovered color and transparency.

    Raises:
        ValueError: If the two images have different dimensions.
    """
    if white_img.shape != black_img.shape:
        raise ValueError(
            f"Dimension mismatch: white is {white_img.shape}, black is {black_img.shape}. "
            "Both images must be identical size."
        )

    # Per-pixel Euclidean distance between white-bg and black-bg observations.
    diff = white_img - black_img  # (H, W, 3)
    pixel_dist = np.sqrt(np.sum(diff * diff, axis=2))  # (H, W)

    # Alpha: fully opaque pixels look the same on both (dist=0 -> alpha=1),
    # fully transparent pixels look like the backgrounds (dist=BG_DISTANCE -> alpha=0).
    alpha = 1.0 - (pixel_dist / BG_DISTANCE)
    alpha = np.clip(alpha, 0.0, 1.0)  # (H, W)

    # Recover foreground color from the black-background image.
    # Since BG is (0,0,0), the formula C_fg = (C_observed - (1-alpha)*BG) / alpha
    # simplifies to C_fg = C_observed / alpha.
    safe_alpha = np.where(alpha > ALPHA_EPSILON, alpha, 1.0)  # avoid div-by-zero
    rgb_out = black_img / safe_alpha[..., np.newaxis]  # (H, W, 3)

    # Zero out color for fully transparent pixels (where alpha <= epsilon).
    transparent_mask = alpha <= ALPHA_EPSILON
    rgb_out[transparent_mask] = 0.0

    # Clamp and assemble RGBA.
    rgb_out = np.clip(rgb_out, 0.0, 255.0)
    alpha_channel = (alpha * 255.0).clip(0.0, 255.0)

    rgba = np.zeros((*white_img.shape[:2], 4), dtype=np.uint8)
    rgba[..., :3] = np.round(rgb_out).astype(np.uint8)
    rgba[..., 3] = np.round(alpha_channel).astype(np.uint8)

    return rgba


def _auto_output_path(white_path: str | Path) -> Path:
    """Generate an output filename based on the white-background input.

    Appends '_alpha' before the extension and forces .png.

    Args:
        white_path: Path to the white-background image (used as name basis).

    Returns:
        Path object for the output file.
    """
    p = Path(white_path)
    return p.with_name(f"{p.stem}_alpha.png")


def alphafromdiff(
    *,
    white: str,
    black: str,
    output: str | None = None,
) -> None:
    """Extract transparency via difference matting from white/black background pairs.

    Takes two images of the same subject — one on a pure white background,
    one on a pure black background — and produces a PNG with correct alpha
    transparency recovered via difference matting.

    Args:
        white: Path to the image on a pure white (#FFFFFF) background.
        black: Path to the image on a pure black (#000000) background.
        output: Output PNG path. If omitted, auto-generates from the white image name.
    """
    white_path = Path(white)
    black_path = Path(black)
    out_path = Path(output) if output else _auto_output_path(white_path)

    rprint(f"[bold]Difference Matting[/bold]")
    rprint(f"  White BG : {white_path}")
    rprint(f"  Black BG : {black_path}")
    rprint(f"  Output   : {out_path}")

    # Load both images as RGB float arrays.
    white_img = _load_rgb(white_path)
    black_img = _load_rgb(black_path)

    rprint(f"  Size     : {white_img.shape[1]}x{white_img.shape[0]}")

    # Run the matting algorithm.
    rgba = extract_alpha_two_pass(white_img, black_img)

    # Count transparency stats for user feedback.
    alpha_chan = rgba[..., 3]
    total = alpha_chan.size
    fully_opaque = int(np.sum(alpha_chan == 255))
    fully_transparent = int(np.sum(alpha_chan == 0))
    semi_transparent = total - fully_opaque - fully_transparent

    rprint(f"  Pixels   : {total:,} total")
    rprint(
        f"  Alpha    : [green]{fully_opaque:,}[/green] opaque, "
        f"[yellow]{semi_transparent:,}[/yellow] semi, "
        f"[red]{fully_transparent:,}[/red] transparent"
    )

    # Save as PNG (the only format that supports full alpha).
    out_path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(rgba, mode="RGBA").save(out_path, format="PNG")

    rprint(f"[bold green]Saved:[/bold green] {out_path}")


def cli() -> None:
    """CLI entry point."""
    fire.Fire(alphafromdiff)


if __name__ == "__main__":
    cli()
