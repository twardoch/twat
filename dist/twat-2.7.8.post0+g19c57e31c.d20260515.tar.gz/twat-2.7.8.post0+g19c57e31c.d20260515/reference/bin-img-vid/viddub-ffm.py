#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["ffmpeg-python", "fire"]
# ///
# this_file: viddub-ffm.py

"""
Merge video and audio streams using FFmpeg (re-encodes audio to AAC).

Combines video track from one file with audio track from another.
Unlike viddub-av.py (stream copy), this re-encodes audio to AAC for
maximum compatibility. Useful when source audio format isn't supported.

Examples:
    # Merge video.mp4 video with audio.mp3 (output: audio.mp4)
    viddub-ffm.py video.mp4 audio.mp3

    # Merge with custom output path
    viddub-ffm.py video.mp4 narration.wav --output-path final.mp4

    # Replace original audio with dubbed track
    viddub-ffm.py original.mp4 dubbed_audio.m4a --output-path dubbed.mp4

Note: Video is copied (no re-encoding), audio is converted to AAC.
      Uses 'shortest' mode - output length matches shorter input.
"""

from pathlib import Path

import ffmpeg
import fire


def merge_video_audio(video_path: str, audio_path: str, output_path: str = None):
    video_path = Path(video_path)
    audio_path = Path(audio_path)

    if not output_path:
        output_path = audio_path.with_name(f"{audio_path.stem}.{video_path.suffix}")
    else:
        output_path = Path(output_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    input_video = ffmpeg.input(str(video_path))
    input_audio = ffmpeg.input(str(audio_path))

    (
        ffmpeg.output(
            input_video,
            input_audio.audio,
            str(output_path),
            vcodec="copy",
            acodec="aac",
            shortest=None,
        )
        .overwrite_output()
        .run()
    )

    print(f"Output saved as: {output_path}")


if __name__ == "__main__":
    fire.Fire(merge_video_audio)
