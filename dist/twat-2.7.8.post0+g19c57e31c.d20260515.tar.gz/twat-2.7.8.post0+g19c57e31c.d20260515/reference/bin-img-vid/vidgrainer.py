#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "ffmpeg-python", "rich"]
# ///
# this_file: vidgrainer.py

"""
vidgrainer.py - A CLI tool for applying film grain effects to videos.

This tool uses ffmpeg to apply customizable film grain effects to video files.
It offers multiple presets and can intelligently analyze videos to recommend
the best grain settings.

Commands:
    info: Analyze a video file and provide information
    test: Generate test clips with different grain presets
    grain: Apply a specific grain preset to a video

Examples:
    # Get video info and grain recommendations
    vidgrainer.py info video.mp4

    # Generate test clips with all 4 presets to compare
    vidgrainer.py test video.mp4

    # Apply preset 1 (light grain, desaturated - subtle vintage)
    vidgrainer.py grain video.mp4 --preset 1

    # Apply preset 2 (strong grain, desaturated - heavy film look)
    vidgrainer.py grain video.mp4 --preset 2

    # Apply preset 3 (light grain, normal saturation)
    vidgrainer.py grain video.mp4 --preset 3

    # Apply preset 4 (strong grain, normal saturation - bold film effect)
    vidgrainer.py grain video.mp4 --preset 4

    # Custom output path
    vidgrainer.py grain video.mp4 --preset 2 --output grainy_video.mp4

Presets:
    1: Light grain (6), desaturated (0.85) - subtle vintage look
    2: Strong grain (10), desaturated (0.85) - heavy film look
    3: Light grain (6), normal saturation (1.0) - subtle texture
    4: Strong grain (10), normal saturation (1.0) - bold film effect
"""

import os
import re
import subprocess
import sys
from pathlib import Path

import ffmpeg
import fire
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

# Grain presets configuration
# Format: (strength, saturation)
PRESETS = {
    1: (6, 0.85),  # Light grain, low saturation
    2: (10, 0.85),  # Strong grain, low saturation
    3: (6, 1.0),  # Light grain, normal saturation
    4: (10, 1.0),  # Strong grain, normal saturation
}


def get_video_info(video_path: str) -> dict:
    """
    Get detailed information about a video file using ffprobe.

    Args:
        video_path: Path to the video file

    Returns:
        Dictionary containing video metadata
    """
    try:
        probe = ffmpeg.probe(video_path)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )

        if not video_stream:
            console.print(
                "[bold red]Error:[/bold red] No video stream found in the file."
            )
            sys.exit(1)

        return {
            "width": int(video_stream.get("width", 0)),
            "height": int(video_stream.get("height", 0)),
            "codec_name": video_stream.get("codec_name", "unknown"),
            "duration": float(probe.get("format", {}).get("duration", 0)),
            "bit_rate": int(probe.get("format", {}).get("bit_rate", 0)),
            "format_name": probe.get("format", {}).get("format_name", "unknown"),
            "raw": video_stream,
        }
    except ffmpeg.Error as e:
        console.print(f"[bold red]Error:[/bold red] {e.stderr.decode()}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        sys.exit(1)


def detect_existing_grain(video_path: str) -> float:
    """
    Analyze the video to detect if it already has film grain.
    Uses variance in pixel values of flat areas as a heuristic.

    Args:
        video_path: Path to the video file

    Returns:
        Float between 0.0 and 1.0 indicating the estimated amount of grain
    """
    # Use a much faster, more efficient approach
    try:
        # Get video info
        info = get_video_info(video_path)

        # Extract a single frame from 20% into the video (likely to have good content)
        middle_time = float(info["duration"]) * 0.2

        # Use ffmpeg to extract a single frame and analyze its noise characteristics
        # by scaling it down (faster) and using the signalstats filter
        cmd = [
            "ffmpeg",
            "-ss",
            str(middle_time),
            "-i",
            video_path,
            "-vframes",
            "1",
            "-vf",
            "scale=320:240,signalstats",
            "-f",
            "null",
            "-",
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            timeout=5,  # Don't wait too long
        )

        # Parse the output for noise indicators
        stderr = result.stderr.decode()

        # Look for specific stats that indicate noise/grain
        # YAVG is luminance average, YDIF is frame difference
        avg_vals = re.findall(r"YAVG:([0-9.]+)", stderr)
        dif_vals = re.findall(r"YDIF:([0-9.]+)", stderr)

        # Use a simple heuristic based on the Y difference value
        if dif_vals and avg_vals:
            # Higher YDIF relative to YAVG indicates more grain/noise
            y_dif = float(dif_vals[0])
            y_avg = float(avg_vals[0])

            # Normalize to a 0-1 scale with a reasonable threshold
            # Values over 1.0 indicate heavy grain
            grain_estimate = min(1.0, (y_dif / y_avg) * 5.0)
            return grain_estimate

        # Fallback if we couldn't get good metrics
        return 0.3  # Assume moderate-low grain

    except Exception as e:
        console.print(f"[yellow]Warning:[/yellow] Could not analyze grain: {str(e)}")
        return 0.3  # Default to moderate-low grain level


def detect_color_intensity(video_path: str) -> float:
    """
    Analyze the video to detect its color intensity/saturation.

    Args:
        video_path: Path to the video file

    Returns:
        Float between 0.0 and 1.0 indicating the color intensity
    """
    try:
        # Get video info
        info = get_video_info(video_path)

        # Sample a frame from 30% into the video
        sample_time = float(info["duration"]) * 0.3

        # Use a much faster approach with ffmpeg's signalstats filter
        # which provides color measurements
        cmd = [
            "ffmpeg",
            "-ss",
            str(sample_time),
            "-i",
            video_path,
            "-vframes",
            "1",
            "-vf",
            "scale=320:240,signalstats",
            "-f",
            "null",
            "-",
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            timeout=5,  # Reasonable timeout
        )

        # Parse the output for color saturation indicators
        stderr = result.stderr.decode()

        # Look for color saturation indicators (UAVG and VAVG for chroma values)
        u_avg_vals = re.findall(r"UAVG:([0-9.]+)", stderr)
        v_avg_vals = re.findall(r"VAVG:([0-9.]+)", stderr)

        if u_avg_vals and v_avg_vals:
            # Get the U and V chroma values (higher = more saturation)
            u_avg = abs(float(u_avg_vals[0]) - 128.0)  # Distance from neutral gray
            v_avg = abs(float(v_avg_vals[0]) - 128.0)  # Distance from neutral gray

            # Calculate overall saturation (normalize to 0-1 range)
            # Max theoretical distance from gray is ~128 on each channel
            saturation = min(1.0, (u_avg + v_avg) / 128.0)
            return saturation

        # Fallback if we couldn't get good metrics
        return 0.5  # Assume moderate saturation

    except Exception as e:
        console.print(
            f"[yellow]Warning:[/yellow] Could not analyze color intensity: {str(e)}"
        )
        return 0.5  # Default to middle value


def recommend_preset(video_path: str) -> int:
    """
    Analyze the video and recommend the best grain preset to apply.

    Args:
        video_path: Path to the video file

    Returns:
        Integer representing the recommended preset number
    """
    try:
        # Detect existing grain level (0.0 to 1.0)
        grain_level = detect_existing_grain(video_path)

        # Detect color intensity/saturation (0.0 to 1.0)
        color_intensity = detect_color_intensity(video_path)

        console.print(f"[dim]Detected grain level: {grain_level:.2f}[/dim]")
        console.print(f"[dim]Detected color intensity: {color_intensity:.2f}[/dim]")

        # Decision logic for preset selection
        if grain_level > 0.5:
            # Already has significant grain
            grain_strength = "light"  # Choose lighter grain (1 or 3)
        else:
            # Low grain, can add more
            grain_strength = "strong"  # Choose stronger grain (2 or 4)

        if color_intensity > 0.6:
            # High color intensity
            saturation = "low"  # Choose lower saturation (1 or 2)
        else:
            # Low color intensity
            saturation = "normal"  # Choose normal saturation (3 or 4)

        # Map decision to preset number
        preset_map = {
            ("light", "low"): 1,
            ("strong", "low"): 2,
            ("light", "normal"): 3,
            ("strong", "normal"): 4,
        }

        return preset_map[(grain_strength, saturation)]

    except Exception as e:
        console.print(
            f"[yellow]Warning:[/yellow] Could not determine optimal preset: {str(e)}"
        )
        return 3  # Default to preset 3 as a safe middle ground


def determine_hardware_acceleration() -> tuple[bool, str]:
    """
    Detect if hardware acceleration is available and which method to use.

    Returns:
        Tuple of (is_available, method_name)
    """
    # Check for hardware acceleration options
    hw_methods = [
        # Apple Silicon / macOS
        ("videotoolbox", "-hwaccel videotoolbox"),
        # NVIDIA GPUs
        ("cuda", "-hwaccel cuda"),
        # AMD GPUs on Windows/Linux
        ("amf", "-hwaccel amf"),
        # Intel GPUs
        ("qsv", "-hwaccel qsv"),
        # Generic
        ("auto", "-hwaccel auto"),
    ]

    for method, option in hw_methods:
        try:
            # Try running ffmpeg with the acceleration option
            result = subprocess.run(
                [
                    "ffmpeg",
                    *option.split(),
                    "-hide_banner",
                    "-f",
                    "lavfi",
                    "-i",
                    "nullsrc",
                    "-t",
                    "0.1",
                    "-f",
                    "null",
                    "-",
                ],
                capture_output=True,
                timeout=2,  # Short timeout
            )

            # If no error about hwaccel, assume it's supported
            stderr = result.stderr.decode().lower()
            if (
                "error" not in stderr
                and "unable" not in stderr
                and "invalid" not in stderr
            ):
                return True, method

        except (subprocess.SubprocessError, OSError):
            continue

    # No hardware acceleration available
    return False, "none"


def create_output_path(
    input_path: str, preset_num: int, output_path: str | None = None
) -> str:
    """
    Create the output path based on input path and preset.

    Args:
        input_path: Path to the input video file
        preset_num: Preset number used
        output_path: Optional user-specified output path

    Returns:
        Path for the output file
    """
    if output_path:
        return output_path

    # Create default output path
    input_file = Path(input_path)
    output_name = f"{input_file.stem}-grain{preset_num}.mp4"
    return str(input_file.parent / output_name)


def apply_grain(
    input_path: str,
    output_path: str,
    preset_num: int,
    duration: float | None = None,
    start_time: float | None = None,
) -> None:
    """
    Apply grain effect to the video.

    Args:
        input_path: Path to the input video file
        output_path: Path for the output file
        preset_num: Preset number to use
        duration: Optional duration to limit processing (for test clips)
        start_time: Optional start time for processing (for test clips)
    """
    # Get preset parameters
    grain_strength, saturation = PRESETS.get(preset_num, PRESETS[3])

    # Check if hardware acceleration is available
    hw_accel, hw_method = determine_hardware_acceleration()

    try:
        # Start building the ffmpeg command
        input_options = {}
        if hw_accel:
            input_options["hwaccel"] = "auto"

        if start_time is not None:
            input_options["ss"] = str(start_time)  # Convert float to string for ffmpeg

        # For duration limiting, we'll use the -t option instead of a trim filter
        output_options = {
            "c:v": "libx264",
            "crf": 18,
            "preset": "medium",  # Balance between speed and quality
            "tune": "film",
            "pix_fmt": "yuv420p",
        }

        if duration is not None:
            output_options["t"] = str(duration)

        # Input file
        stream = ffmpeg.input(input_path, **input_options)

        # Apply the grain effect and other enhancements
        video = (
            stream.video.filter("eq", contrast=1.1, saturation=saturation)
            .filter("unsharp", 5, 5, 1, 5, 5, 0)
            .filter("noise", alls=grain_strength, allf="t")
        )

        # Check if the input has an audio stream
        has_audio = False
        probe = ffmpeg.probe(input_path)
        for stream_info in probe["streams"]:
            if stream_info.get("codec_type") == "audio":
                has_audio = True
                break

        # For x264, add options to better preserve grain
        output_options["x264opts"] = "no-dct-decimate=1:no-fast-pskip=1"

        # Add advanced multithreading options
        output_options["threads"] = "auto"

        # Run the ffmpeg command
        if has_audio:
            # If there's audio, include it
            audio = stream.audio
            output_options["c:a"] = "aac"
            output_options["b:a"] = "192k"
            ffmpeg.output(video, audio, output_path, **output_options).run(
                capture_stdout=True, capture_stderr=True, overwrite_output=True
            )
        else:
            # Video only
            ffmpeg.output(video, output_path, **output_options).run(
                capture_stdout=True, capture_stderr=True, overwrite_output=True
            )

    except ffmpeg.Error as e:
        console.print("[bold red]Error during processing:[/bold red]")
        console.print(e.stderr.decode())
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Unexpected error:[/bold red] {str(e)}")
        sys.exit(1)


class VidGrainer:
    """Video Grain Effect CLI Tool"""

    def info(self, video_path: str) -> None:
        """
        Analyze a video file and print information.

        Args:
            video_path: Path to the video file
        """
        if not os.path.exists(video_path):
            console.print(f"[bold red]Error:[/bold red] File not found: {video_path}")
            return

        with console.status("[bold green]Analyzing video..."):
            info = get_video_info(video_path)
            grain_level = detect_existing_grain(video_path)
            color_intensity = detect_color_intensity(video_path)
            recommended_preset = recommend_preset(video_path)

        # Create a table with video information
        table = Table(title=f"Video Analysis: {os.path.basename(video_path)}")

        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Resolution", f"{info['width']}x{info['height']}")
        table.add_row("Codec", info["codec_name"])
        table.add_row("Duration", f"{float(info['duration']):.2f} seconds")
        table.add_row("Bitrate", f"{int(info['bit_rate']) // 1000} kbps")
        table.add_row("Format", info["format_name"])
        table.add_row("Existing Grain", f"{grain_level:.2f} (0=none, 1=heavy)")
        table.add_row("Color Intensity", f"{color_intensity:.2f} (0=low, 1=high)")
        table.add_row("Recommended Preset", f"Preset {recommended_preset}")

        console.print(table)

        # Explain the recommendation
        grain_strength, saturation = PRESETS[recommended_preset]

        preset_description = Panel(
            f"[bold]Recommended:[/bold] Preset {recommended_preset}\n"
            f"Grain Strength: {'Light' if grain_strength <= 6 else 'Strong'}\n"
            f"Saturation: {'Reduced' if saturation < 1.0 else 'Normal'}\n\n"
            f"To apply this preset: [bold]vidgrainer.py grain {video_path} --preset={recommended_preset}[/bold]",
            title="Grain Preset Recommendation",
            border_style="green",
        )

        console.print(preset_description)

    def test(self, video_path: str) -> None:
        """
        Create test clips with different grain presets.

        Args:
            video_path: Path to the video file
        """
        if not os.path.exists(video_path):
            console.print(f"[bold red]Error:[/bold red] File not found: {video_path}")
            return

        # Create test directory
        video_path = os.path.abspath(video_path)
        input_path = Path(video_path)
        test_dir = input_path.parent / f"test--{input_path.stem}"

        # Ensure directory exists
        os.makedirs(test_dir, exist_ok=True)

        # Create a short test clip
        test_clip_path = test_dir / f"test--{input_path.stem}.mp4"

        # Get video info to find a good starting point
        with console.status("[bold green]Analyzing video..."):
            info = get_video_info(video_path)

        # Extract a 2 second clip from 10% into the video
        start_time = float(info["duration"]) * 0.1
        test_duration = 2.0

        console.print(
            f"[bold]Creating 2-second test clip at {start_time:.1f}s mark...[/bold]"
        )

        # Create the basic test clip
        try:
            # Create a clean test clip without grain
            (
                ffmpeg.input(video_path, ss=start_time, t=test_duration)
                .output(str(test_clip_path), c="copy")
                .run(capture_stdout=True, capture_stderr=True, overwrite_output=True)
            )

            console.print(f"✅ Created test clip: [cyan]{test_clip_path}[/cyan]")
        except ffmpeg.Error as e:
            console.print("[bold red]Error creating test clip:[/bold red]")
            console.print(e.stderr.decode())
            return

        # Apply each preset
        for preset_num in PRESETS.keys():
            preset_output = test_dir / f"preset{preset_num}--{input_path.stem}.mp4"

            console.print(f"Applying preset {preset_num}...")

            # Apply grain with the current preset
            try:
                apply_grain(
                    input_path=video_path,
                    output_path=str(preset_output),
                    preset_num=preset_num,
                    duration=test_duration,
                    start_time=start_time,
                )
                console.print(
                    f"✅ Created preset {preset_num}: [cyan]{preset_output}[/cyan]"
                )
            except Exception as e:
                console.print(
                    f"[bold red]Error applying preset {preset_num}:[/bold red] {str(e)}"
                )

        console.print(f"\n[bold green]Test clips generated in:[/bold green] {test_dir}")
        console.print(
            "[bold]Review the clips to choose your preferred grain preset.[/bold]"
        )

    def grain(
        self,
        video_path: str,
        preset: int | None = None,
        output: str | None = None,
    ) -> None:
        """
        Apply grain effect to a video.

        Args:
            video_path: Path to the video file
            preset: Grain preset number (1-4). If not specified, will be automatically determined.
            output: Output file path. If not specified, will use the same name with a -grain suffix.
        """
        if not os.path.exists(video_path):
            console.print(f"[bold red]Error:[/bold red] File not found: {video_path}")
            return

        # If preset is not specified, recommend one
        if preset is None:
            with console.status(
                "[bold green]Analyzing video to determine optimal grain settings..."
            ):
                preset = recommend_preset(video_path)
            console.print(f"[bold]Automatically selected preset {preset}[/bold]")
        elif preset not in PRESETS:
            console.print(
                "[bold red]Error:[/bold red] Invalid preset number. Choose from 1-4."
            )
            return

        # Create output path
        output_path = create_output_path(video_path, preset, output)

        # Display information about the processing
        info = get_video_info(video_path)
        grain_strength, saturation = PRESETS[preset]

        console.print(
            Panel(
                f"Processing [bold]{os.path.basename(video_path)}[/bold]\n"
                f"Resolution: {info['width']}x{info['height']}\n"
                f"Duration: {float(info['duration']):.2f} seconds\n"
                f"Preset: {preset} (Grain: {grain_strength}, Saturation: {saturation})\n"
                f"Output: [cyan]{output_path}[/cyan]",
                title="Applying Film Grain",
                border_style="green",
            )
        )

        # Apply the grain effect
        with console.status(
            "[bold green]Processing video... This may take some time depending on the file size."
        ):
            apply_grain(video_path, output_path, preset)

        get_video_info(output_path)
        output_size = os.path.getsize(output_path) / (1024 * 1024)  # Convert to MB

        console.print("[bold green]✅ Processing complete![/bold green]")
        console.print(f"Output file: [cyan]{output_path}[/cyan]")
        console.print(f"File size: {output_size:.1f} MB")


def main():
    """Main entry point for the tool."""
    try:
        fire.Fire(VidGrainer)
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Process interrupted by user.[/bold yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Unexpected error:[/bold red] {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
