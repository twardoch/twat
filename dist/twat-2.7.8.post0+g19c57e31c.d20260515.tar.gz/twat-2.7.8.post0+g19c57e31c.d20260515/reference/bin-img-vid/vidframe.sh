#!/usr/bin/env bash
# this_file: vidframe.sh
# Extract a frame from an MP4 video and save it as a JPG

set -euo pipefail

if [ $# -lt 1 ] || [ $# -gt 2 ]; then
    echo "Usage: $0 <path_to_mp4> [frame_number]"
    echo "  path_to_mp4: Path to the MP4 video file"
    echo "  frame_number: Optional frame number to extract (default: 0)"
    exit 1
fi

VIDEO_PATH="$1"
FRAME_NUMBER="${2:-0}"

# Validate input file exists and is an MP4
if [ ! -f "$VIDEO_PATH" ]; then
    echo "Error: Video file does not exist: $VIDEO_PATH" >&2
    exit 1
fi

if [[ "$VIDEO_PATH" != *.mp4 && "$VIDEO_PATH" != *.MP4 ]]; then
    echo "Error: Input file must be an MP4 video: $VIDEO_PATH" >&2
    exit 1
fi

# Validate frame number is a non-negative integer
if ! [[ "$FRAME_NUMBER" =~ ^[0-9]+$ ]]; then
    echo "Error: frame_number must be a non-negative integer: $FRAME_NUMBER" >&2
    exit 1
fi

# Determine output path (same folder and basename as video, with .jpg extension)
DIRNAME=$(dirname "$VIDEO_PATH")
BASENAME=$(basename "$VIDEO_PATH" .mp4)
BASENAME=$(basename "$BASENAME" .MP4)
OUTPUT_PATH="${DIRNAME}/${BASENAME}.jpg"

# Extract the specified frame
ffmpeg -i "$VIDEO_PATH" -vf "select=eq(n\,${FRAME_NUMBER})" -vsync vfr -q:v 2 "$OUTPUT_PATH" -y -loglevel quiet

if [ $? -eq 0 ] && [ -f "$OUTPUT_PATH" ]; then
    echo "Extracted frame ${FRAME_NUMBER} from $(basename "$VIDEO_PATH")"
    echo "Output: $OUTPUT_PATH"
else
    echo "Error: Failed to extract frame" >&2
    exit 1
fi
