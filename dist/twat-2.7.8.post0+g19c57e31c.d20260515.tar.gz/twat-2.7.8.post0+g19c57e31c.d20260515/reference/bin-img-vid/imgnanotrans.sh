#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")" || exit 1
cd 13-img/
for p in *.jpeg; do
	echo "$p"
    ../imgnanobanatrans.py -i "$p" -r ../ref1.jpg -o "../14-img/${p}" -m pro3
	../imgrmbg2.py white -i "../14-img/${p}" -o "../15-img/${p}"
done
