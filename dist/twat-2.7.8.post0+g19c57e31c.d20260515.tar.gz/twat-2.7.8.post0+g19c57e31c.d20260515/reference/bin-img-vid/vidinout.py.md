
Develop @vidinout.py , a Fire CLI app that does this: 

- take --path to the input video
- optionally take --output path to the output video (auto-generated if not given)
- take --start_speed which is the multiplier in % (that means, the very beginning runs 2x faster if 200 is given), default = 100
- take --start_numf which is the number of input video’s frames which pass from the start_speed until the speed catches up to 100%, default = 30
- take --end_speed which is the analogical multiplier for the very end speed change, default = 100
- take --end_numf which is the number of input video’s frames at the end which pass to the final speed specified by end_speed, default = 30 
- take --fadein_color which is the rrggbb or rrggbbaa color which becomes the solid first frame if specified (aa only used if output is .mov, otherwise ignored), default = 000000
- take --fadein_numf which is the number of frames which is the duration of the fade-in
- take --fadeout_color which is analogical as fadein_color but for the end frame, default = fadein_color
- take --fadeout_numf, analogical
- speed_function should be some enum defining how the speed changes, default should be 'desi' (double-exponential sigmoid, akin to ffmpeg’s audio afade/acrossfade)
- fade_function should be analogical but for the fade effects, default should be the same as speed_function

And then performs the specified actions and outputs the new video. 