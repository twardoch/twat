#!/usr/bin/env -S uv run -s
# /// script
# dependencies = [
#     "fire",
#     "ffmpeg-python",
#     "loguru",
#     "rich"
# ]
# ///
# this_file: vidmenubar.py

"""
vidmenubar.py - Tool to cover menubar icons in macOS screen recordings

This tool takes a macOS screen recording and covers menubar icons in the top-
right corner by overlaying a clean section of the menubar from the first frame.

Features:
- Single-pass processing using FFmpeg filter complex
- Hardware acceleration (h264_videotoolbox) for max speed
- Preserves audio track
- Rich progress logging and error handling

Usage:
    vidmenubar.py --input_video screen_recording.mp4
    vidmenubar.py input_video.mp4 --height 80 --width 15
    vidmenubar.py input_video.mp4 --output_video cleaned.mp4
"""

import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

import fire
from loguru import logger
from rich.console import Console

# Set up logging
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{message}</level>",
    level="INFO",
)

console = Console()


class VideoMenuBarProcessor:
    """
    Processor for covering menubar icons in macOS screen recordings.

    Uses a single-pass FFmpeg command to extract a clean menubar section
    from the first frame and overlay it on the menubar icons area.
    """

    def __init__(self, verbose: bool = False):
        """
        Initialize the processor.

        Args:
            verbose: Enable verbose logging
        """
        if verbose:
            logger.remove()
            logger.add(sys.stderr, level="DEBUG")

        self.verbose = verbose

    def get_video_info(self, video_path: str) -> Tuple[int, int]:
        """
        Get video dimensions using ffprobe.

        Args:
            video_path: Path to input video

        Returns:
            Tuple of (width, height)
        """
        try:
            # Use ffprobe to get video information
            cmd = [
                "ffprobe", "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=width,height", "-of", "csv=p=0",
                video_path
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, check=True
            )
            
            # Parse the output: width,height
            dimensions = result.stdout.strip().split(',')
            if len(dimensions) != 2:
                raise ValueError("Could not parse video dimensions")
                
            width = int(dimensions[0])
            height = int(dimensions[1])
            return width, height
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Error probing video: {e.stderr}")
            raise
        except Exception as e:
            logger.error(f"Error probing video: {e}")
            raise

    def process_video(
        self,
        input_path: str,
        output_path: str,
        source_x: int,
        source_y: int,
        source_width: int,
        source_height: int,
        target_x: int,
        target_y: int,
    ) -> bool:
        """
        Process video in a single pass: crop source area from first frame,
        loop it, and overlay on target area.

        Args:
            input_path: Path to input video
            output_path: Path to output video
            source_x: X coordinate of source area
            source_y: Y coordinate of source area
            source_width: Width of source area
            source_height: Height of source area
            target_x: X coordinate of target area
            target_y: Y coordinate of target area

        Returns:
            True if successful, False otherwise
        """
        try:
            # Filter complex explanation:
            # [0:v]split[main][copy] -> Split input into two streams
            # [copy]crop=w:h:x:y[cropped] -> Crop the source area from the copy
            # [cropped]select=eq(n\,0)[first_frame] -> Keep only the first frame
            # [first_frame]loop=-1:1:0[mask] -> Loop the first frame indefinitely
            # [main][mask]overlay=x:y[out] -> Overlay the looped mask onto the main video
            
            # Note: We don't strictly need 'split' if we use the input twice, 
            # but using split is often cleaner in filter graphs. 
            # However, for simple overlay with static image from same video, 
            # we can just use the input as [0:v] twice if we map it carefully, 
            # or just use split. Let's use split for clarity.
            
            filter_complex = (
                f"[0:v]split[main][copy];"
                f"[copy]crop={source_width}:{source_height}:{source_x}:{source_y},"
                f"select=eq(n\\,0),loop=-1:1:0[mask];"
                f"[main][mask]overlay={target_x}:{target_y}"
            )

            # Build FFmpeg command
            # Note: We explicitly set pixel format to yuv420p for compatibility
            base_cmd = [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "info" if self.verbose else "error",
                "-i", input_path,
                "-filter_complex", filter_complex,
                "-c:a", "copy",
                "-pix_fmt", "yuv420p",
                "-y",
            ]

            # Try Hardware Acceleration first (VideoToolbox on macOS)
            # Key fixes:
            # 1. Add hardware decoding for faster input (frames to system memory for filters)
            # 2. Use -b:v for bitrate instead of -q:v (which doesn't work with VideoToolbox)
            # 3. Add -allow_sw 1 to allow software fallback within VideoToolbox if needed
            # 4. Use high bitrate for quality (15M ~= CRF 18 for high-res video)
            # Note: Filters run on CPU, so we decode to system memory, filter, then HW encode
            cmd_hw = [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "info" if self.verbose else "error",
                "-hwaccel", "videotoolbox",  # Hardware-accelerated decode
                "-i", input_path,
                "-filter_complex", filter_complex,
                "-c:v", "h264_videotoolbox",  # Hardware-accelerated encode
                "-b:v", "15M",  # High bitrate for quality (~CRF 18 equivalent)
                "-allow_sw", "1",  # Allow software fallback if HW encoder unavailable
                "-c:a", "copy",
                "-pix_fmt", "yuv420p",
                "-y",
                output_path,
            ]

            logger.info("Processing video with menubar overlay (Hardware Accelerated)...")
            if self.verbose:
                logger.debug(f"Command: {' '.join(cmd_hw)}")

            try:
                result = subprocess.run(cmd_hw, capture_output=True, text=True, check=True)

                # Check if output is valid (non-zero size)
                if Path(output_path).exists() and Path(output_path).stat().st_size > 0:
                    logger.success(f"Video processed successfully with hardware acceleration: {output_path}")
                    return True
                else:
                    logger.warning("Hardware encoding produced empty file. Falling back to software encoding...")
                    if self.verbose and result.stderr:
                        logger.debug(f"Hardware stderr: {result.stderr}")
            except subprocess.CalledProcessError as e:
                stderr = e.stderr if e.stderr else str(e)
                logger.warning(f"Hardware encoding failed: {stderr}. Falling back to software encoding...")
                if self.verbose:
                    logger.debug(f"Full hardware error: {e}")

            # Fallback to Software Encoding (libx264 ultrafast)
            cmd_sw = base_cmd + [
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "18",
                output_path,
            ]
            
            logger.info("Processing video with menubar overlay (Software - Ultrafast)...")
            if self.verbose:
                logger.debug(f"Command: {' '.join(cmd_sw)}")

            subprocess.run(cmd_sw, capture_output=True, check=True)

            logger.success(f"Video processed successfully: {output_path}")
            return True

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode() if e.stderr else str(e)
            logger.error(f"FFmpeg error during processing: {stderr}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during processing: {e}")
            return False


def validate_parameters(
    input_video: str,
    height: int,
    width_percent: int
) -> None:
    """
    Validate input parameters.

    Args:
        input_video: Path to input video
        height: Height in pixels
        width_percent: Width as percentage

    Raises:
        ValueError: If parameters are invalid
    """
    if not input_video:
        raise ValueError("input_video is required")

    input_path = Path(input_video).expanduser()  # Expand ~ to home directory
    if not input_path.exists():
        raise ValueError(f"Input video does not exist: {input_video}")

    if not input_path.is_file():
        raise ValueError(f"Input path is not a file: {input_video}")

    if height <= 0:
        raise ValueError("Height must be positive")

    if width_percent <= 0 or width_percent > 100:
        raise ValueError("Width percentage must be between 1 and 100")


def generate_output_path(input_video: str) -> str:
    """
    Generate default output path based on input video.

    Args:
        input_video: Path to input video

    Returns:
        Default output video path
    """
    input_path = Path(input_video)
    output_name = f"{input_path.stem}_menubar.mp4"
    return str(input_path.parent / output_name)


def menubar_cover(
    input_video: str,
    height: int = 60,
    width: int = 10,
    output_video: Optional[str] = None,
    verbose: bool = False,
) -> None:
    """
    Cover menubar icons in a macOS screen recording.

    Args:
        input_video: Path to the macOS screen recording video
        height: Height of menubar in pixels (default: 60 for Retina displays)
        width: Width of target area as percent of screen width (default: 10)
        output_video: Output path (default: adds _menubar suffix to input)
        verbose: Enable verbose logging for debugging
    """
    if verbose:
        logger.info("Verbose mode enabled")

    try:
        # Expand tilde in input path
        input_video = str(Path(input_video).expanduser())

        # Validate parameters
        validate_parameters(input_video, height, width)

        # Generate output path if not provided
        if not output_video:
            output_video = generate_output_path(input_video)

        logger.info(f"Processing video: {Path(input_video).name}")
        logger.info(f"Menubar height: {height}px")
        logger.info(f"Target width: {width}%")
        logger.info(f"Output: {output_video}")

        # Initialize processor
        processor = VideoMenuBarProcessor(verbose=verbose)

        # Get video dimensions
        video_width, video_height = processor.get_video_info(input_video)
        logger.info(f"Video dimensions: {video_width}x{video_height}")

        # Calculate areas
        target_width = int(video_width * width / 100)
        target_x = video_width - target_width  # Right edge
        target_y = 0  # Top edge
        source_x = target_x - target_width  # Immediately to the left
        source_y = 0  # Same height

        # Validate coordinates
        if source_x < 0:
            raise ValueError(
                f"Source area extends beyond left edge ({source_x} < 0). "
                f"Consider reducing width percentage."
            )

        logger.info(
            f"Target area: {target_width}x{height} at ({target_x}, {target_y})"
        )
        logger.info(
            f"Source area: {target_width}x{height} at ({source_x}, {source_y})"
        )

        # Process video
        success = processor.process_video(
            input_video,
            output_video,
            source_x,
            source_y,
            target_width,
            height,
            target_x,
            target_y
        )

        if success:
            # Check output file size
            input_size = Path(input_video).stat().st_size
            output_size = Path(output_video).stat().st_size
            size_change = (output_size - input_size) / input_size * 100

            logger.success("✓ Menubar icons covered successfully!")
            logger.info(f"Size change: {size_change:+.1f}%")
            logger.info(f"Output saved to: {output_video}")
        else:
            logger.error("Failed to process video")
            raise RuntimeError("Video processing failed")

    except Exception as e:
        logger.error(f"Error: {e}")
        if verbose:
            logger.exception("Full error details:")
        raise


def main():
    """Main entry point for Fire CLI."""
    fire.Fire(menubar_cover)


if __name__ == "__main__":
    main()
