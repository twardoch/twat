#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["av", "fire"]
# ///
# this_file: viddub-av.py

"""
Merge video and audio streams from separate files using PyAV.

Fast stream-copy operation (no re-encoding) - combines video track from one file
with audio track from another. Useful for dubbing, replacing audio, or adding
voiceovers to videos.

Examples:
    # Merge video.mp4 video with audio.mp3 audio (output: audio.mp4)
    viddub-av.py video.mp4 audio.mp3

    # Merge with custom output path
    viddub-av.py video.mp4 narration.wav --output-path final.mp4

    # Replace video's audio with new track
    viddub-av.py original.mp4 new_audio.aac --output-path dubbed.mp4

Note: Uses stream copy (no re-encoding) for maximum speed.
      Video and audio durations should match for best results.
"""

from pathlib import Path

import av
import fire


def merge_video_audio(video_path: str, audio_path: str, output_path: str = None):
    video_path = Path(video_path)
    audio_path = Path(audio_path)

    if not output_path:
        output_path = audio_path.with_name(f"{audio_path.stem}.{video_path.suffix}")
    else:
        output_path = Path(output_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with (
        av.open(str(video_path)) as video_container,
        av.open(str(audio_path)) as audio_container,
        av.open(str(output_path), mode="w") as output_container,
    ):
        video_stream = video_container.streams.video[0]
        audio_stream = audio_container.streams.audio[0]

        output_video = output_container.add_stream(template=video_stream)
        output_audio = output_container.add_stream(template=audio_stream)

        for packet in video_container.demux(video_stream):
            packet.stream = output_video
            output_container.mux(packet)

        for packet in audio_container.demux(audio_stream):
            packet.stream = output_audio
            output_container.mux(packet)

    print(f"Output saved as: {output_path}")


if __name__ == "__main__":
    fire.Fire(merge_video_audio)
