#!/usr/bin/env bash
# this_file: vidstartendframeall.sh
set -euo pipefail

DIR="${1:-.}"
fd "" "$DIR" --extension mov --extension mp4 --type f --absolute-path -x ~/bin/img/vidstartendframe.sh {}
