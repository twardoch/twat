#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "moviepy", "rich"]
# ///
# this_file: vidkenburns.py

"""
Create Ken Burns effect slideshow videos from PNG images.

Creates smooth zoom and pan animations across images with optional audio soundtrack.
Images are randomly shuffled and each gets random zoom/pan movements.

Examples:
    # Basic slideshow from images folder (uses default 5s per image)
    vidkenburns.py ./images

    # Slideshow with specific duration (60 seconds total)
    vidkenburns.py ./images --duration 60

    # Slideshow with background music (duration matches audio)
    vidkenburns.py ./images --audio background.mp3

    # Custom output folder
    vidkenburns.py ./images --output-folder ./output

    # Debug mode (saves intermediate clips)
    vidkenburns.py ./images --audio music.mp3 --debug

Output:
    - Creates MP4 video with Ken Burns zoom/pan effects
    - If audio provided: {folder_name}_{timestamp}_with_audio.mp4
    - If no audio: {folder_name}_{timestamp}.mp4
"""

import datetime
import os
import random
from pathlib import Path

import fire
from moviepy.editor import *
from moviepy.video.fx.all import crop
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


def get_random_zoom(min_zoom: float = 1.0, max_zoom: float = 1.5) -> float:
    return random.uniform(min_zoom, max_zoom)


def get_random_pan(
    image_size: tuple[int, int], output_size: tuple[int, int]
) -> tuple[int, int]:
    x_max = max(0, image_size[0] - output_size[0])
    y_max = max(0, image_size[1] - output_size[1])
    return (random.randint(0, x_max), random.randint(0, y_max))


def create_ken_burns_clip(
    image_path: str, duration: float, output_size: tuple[int, int]
) -> VideoClip:
    console.log(f"Creating Ken Burns clip for {image_path}")
    img = ImageClip(image_path)
    img_size = img.size

    start_zoom = get_random_zoom()
    end_zoom = get_random_zoom()

    start_pan = get_random_pan(img_size, output_size)
    end_pan = get_random_pan(img_size, output_size)

    def make_frame(t):
        progress = t / duration
        current_zoom = start_zoom + (end_zoom - start_zoom) * progress
        current_pan = (
            int(start_pan[0] + (end_pan[0] - start_pan[0]) * progress),
            int(start_pan[1] + (end_pan[1] - start_pan[1]) * progress),
        )

        zoomed = img.resize(current_zoom)
        cropped = crop(
            zoomed,
            x1=current_pan[0],
            y1=current_pan[1],
            width=output_size[0],
            height=output_size[1],
        )
        return cropped.get_frame(0)

    return VideoClip(make_frame, duration=duration)


def create_slideshow(
    input_folder: str,
    output_file: str,
    duration: float,
    output_size: tuple[int, int] = (1920, 1080),
    transition_duration: float = 1.0,
    debug: bool = False,
    work_folder: str = None,
):
    image_files = list(Path(input_folder).glob("*.png"))
    random.shuffle(image_files)

    console.log(f"Found {len(image_files)} PNG files in {input_folder}")

    clips = []
    remaining_duration = duration

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Creating clips...", total=duration)

        while remaining_duration > 0:
            for image_file in image_files:
                clip_duration = random.uniform(3, 7)
                if clip_duration > remaining_duration:
                    clip_duration = remaining_duration

                clip = create_ken_burns_clip(
                    str(image_file), clip_duration, output_size
                )
                clips.append(clip)

                if debug and work_folder:
                    debug_output = os.path.join(
                        work_folder, f"debug_clip_{len(clips)}.mp4"
                    )
                    clip.write_videofile(debug_output, fps=30, codec="libx264")

                remaining_duration -= clip_duration
                progress.update(task, advance=clip_duration)

                if remaining_duration <= 0:
                    break

            random.shuffle(image_files)

    console.log("Concatenating clips and adding transitions...")
    final_clip = concatenate_videoclips(clips, method="compose")
    final_clip = final_clip.set_duration(duration)

    console.log(f"Writing video to {output_file}")
    final_clip.write_videofile(output_file, fps=30, codec="libx264")

    return final_clip


def main(
    input_folder: str,
    output_folder: str = "vid",
    duration: float = None,
    audio: str = None,
    debug: bool = False,
):
    """
    Create a randomized slideshow video with Ken Burns effect and optional audio.

    Args:
    input_folder: Path to the folder containing PNG images.
    output_folder: Path to the output folder. Default is "vid".
    duration: Desired duration of the video in seconds. If not provided, it will be inferred from the audio file.
    audio: Path to the audio file (MP3, WAV, etc.) to be added to the video.
    debug: If True, output intermediate results as video clips.
    """
    console.log("Starting slideshow creation...")

    # Create output folder
    os.makedirs(output_folder, exist_ok=True)

    # Create work folder for debug output
    work_folder = None
    if debug:
        work_folder = os.path.join(output_folder, "work")
        os.makedirs(work_folder, exist_ok=True)

    # Handle audio
    audio_clip = None
    if audio:
        audio_clip = AudioFileClip(audio)
        if duration is None:
            duration = audio_clip.duration
        console.log(f"Audio duration: {audio_clip.duration:.2f} seconds")

    if duration is None:
        raise ValueError("Duration must be specified if no audio file is provided.")

    duration = float(duration)  # Ensure duration is a float
    console.log(f"Video duration: {duration:.2f} seconds")

    # Create output filename
    timestamp = datetime.datetime.now().strftime("%y%m%d%H%M%S")
    folder_name = os.path.basename(os.path.normpath(input_folder))
    output_file = os.path.join(output_folder, f"{folder_name}_{timestamp}.mp4")

    # Create video
    video_clip = create_slideshow(
        input_folder, output_file, duration, debug=debug, work_folder=work_folder
    )

    # Add audio if provided
    if audio_clip:
        if audio_clip.duration < duration:
            # Pad audio
            pad_duration = (duration - audio_clip.duration) / 2
            padded_audio = CompositeAudioClip([audio_clip.set_start(pad_duration)])
            padded_audio = padded_audio.set_duration(duration)
            final_clip = video_clip.set_audio(padded_audio)
        else:
            # Crop audio if necessary
            audio_clip = audio_clip.subclip(0, duration)
            final_clip = video_clip.set_audio(audio_clip)

        final_output = os.path.join(
            output_folder, f"{folder_name}_{timestamp}_with_audio.mp4"
        )
        console.log(f"Writing final video with audio to {final_output}")
        final_clip.write_videofile(final_output, fps=30, codec="libx264")

    console.log("Slideshow creation complete!")


if __name__ == "__main__":
    fire.Fire(main)
