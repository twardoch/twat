# Work Log

## 2026-01-17 - Phase 1 & 2 Complete

### Phase 1: Script Standardization ✅
- 22 scripts standardized with uv shebangs and safety guards
- All broken paths fixed
- All this_file markers corrected

### Phase 2: Documentation ✅
- Created comprehensive README.md with script catalog
- Updated PLAN.md with completion status
- Set up TODO.md with future improvements

## 2026-04-01 - vidcropscale MVP

- Implemented `vidcropscale.py` as a minimal Fire-based CLI for explicit crop/scale operations
- Added strict parsing for `scale`, `crop`, side offsets, and stub-defined precedence rules
- Added ffprobe-based size detection, deterministic `_cropscale` output naming, and ffmpeg execution via subprocess
- Verified parser/resolver behavior, CLI help, Python compilation, and serial smoke checks on a generated sample clip
- Tightened follow-up validation so invalid dimension tokens are rejected even when side overrides would ignore that axis
- Changed odd resolved crop/scale geometry handling to fail fast instead of silently coercing dimensions

## 2026-04-02 - vidsplit MVP

- Implemented `vidsplit.py` as a uv-shebang Fire CLI for `--input_video` plus exactly one of `--parts`, `--seconds`, or `--frames`
- Made `--parts` split by frame count, `--seconds` accept floats for exact non-final chunk length, and `--frames` split by fixed frame-count chunks
- Added ffprobe-based duration, frame-rate, and frame-count probing plus deterministic default output directories like `{stem}-{N}p`, `{stem}-{M}s`, and `{stem}-{O}f`
- Preserved audio by trimming video and audio together per segment with ffmpeg filter graphs and writing each segment into the target directory
- Verified Python compilation, Fire help, selector validation, auto-created directory naming, and serial smoke checks on a generated A/V sample for parts, seconds, and frames modes
