#!/usr/bin/env -S uv run
# /// script
# requires-python = ">=3.10"
# dependencies = ["fire"]
# ///
# this_file: vidshortentoframes.py

from fractions import Fraction
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

import fire


FFPROBE_BASE_CMD = ["ffprobe", "-v", "error"]
FFMPEG_BASE_CMD = ["ffmpeg", "-hide_banner", "-loglevel", "error"]


def _has_executable(tool: str) -> bool:
    """Return True if an executable is available on PATH."""
    return shutil.which(tool) is not None


def _require_executable(tool: str) -> None:
    """Raise when a required executable is not available."""
    if _has_executable(tool):
        return
    raise RuntimeError(
        f"Required executable '{tool}' was not found on PATH. Install FFmpeg tools and retry."
    )


def _run_text_command(cmd: list[str]) -> str:
    """Run a command and return stripped stdout."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except FileNotFoundError as exc:
        tool = cmd[0] if cmd else "command"
        raise RuntimeError(
            f"Required executable '{tool}' was not found on PATH. Install FFmpeg tools and retry."
        ) from exc
    return result.stdout.strip()


def get_video_fps(video_path: str | Path) -> float:
    """Return the input video frame rate."""
    path = Path(video_path)
    fps_str = _run_text_command(
        [
            *FFPROBE_BASE_CMD,
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=r_frame_rate",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ]
    )
    if not fps_str:
        raise RuntimeError(f"Unable to read FPS for '{path}'.")

    try:
        fps = float(Fraction(fps_str))
    except (ValueError, ZeroDivisionError) as exc:
        raise RuntimeError(f"Invalid FPS value '{fps_str}' for '{path}'.") from exc

    if fps <= 0:
        raise RuntimeError(f"Invalid FPS value '{fps_str}' for '{path}'.")
    return fps


def count_video_frames(video_path: str | Path) -> int:
    """Count decoded video frames using ffprobe."""
    path = Path(video_path)
    frames_str = _run_text_command(
        [
            *FFPROBE_BASE_CMD,
            "-count_frames",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=nb_read_frames",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ]
    )
    if not frames_str or frames_str == "N/A":
        raise RuntimeError(f"Unable to count frames for '{path}'.")
    try:
        frames = int(frames_str)
    except ValueError as exc:
        raise RuntimeError(f"Unexpected frame count '{frames_str}' for '{path}'.") from exc
    if frames < 0:
        raise RuntimeError(f"Invalid frame count '{frames}' for '{path}'.")
    return frames


def shorten_video_to_frames(
    input_path: str,
    num_frames: int,
    output_path: str | None = None,
    force: bool = False,
    verify_output: bool = True,
    dry_run: bool = False,
) -> str:
    """Shorten video to a specific number of frames."""
    input_file = Path(input_path)
    if not input_file.exists():
        raise FileNotFoundError(f"Input file '{input_file}' does not exist.")
    if num_frames <= 0:
        raise ValueError("frames must be > 0")

    if output_path is None:
        output_file = input_file.with_name(f"{input_file.stem}-{num_frames}f{input_file.suffix}")
    else:
        output_file = Path(output_path)
    if input_file.resolve() == output_file.resolve():
        raise ValueError("output file must be different from input file")
    output_file.parent.mkdir(parents=True, exist_ok=True)

    if output_file.exists() and not force:
        raise FileExistsError(
            f"Output file '{output_file}' already exists. Use --force to overwrite it."
        )

    if not dry_run:
        _require_executable("ffmpeg")
    if verify_output and not dry_run:
        _require_executable("ffprobe")

    fps: float | None = None
    if not dry_run and _has_executable("ffprobe"):
        fps = get_video_fps(input_file)

    overwrite_flag = "-y" if force else "-n"

    cmd = [
        *FFMPEG_BASE_CMD,
        "-i",
        str(input_file),
        "-frames:v",
        str(num_frames),
        "-c",
        "copy",
        overwrite_flag,
        str(output_file),
    ]

    print(f"Processing: {input_file}")
    if fps is None:
        print(f"Frames: {num_frames} (duration unavailable)")
    else:
        duration = num_frames / fps
        print(f"FPS: {fps:.2f}, Duration: {duration:.2f}s ({num_frames} frames)")
    print(f"Output: {output_file}")
    if dry_run:
        print("Dry run: ffmpeg command not executed.")
        print(f"Command: {shlex.join(cmd)}")
        return str(output_file)

    subprocess.run(cmd, check=True)
    if verify_output:
        output_frames = count_video_frames(output_file)
        if output_frames != num_frames:
            raise RuntimeError(
                f"Output has {output_frames} frames but expected {num_frames}: '{output_file}'."
            )
    print("Done!")
    return str(output_file)


def main(
    input: str,
    frames: int = 449,
    out: str | None = None,
    force: bool = False,
    verify: bool = True,
    dry_run: bool = False,
):
    """Shorten a video to a specific number of frames.

    Args:
        input: Input video file path
        frames: Number of frames to keep (default: 450)
        out: Output video file path (default: <input>-<frames>f.ext)
        force: Overwrite output file if it already exists
        verify: Verify output frame count after processing
        dry_run: Print ffmpeg command without writing output
    """
    try:
        shorten_video_to_frames(
            input, frames, out, force=force, verify_output=verify, dry_run=dry_run
        )
    except (
        FileNotFoundError,
        FileExistsError,
        ValueError,
        RuntimeError,
        subprocess.CalledProcessError,
    ) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    fire.Fire(main)
