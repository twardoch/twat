#!/usr/bin/env -S uv run
# /// script
# requires-python = ">=3.12"
# dependencies = ["fire", "langcodes"]
# ///
# this_file: mkv2srt.py
"""Extract subtitle tracks from video files to SRT format.

Supports MKV, MP4, AVI, M2TS, TS, WebM, MOV containers.
Uses FFmpeg for extraction with Plex/Jellyfin-compatible naming:
  movie.mkv → movie.en.srt, movie.fr.srt, movie.en.forced.srt

Exit codes: 0=success, 1=partial failure, 2=total failure
"""

import json
import shutil
import signal
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import fire
import langcodes


def check_dependencies() -> None:
    """Verify ffmpeg and ffprobe are installed."""
    missing = []
    if not shutil.which("ffprobe"):
        missing.append("ffprobe")
    if not shutil.which("ffmpeg"):
        missing.append("ffmpeg")

    if missing:
        print(f"✗ Missing required tools: {', '.join(missing)}", file=sys.stderr)
        print("  Install FFmpeg: brew install ffmpeg (macOS) or apt install ffmpeg (Linux)", file=sys.stderr)
        sys.exit(2)

# Bitmap subtitle codecs that cannot be converted to text SRT
BITMAP_CODECS = {"hdmv_pgs_subtitle", "dvd_subtitle", "dvb_subtitle", "xsub"}

# Video container formats that can have embedded subtitles
VIDEO_EXTENSIONS = {".mkv", ".mp4", ".avi", ".m2ts", ".ts", ".webm", ".mov"}

# Language code normalization (verbose → ISO 639-1)
LANG_ALIASES = {
    "english": "en", "en-us": "en", "en-gb": "en", "en_us": "en",
    "french": "fr", "fr-fr": "fr", "français": "fr",
    "german": "de", "de-de": "de", "deutsch": "de",
    "spanish": "es", "es-es": "es", "español": "es",
    "italian": "it", "it-it": "it", "italiano": "it",
    "portuguese": "pt", "pt-br": "pt", "pt-pt": "pt",
    "japanese": "ja", "ja-jp": "ja",
    "chinese": "zh", "zh-cn": "zh", "zh-tw": "zh",
    "korean": "ko", "ko-kr": "ko",
    "russian": "ru", "ru-ru": "ru",
    "arabic": "ar", "ar-sa": "ar",
    "dutch": "nl", "nl-nl": "nl", "nederlands": "nl",
    "polish": "pl", "pl-pl": "pl",
    "swedish": "sv", "sv-se": "sv",
    "norwegian": "no", "no-no": "no", "nb-no": "no",
    "danish": "da", "da-dk": "da",
    "finnish": "fi", "fi-fi": "fi",
    "greek": "el", "el-gr": "el",
    "turkish": "tr", "tr-tr": "tr",
    "hebrew": "he", "he-il": "he",
    "thai": "th", "th-th": "th",
    "vietnamese": "vi", "vi-vn": "vi",
    "hindi": "hi", "hi-in": "hi",
}


def normalize_lang(lang: str) -> str:
    """Normalize language code to ISO 639-1 (2-letter) when possible."""
    raw = lang.strip()
    if not raw:
        return "und"
    lower = raw.lower()

    try:
        standardized = langcodes.standardize_tag(lower)
        primary = standardized.split("-")[0]
        return primary.lower()
    except Exception:
        return LANG_ALIASES.get(lower, lower)


@dataclass
class Stats:
    """Track extraction statistics."""

    files: int = 0
    extracted: int = 0
    skipped: int = 0
    failed: int = 0
    no_subs: int = 0
    bitmap: int = 0

    def summary(self) -> str:
        parts = [f"{self.files} files"]
        if self.extracted:
            parts.append(f"{self.extracted} extracted")
        if self.skipped:
            parts.append(f"{self.skipped} skipped")
        if self.bitmap:
            parts.append(f"{self.bitmap} bitmap (needs OCR)")
        if self.failed:
            parts.append(f"{self.failed} failed")
        if self.no_subs:
            parts.append(f"{self.no_subs} without subs")
        return ", ".join(parts)

    def exit_code(self) -> int:
        """Return appropriate exit code based on results."""
        if self.failed == 0 and self.extracted > 0:
            return 0  # All succeeded
        if self.extracted > 0:
            return 1  # Partial failure
        return 2  # Total failure


def _one_line(text: str) -> str:
    """Collapse whitespace to keep error output single-line."""
    return " ".join(text.split())


def get_subtitle_streams(video_path: Path) -> list[dict]:
    """Probe MKV for subtitle stream metadata using ffprobe."""
    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_streams",
        "-select_streams", "s",
        str(video_path),
    ]
    last_error = ""
    for _attempt in range(3):
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            if not result.stdout.strip():
                return []
            try:
                data = json.loads(result.stdout)
                return data.get("streams", [])
            except json.JSONDecodeError as exc:
                last_error = f"invalid JSON: {exc}"
                continue
        last_error = _one_line(result.stderr or result.stdout)

    raise RuntimeError(f"ffprobe failed: {last_error or 'unknown error'}")


def build_output_name(base_stem: str, output_dir: Path, stream: dict, index: int) -> Path:
    """Build SRT filename.

    Format: base.lang.srt or base.lang-suffix.srt
    Falls back to track index if no language tag.
    """
    tags = stream.get("tags", {})
    raw_lang = tags.get("language", f"track{index}")
    lang = normalize_lang(raw_lang)

    # Detect forced/SDH flags from title or disposition
    title = tags.get("title", "").lower()
    disposition = stream.get("disposition", {})

    suffixes = []
    if disposition.get("forced") or "forced" in title:
        suffixes.append("forced")
    if disposition.get("hearing_impaired") or "sdh" in title:
        suffixes.append("sdh")

    # Build filename: movie.en.srt or movie.en-sdh.srt
    if suffixes:
        suffix = f"{lang}-{'-'.join(suffixes)}"
    else:
        suffix = lang

    return output_dir / f"{base_stem}.{suffix}.srt"


def dedupe_output_names(outputs: list[Path]) -> list[Path]:
    """Ensure unique output names by appending counter to duplicates."""
    seen: dict[Path, int] = {}
    result = []

    for out in outputs:
        if out in seen:
            seen[out] += 1
            # Insert counter before .srt: movie.en.srt → movie.en.2.srt
            new_stem = f"{out.stem}.{seen[out]}"
            out = out.with_stem(new_stem)
        else:
            seen[out] = 1
        result.append(out)

    return result


def extract_subtitle(video_path: Path, stream_index: int, output_path: Path, quiet: bool) -> bool:
    """Extract a single subtitle stream to SRT using ffmpeg."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",  # Overwrite
        "-v", "warning",
        "-i", str(video_path),
        "-map", f"0:s:{stream_index}",
        "-c:s", "srt",
        str(output_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        if not quiet:
            print(f"  ✗ Failed: {result.stderr.strip()}", file=sys.stderr)
        return False
    return True


def find_video_files(paths: tuple[str, ...], recursive: bool) -> list[Path]:
    """Resolve paths to video files with potential subtitles."""
    video_files = []

    for path_str in paths:
        p = Path(path_str).resolve()

        if p.is_file():
            if p.suffix.lower() in VIDEO_EXTENSIONS:
                video_files.append(p)
            else:
                print(f"✗ Unsupported format: {p.suffix} ({p.name})", file=sys.stderr)
        elif p.is_dir():
            for ext in VIDEO_EXTENSIONS:
                pattern = f"**/*{ext}" if recursive else f"*{ext}"
                video_files.extend(p.glob(pattern))
            video_files = sorted(set(video_files))  # Dedupe and sort
        else:
            print(f"✗ Not found: {p}", file=sys.stderr)

    return video_files


def parse_lang_filter(lang: str | None) -> set[str] | None:
    """Parse comma-separated language codes into a normalized set."""
    if not lang:
        return None
    return {normalize_lang(l) for l in lang.split(",")}


def info(*paths: str, recursive: bool = False) -> None:
    """Show subtitle track information without extracting.

    Args:
        paths: MKV file(s) or directory path(s) to analyze
        recursive: Recursively find MKV files in directories
    """
    if not paths:
        print("Usage: mkv2srt.py info <video|dir> [...]", file=sys.stderr)
        sys.exit(2)

    check_dependencies()

    video_files = find_video_files(paths, recursive)
    if not video_files:
        print("No video files found.", file=sys.stderr)
        sys.exit(2)

    total_tracks = 0
    total_bitmap = 0

    for video_path in video_files:
        print(f"► {video_path.name}")

        try:
            streams = get_subtitle_streams(video_path)
        except RuntimeError as exc:
            print(f"  ✗ ffprobe error: {_one_line(str(exc))}", file=sys.stderr)
            continue
        if not streams:
            print("  (no subtitle tracks)")
            continue

        for i, stream in enumerate(streams):
            codec = stream.get("codec_name", "?")
            tags = stream.get("tags", {})
            raw_lang = tags.get("language", "und")
            lang = normalize_lang(raw_lang)
            title = tags.get("title", "")
            disposition = stream.get("disposition", {})

            # Build info line
            flags = []
            if disposition.get("default"):
                flags.append("default")
            if disposition.get("forced"):
                flags.append("forced")
            if disposition.get("hearing_impaired"):
                flags.append("sdh")

            is_bitmap = codec in BITMAP_CODECS
            if is_bitmap:
                total_bitmap += 1

            info_parts = [f"[{codec}]", lang]
            if raw_lang != lang:
                info_parts.append(f"(was: {raw_lang})")
            if title:
                info_parts.append(f'"{title}"')
            if flags:
                info_parts.append(f"({', '.join(flags)})")
            if is_bitmap:
                info_parts.append("⊘ bitmap")

            total_tracks += 1
            print(f"  {i}: {' '.join(info_parts)}")

    print(f"\n{len(video_files)} files, {total_tracks} tracks", end="")
    if total_bitmap:
        print(f", {total_bitmap} bitmap (need OCR)")
    else:
        print()


def extract(
    *paths: str,
    output_dir: str | None = None,
    lang: str | None = None,
    recursive: bool = False,
    skip_existing: bool = False,
    dry_run: bool = False,
    quiet: bool = False,
) -> None:
    """Extract all subtitles from video file(s) to SRT.

    Args:
        paths: Video file(s) or directory path(s) to process
        output_dir: Output directory for SRT files (default: same as source)
        lang: Only extract these languages (comma-separated, e.g., "en,fr")
        recursive: Recursively find MKV files in directories
        skip_existing: Skip extraction if SRT file already exists
        dry_run: Show what would be extracted without doing it
        quiet: Only show errors and summary (for scripts/cron)
    """
    if not paths:
        print("Usage: mkv2srt.py extract <video|dir> [...]", file=sys.stderr)
        print("Options: --output-dir=PATH --lang=en,fr --recursive --skip-existing --dry-run --quiet", file=sys.stderr)
        sys.exit(2)

    check_dependencies()

    video_files = find_video_files(paths, recursive)
    if not video_files:
        print("No video files found.", file=sys.stderr)
        sys.exit(2)

    out_base = Path(output_dir).resolve() if output_dir else None
    lang_filter = parse_lang_filter(lang)
    stats = Stats()

    # Handle Ctrl+C gracefully
    def handle_interrupt(_sig: int, _frame: object) -> None:
        print(f"\n\nInterrupted! Partial: {stats.summary()}")
        sys.exit(130)  # Standard exit code for SIGINT

    signal.signal(signal.SIGINT, handle_interrupt)

    for video_path in video_files:
        stats.files += 1
        if not quiet:
            print(f"► {video_path.name}")

        try:
            streams = get_subtitle_streams(video_path)
        except RuntimeError as exc:
            stats.failed += 1
            if not quiet:
                print(f"  ✗ ffprobe error: {_one_line(str(exc))}", file=sys.stderr)
            continue
        if not streams:
            stats.no_subs += 1
            if not quiet:
                print("  (no subtitle tracks)")
            continue

        # Determine output directory
        dest_dir = out_base if out_base else video_path.parent

        # Build all output names first, then dedupe
        outputs = [
            build_output_name(video_path.stem, dest_dir, stream, i)
            for i, stream in enumerate(streams)
        ]
        outputs = dedupe_output_names(outputs)

        for i, (stream, output) in enumerate(zip(streams, outputs)):
            codec = stream.get("codec_name", "?")
            tags = stream.get("tags", {})
            raw_lang = tags.get("language", "und")
            stream_lang = normalize_lang(raw_lang)
            title = tags.get("title", "")

            info = f"[{codec}] {stream_lang}"
            if title:
                info += f' "{title}"'

            # Filter by language if specified
            if lang_filter and stream_lang not in lang_filter:
                continue

            # Skip bitmap subtitles (PGS, VobSub) - they need OCR
            if codec in BITMAP_CODECS:
                stats.bitmap += 1
                if not quiet:
                    print(f"  ⊘ {output.name}  {info}  (bitmap, needs OCR)")
                continue

            # Skip if exists and --skip-existing
            if skip_existing and output.exists():
                stats.skipped += 1
                if not quiet:
                    print(f"  ○ {output.name}  {info}  (exists)")
                continue

            if dry_run:
                if not quiet:
                    print(f"  → {output.name}  {info}")
                stats.extracted += 1
            else:
                if extract_subtitle(video_path, i, output, quiet):
                    stats.extracted += 1
                    if not quiet:
                        print(f"  ✓ {output.name}  {info}")
                else:
                    stats.failed += 1

    # Always show summary
    if dry_run:
        print(f"\n{stats.summary()} (dry-run)")
    else:
        print(f"\n{stats.summary()}")
    sys.exit(stats.exit_code())


if __name__ == "__main__":
    fire.Fire({"extract": extract, "info": info})
