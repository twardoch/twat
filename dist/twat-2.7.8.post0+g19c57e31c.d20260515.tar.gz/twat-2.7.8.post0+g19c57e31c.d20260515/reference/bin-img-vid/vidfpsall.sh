#!/usr/bin/env bash
# this_file: vidfpsall.sh
set -euo pipefail

DIR="${1:-.}"
fd "" "$DIR" --extension mp4 --extension mov --type f --absolute-path -x ~/bin/img/vidfps {}
