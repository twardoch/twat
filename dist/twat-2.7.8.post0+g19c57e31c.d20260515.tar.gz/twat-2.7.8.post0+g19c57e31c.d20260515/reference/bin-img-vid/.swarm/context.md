

## Agent Activity

| Tool | Calls | Success | Failed | Avg Duration |
|------|-------|---------|--------|--------------|
| read | 129 | 129 | 0 | 19ms |
| bash | 75 | 75 | 0 | 313ms |
| todowrite | 24 | 24 | 0 | 14ms |
| apply_patch | 19 | 19 | 0 | 362ms |
| glob | 18 | 18 | 0 | 17ms |
| grep | 18 | 18 | 0 | 22ms |
| lsp_diagnostics | 11 | 11 | 0 | 1073ms |
| task | 8 | 8 | 0 | 556860ms |
| background_output | 6 | 6 | 0 | 33755ms |
| skill | 2 | 2 | 0 | 218ms |
| call_omo_agent | 2 | 2 | 0 | 66ms |
| plan_exit | 2 | 2 | 0 | 798504ms |
| diff | 2 | 2 | 0 | 24ms |
| compress | 2 | 2 | 0 | 384ms |
