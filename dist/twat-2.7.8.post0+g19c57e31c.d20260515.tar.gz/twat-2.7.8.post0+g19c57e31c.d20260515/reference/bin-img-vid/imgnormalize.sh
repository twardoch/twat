#!/usr/bin/env bash
# this_file: imgnormalize.sh
# Batch-normalize images using ImageMagick (magick convert).
# Usage: ./imgnormalize.sh <input_dir> <output_dir> <level 1|2|3>
#   1 = basic (auto-level per channel)
#   2 = medium (normalize + auto-gamma)
#   3 = intense (aggressive contrast stretch + saturation boost + sharpen)
set -euo pipefail

die() { echo "ERROR: $*" >&2; exit 1; }

resolve_path() {
    python3 - "$1" <<'PY'
from pathlib import Path
import sys

print(Path(sys.argv[1]).expanduser().resolve(strict=False))
PY
}

# --- Validate arguments ---------------------------------------------------
[[ $# -eq 3 ]] || die "Usage: $0 <input_dir> <output_dir> <1|2|3>"

INPUT_DIR="$1"
OUTPUT_DIR="$2"
LEVEL="$3"

command -v python3 >/dev/null || die "python3 is required to resolve paths"
command -v magick >/dev/null || die "ImageMagick not found. Install with: brew install imagemagick"

INPUT_DIR="$(resolve_path "$INPUT_DIR")"
OUTPUT_DIR="$(resolve_path "$OUTPUT_DIR")"
[[ -d "$INPUT_DIR" ]]      || die "Input directory does not exist: $INPUT_DIR"
[[ "$LEVEL" =~ ^[123]$ ]]  || die "Level must be 1, 2, or 3 (got: $LEVEL)"
[[ "$OUTPUT_DIR" == "$INPUT_DIR" || "$OUTPUT_DIR" == "$INPUT_DIR"/* ]] \
    && die "Output directory must not be the input directory or inside it: $OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

# --- Build magick flags per level ------------------------------------------
case "$LEVEL" in
    1)  # Basic: linear per-channel stretch to full range, no clipping
        MAGICK_OPTS=( -auto-orient -auto-level )
        LABEL="basic"
        ;;
    2)  # Medium: clip outliers (2%), auto-gamma for midtone correction
        MAGICK_OPTS=( -auto-orient -normalize -auto-gamma )
        LABEL="medium"
        ;;
    3)  # Intense: aggressive clip, gamma, saturation boost, mild sharpen
        MAGICK_OPTS=( -auto-orient -contrast-stretch "5%x3%" -auto-gamma -modulate "103,125,100" -unsharp "0x0.5+0.5+0" )
        LABEL="intense"
        ;;
esac

echo "=== imgnormalize: level $LEVEL ($LABEL) ==="
echo "    input:  $INPUT_DIR"
echo "    output: $OUTPUT_DIR"
echo "    flags:  ${MAGICK_OPTS[*]}"
echo

# --- Process images recursively --------------------------------------------
count=0
errors=0
found_any=0

while IFS= read -r -d '' src; do
    found_any=1
    # Relative path from input dir
    rel="${src#"$INPUT_DIR"/}"
    dst="$OUTPUT_DIR/$rel"

    # Create output subdirectory
    mkdir -p "$(dirname "$dst")"

    if magick convert "$src" "${MAGICK_OPTS[@]}" "$dst" 2>/dev/null; then
        count=$((count + 1))
        printf "  [OK] %s\n" "$rel"
    else
        errors=$((errors + 1))
        printf "  [FAIL] %s\n" "$rel" >&2
    fi
done < <(find "$INPUT_DIR" -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \
         -o -iname '*.tif' -o -iname '*.tiff' -o -iname '*.bmp' -o -iname '*.webp' \) -print0)

if [[ "$found_any" -eq 0 ]]; then
    echo "No images found in $INPUT_DIR"
fi

echo
echo "=== Done: $count processed, $errors errors ==="

if [[ "$errors" -gt 0 ]]; then
    exit 1
fi
