#!/usr/bin/env -S uv run
# /// script
# dependencies = ["fire"]
# ///
# this_file: srtmultifix.py

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Iterable

import fire

_TIME_RE = re.compile(r"^(\d{2}):(\d{2}):(\d{2}),(\d{3})$")


@dataclass
class SrtEntry:
    index_line: str
    start_ms: int
    end_ms: int
    text_lines: list[str]


def parse_timestamp(value: str) -> int:
    match = _TIME_RE.match(value.strip())
    if not match:
        raise ValueError(f"Invalid timestamp: {value!r}")
    hours, minutes, seconds, millis = map(int, match.groups())
    return (((hours * 60) + minutes) * 60 + seconds) * 1000 + millis


def format_timestamp(total_ms: int) -> str:
    total_ms = max(0, int(total_ms))
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"


def detect_newline(text: str) -> str:
    return "\r\n" if "\r\n" in text else "\n"


def parse_srt(text: str) -> list[SrtEntry]:
    lines = text.splitlines()
    entries: list[SrtEntry] = []
    i = 0
    while i < len(lines):
        if not lines[i].strip():
            i += 1
            continue
        entry, i = read_block(lines, i)
        entries.append(entry)
    return entries


def read_block(lines: list[str], i: int) -> tuple[SrtEntry, int]:
    index_line = lines[i].strip()
    i += 1
    if i >= len(lines):
        raise ValueError("Unexpected end after index line")
    time_line = lines[i].strip()
    i += 1
    start_ms, end_ms = parse_time_line(time_line)
    text_lines: list[str] = []
    while i < len(lines) and lines[i].strip():
        text_lines.append(lines[i])
        i += 1
    return SrtEntry(index_line, start_ms, end_ms, text_lines), i


def parse_time_line(line: str) -> tuple[int, int]:
    if "-->" not in line:
        raise ValueError(f"Missing time separator in: {line!r}")
    start_raw, end_raw = [part.strip() for part in line.split("-->", 1)]
    return parse_timestamp(start_raw), parse_timestamp(end_raw)


def format_srt(entries: Iterable[SrtEntry], newline: str, keep_trailing: bool) -> str:
    chunks: list[str] = []
    for idx, entry in enumerate(entries, start=1):
        index_line = entry.index_line or str(idx)
        chunks.append(index_line)
        chunks.append(
            f"{format_timestamp(entry.start_ms)} --> {format_timestamp(entry.end_ms)}"
        )
        chunks.extend(entry.text_lines)
        chunks.append("")
    if chunks:
        chunks.pop()
    text = newline.join(chunks)
    if keep_trailing:
        text += newline
    return text


def duration_ms(entry: SrtEntry) -> int:
    return entry.end_ms - entry.start_ms


def available_gap_before(entries: list[SrtEntry], index: int, min_gap_ms: int) -> int:
    if index <= 0:
        return 0
    prev = entries[index - 1]
    current = entries[index]
    return current.start_ms - (prev.end_ms + min_gap_ms)


def available_gap_after(entries: list[SrtEntry], index: int, min_gap_ms: int) -> int:
    if index >= len(entries) - 1:
        return 0
    current = entries[index]
    nxt = entries[index + 1]
    return (nxt.start_ms - min_gap_ms) - current.end_ms


def borrow_from_prev(
    entries: list[SrtEntry], index: int, amount_ms: int
) -> int:
    if index <= 0 or amount_ms <= 0:
        return 0
    prev = entries[index - 1]
    current = entries[index]
    prev.end_ms -= amount_ms
    current.start_ms -= amount_ms
    return amount_ms


def borrow_from_next(
    entries: list[SrtEntry], index: int, amount_ms: int
) -> int:
    if index >= len(entries) - 1 or amount_ms <= 0:
        return 0
    current = entries[index]
    nxt = entries[index + 1]
    current.end_ms += amount_ms
    nxt.start_ms += amount_ms
    return amount_ms


def fix_entries(
    entries: list[SrtEntry], min_duration_ms: int, min_gap_ms: int
) -> list[SrtEntry]:
    if not entries:
        return entries

    for i in range(1, len(entries)):
        prev = entries[i - 1]
        current = entries[i]
        if current.start_ms < prev.end_ms:
            prev.end_ms = current.start_ms
            if prev.end_ms < prev.start_ms:
                prev.end_ms = prev.start_ms

    for i, entry in enumerate(entries):
        need = min_duration_ms - duration_ms(entry)
        if need <= 0:
            continue
        gap_after = available_gap_after(entries, i, min_gap_ms)
        if gap_after > 0:
            shift = min(need, gap_after)
            entry.end_ms += shift
            need -= shift
        if need <= 0:
            continue
        gap_before = available_gap_before(entries, i, min_gap_ms)
        if gap_before > 0:
            shift = min(need, gap_before)
            entry.start_ms -= shift
            need -= shift

    max_iterations = len(entries)
    for _ in range(max_iterations):
        changed = False
        for i, entry in enumerate(entries):
            if duration_ms(entry) >= min_duration_ms:
                continue
            if (
                available_gap_before(entries, i, min_gap_ms) > 0
                or available_gap_after(entries, i, min_gap_ms) > 0
            ):
                continue
            need = min_duration_ms - duration_ms(entry)
            if need <= 0:
                continue
            prev_avail = 0
            next_avail = 0
            if i > 0:
                prev_avail = max(0, duration_ms(entries[i - 1]) - min_duration_ms)
            if i < len(entries) - 1:
                next_avail = max(0, duration_ms(entries[i + 1]) - min_duration_ms)
            if prev_avail <= 0 and next_avail <= 0:
                continue
            if next_avail > prev_avail:
                taken = borrow_from_next(entries, i, min(need, next_avail))
                need -= taken
                if need > 0:
                    taken += borrow_from_prev(entries, i, min(need, prev_avail))
            else:
                taken = borrow_from_prev(entries, i, min(need, prev_avail))
                need -= taken
                if need > 0:
                    taken += borrow_from_next(entries, i, min(need, next_avail))
            if taken:
                changed = True
        if not changed:
            break
    return entries


def iter_srt_paths(root: Path) -> list[Path]:
    if root.is_file() and root.suffix.lower() == ".srt":
        return [root]
    if root.is_dir():
        return sorted(p for p in root.rglob("*.srt") if p.is_file())
    raise FileNotFoundError(f"Input not found: {root}")


def fix_file(path: Path, min_duration_ms: int, min_gap_ms: int, encoding: str) -> None:
    text = path.read_text(encoding=encoding)
    newline = detect_newline(text)
    keep_trailing = text.endswith(("\n", "\r\n"))
    entries = parse_srt(text)
    fixed = fix_entries(entries, min_duration_ms=min_duration_ms, min_gap_ms=min_gap_ms)
    output = format_srt(fixed, newline=newline, keep_trailing=keep_trailing)
    path.write_text(output, encoding=encoding)


class SrtMultiFix:
    def fix(
        self,
        input: str,
        min_duration_ms: int = 800,
        min_gap_ms: int = 1,
        encoding: str = "utf-8",
    ) -> int:
        root = Path(input)
        paths = iter_srt_paths(root)
        for path in paths:
            fix_file(path, min_duration_ms=min_duration_ms, min_gap_ms=min_gap_ms, encoding=encoding)
        return len(paths)


def main() -> None:
    fire.Fire(SrtMultiFix())


if __name__ == "__main__":
    main()
