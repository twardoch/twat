#!/usr/bin/env bash
# this_file: vidhalfsharpenall.sh
set -euo pipefail

DIR="${1:-.}"
fd "" "$DIR" --extension mp4 --extension mov --type f --absolute-path -x ~/bin/img/vidhalfsharpen.sh {}
