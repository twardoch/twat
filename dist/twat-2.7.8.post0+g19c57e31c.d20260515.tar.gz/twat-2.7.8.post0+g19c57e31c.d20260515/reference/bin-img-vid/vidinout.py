#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "rich", "loguru", "numpy<2", "opencv-python-headless", "tqdm"]
# ///
# this_file: vidinout.py

"""
Video processing CLI tool for speed changes and fade effects.
Provides configurable speed ramping and fade in/out effects.

Examples:
    # Basic usage (no effects, just process video)
    vidinout.py video.mp4

    # Add 1-second fade-in from black (30 frames at 30fps)
    vidinout.py video.mp4 --fadein-numf 30

    # Add fade-in and fade-out
    vidinout.py video.mp4 --fadein-numf 30 --fadeout-numf 30

    # Speed ramp: slow start (50%) ramping to normal (100%)
    vidinout.py video.mp4 --start-speed 50 --start-numf 60

    # Speed ramp: normal to slow ending
    vidinout.py video.mp4 --end-speed 50 --end-numf 60

    # Custom fade color (white instead of black)
    vidinout.py video.mp4 --fadein-color ffffff --fadein-numf 30

    # Full cinematic effect: fade from black + speed ramp
    vidinout.py video.mp4 --fadein-numf 30 --fadeout-numf 30 --start-speed 50 --end-speed 50

Speed functions: linear, desi (default), ease_in, ease_out, ease_in_out
Fade functions: linear, desi (default), ease_in, ease_out, ease_in_out
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path
from typing import Optional
import fire
from rich.console import Console
from rich.progress import track
from loguru import logger
import numpy as np
import cv2
from tqdm import tqdm

console = Console()

class SpeedFunction:
    """Enumeration of available speed transition functions."""
    LINEAR = "linear"
    DESI = "desi"  # double-exponential sigmoid
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"

class FadeFunction:
    """Enumeration of available fade transition functions."""
    LINEAR = "linear"
    DESI = "desi"  # double-exponential sigmoid
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"

class VideoProcessor:
    """Main video processing class using FFmpeg."""
    
    def __init__(self, verbose: bool = False):
        """Initialize video processor with optional verbose logging."""
        # Remove default handler to avoid duplicate logging
        logger.remove()
        if verbose:
            logger.add(sys.stderr, level="DEBUG", format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level} | {name}:{function}:{line} - {message}")
        else:
            logger.add(sys.stderr, level="INFO", format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level} | {name}:{function}:{line} - {message}")
    
    def _generate_speed_curve(self, total_frames: int, start_speed: float, 
                             start_numf: int, mid_speed: float, end_speed: float, 
                             end_numf: int, speed_function: str) -> list[float]:
        """Generate speed multiplier curve for the video with optional mid-point speed."""
        speed_curve = [mid_speed / 100.0] * total_frames
        
        # Start speed transition: transition FROM start_speed TO mid_speed
        if start_numf > 0 and start_speed != mid_speed:
            start_multiplier = start_speed / 100.0
            mid_multiplier = mid_speed / 100.0
            for i in range(min(start_numf, total_frames)):
                progress = i / start_numf  # 0.0 to 1.0
                transition = self._apply_transition_function(progress, speed_function)
                # Transition from start_multiplier to mid_multiplier
                speed_curve[i] = start_multiplier + (mid_multiplier - start_multiplier) * transition
        
        # End speed transition: transition FROM mid_speed TO end_speed
        if end_numf > 0 and end_speed != mid_speed:
            end_multiplier = end_speed / 100.0
            mid_multiplier = mid_speed / 100.0
            start_idx = max(0, total_frames - end_numf)
            for i in range(start_idx, total_frames):
                progress = (i - start_idx) / end_numf  # 0.0 to 1.0
                transition = self._apply_transition_function(progress, speed_function)
                # Transition from mid_multiplier to end_multiplier
                speed_curve[i] = mid_multiplier + (end_multiplier - mid_multiplier) * transition
        
        return speed_curve
    
    def _generate_fade_curve(self, total_frames: int, fadein_numf: int, 
                           fadeout_numf: int, fade_function: str) -> list[float]:
        """Generate opacity curve for fade effects."""
        fade_curve = [1.0] * total_frames
        
        # Fade in
        if fadein_numf > 0:
            for i in range(min(fadein_numf, total_frames)):
                progress = i / fadein_numf
                fade_curve[i] = self._apply_transition_function(progress, fade_function)
        
        # Fade out
        if fadeout_numf > 0:
            start_idx = max(0, total_frames - fadeout_numf)
            for i in range(start_idx, total_frames):
                progress = (i - start_idx) / fadeout_numf
                fade_curve[i] = 1.0 - self._apply_transition_function(progress, fade_function)
        
        return fade_curve
    
    def _apply_transition_function(self, progress: float, function: str) -> float:
        """Apply transition function to progress value (0.0 to 1.0)."""
        progress = max(0.0, min(1.0, progress))
        
        if function == SpeedFunction.LINEAR:
            return progress
        elif function == SpeedFunction.DESI:
            # Double-exponential sigmoid (similar to ffmpeg's afade/acrossfade)
            # This creates a smooth S-curve with faster transitions at the edges
            if progress <= 0.5:
                # First half: exponential ease-in
                return 2.0 * progress * progress
            else:
                # Second half: exponential ease-out
                return 1.0 - 2.0 * (1.0 - progress) * (1.0 - progress)
        elif function == SpeedFunction.EASE_IN:
            return progress * progress
        elif function == SpeedFunction.EASE_OUT:
            return 1.0 - (1.0 - progress) * (1.0 - progress)
        elif function == SpeedFunction.EASE_IN_OUT:
            if progress < 0.5:
                return 2.0 * progress * progress
            else:
                return 1.0 - 2.0 * (1.0 - progress) * (1.0 - progress)
        else:
            logger.warning(f"Unknown function '{function}', using linear")
            return progress
    
    def _get_video_info(self, video_path: str) -> dict:
        """Get video information using ffprobe."""
        try:
            cmd = [
                "ffprobe", "-v", "quiet", "-print_format", "json",
                "-show_format", "-show_streams", video_path
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            import json
            info = json.loads(result.stdout)
            
            video_stream = None
            for stream in info['streams']:
                if stream['codec_type'] == 'video':
                    video_stream = stream
                    break
            
            if not video_stream:
                raise ValueError("No video stream found")
            
            # Calculate total frames
            fps = eval(video_stream['r_frame_rate'])
            duration = float(video_stream['duration'])
            total_frames = int(fps * duration)
            
            return {
                'fps': fps,
                'duration': duration,
                'total_frames': total_frames,
                'width': int(video_stream['width']),
                'height': int(video_stream['height'])
            }
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to get video info: {e}")
        except Exception as e:
            raise RuntimeError(f"Error parsing video info: {e}")
    
    def _process_video_with_precise_speed(self, input_path: str, output_path: str,
                                        video_info: dict, start_speed: int, start_numf: int,
                                        mid_speed: int, end_speed: int, end_numf: int, 
                                        speed_function: str, fadein_color: str, fadeout_color: str,
                                        fadein_numf: int, fadeout_numf: int,
                                        fade_function: str, output_fps: float = None) -> None:
        """Process video with frame-by-frame precise speed control using OpenCV."""
        
        # Generate the precise speed curve
        speed_curve = self._generate_speed_curve(
            video_info['total_frames'], start_speed, start_numf,
            mid_speed, end_speed, end_numf, speed_function
        )
        
        # Generate fade curve
        fade_curve = self._generate_fade_curve(
            video_info['total_frames'], fadein_numf, fadeout_numf, fade_function
        )
        
        logger.info(f"Speed curve sample: frames 0-9: {speed_curve[:10]}")
        logger.info(f"Speed curve sample: frames {len(speed_curve)-10}-{len(speed_curve)-1}: {speed_curve[-10:]}")
        
        # Calculate expected output duration
        fps = video_info['fps']
        frame_duration = 1.0 / fps
        total_expected_duration = sum(frame_duration / speed for speed in speed_curve)
        
        logger.info(f"Expected output duration: {total_expected_duration:.3f}s (vs original {video_info['duration']:.3f}s)")
        
        # Open input video
        cap = cv2.VideoCapture(input_path)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open video: {input_path}")
        
        # Read all frames
        logger.info("Reading all input frames...")
        input_frames = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            input_frames.append(frame)
        cap.release()
        
        logger.info(f"Read {len(input_frames)} frames from input video")
        
        # Generate output frame sequence based on precise speed curve
        logger.info("Generating output frame sequence with precise speed control...")
        output_frames = []
        
        for frame_idx, speed in enumerate(tqdm(speed_curve, desc="Processing frames")):
            if frame_idx >= len(input_frames):
                break
                
            frame = input_frames[frame_idx].copy()
            
            # Apply fade effect if specified
            if frame_idx < len(fade_curve) and (fadein_numf > 0 or fadeout_numf > 0):
                opacity = fade_curve[frame_idx]
                if opacity < 1.0:
                    # Determine fade color
                    if frame_idx < fadein_numf:
                        fade_color = self._parse_color(fadein_color)
                    else:
                        fade_color = self._parse_color(fadeout_color)
                    
                    # Blend with fade color
                    color_overlay = np.full_like(frame, fade_color)
                    frame = cv2.addWeighted(frame, opacity, color_overlay, 1 - opacity, 0)
            
            # Apply speed effect: slower speed = more frame duplicates
            if speed > 0:
                # Calculate how many times to repeat this frame
                frame_repeats = int(round(1.0 / speed))
                frame_repeats = max(1, frame_repeats)  # At least show the frame once
                
                for _ in range(frame_repeats):
                    output_frames.append(frame.copy())
        
        logger.info(f"Generated {len(output_frames)} output frames (expected ~{int(total_expected_duration * fps)} frames)")
        
        # Calculate correct output frame rate for proper timing
        # We want the output video to play for total_expected_duration seconds
        # with len(output_frames) frames
        if output_fps is None:
            output_fps = len(output_frames) / total_expected_duration
        else:
            logger.info(f"Using user-specified output FPS: {output_fps}")
            # Recalculate expected duration based on user FPS
            total_expected_duration = len(output_frames) / output_fps
        
        logger.info(f"Setting output FPS to {output_fps:.3f} (vs original {fps}) for correct timing")
        logger.info(f"Output video will be {len(output_frames) / output_fps:.3f}s duration")
        
        # Write output video
        logger.info("Writing output video...")
        
        # Determine codec
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        if output_path.lower().endswith('.mov'):
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        elif output_path.lower().endswith('.avi'):
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
        
        # Create video writer with correct frame rate
        out = cv2.VideoWriter(output_path, fourcc, output_fps, 
                            (video_info['width'], video_info['height']))
        
        if not out.isOpened():
            raise RuntimeError(f"Could not open output video writer: {output_path}")
        
        # Write all frames
        for frame in tqdm(output_frames, desc="Writing frames"):
            out.write(frame)
        
        out.release()
        logger.info(f"Successfully wrote {len(output_frames)} frames to {output_path}")
    
    def _parse_color(self, color_str: str) -> tuple[int, int, int]:
        """Parse color string (rrggbb or rrggbbaa) to BGR tuple for OpenCV."""
        if len(color_str) >= 6:
            r = int(color_str[0:2], 16)
            g = int(color_str[2:4], 16) 
            b = int(color_str[4:6], 16)
            return (b, g, r)  # OpenCV uses BGR
        return (0, 0, 0)
    
    def process_video(self, path: str, output: Optional[str] = None,
                     start_speed: int = 100, start_numf: int = 30,
                     mid_speed: int = 100, end_speed: int = 100, end_numf: int = 30,
                     fadein_color: str = "000000", fadein_numf: int = 0,
                     fadeout_color: Optional[str] = None, fadeout_numf: int = 0,
                     speed_function: str = "desi", fade_function: str = "desi",
                     fps: Optional[float] = None, verbose: bool = False) -> str:
        """
        Process video with speed changes and fade effects.
        
        Args:
            path: Input video path
            output: Output video path (auto-generated if not provided)
            start_speed: Speed multiplier percentage at start (default: 100)
            start_numf: Number of frames for start speed transition (default: 30)
            mid_speed: Speed multiplier percentage for middle section (default: 100)
            end_speed: Speed multiplier percentage at end (default: 100)
            end_numf: Number of frames for end speed transition (default: 30)
            fadein_color: Fade-in color in rrggbb or rrggbbaa format (default: 000000)
            fadein_numf: Number of frames for fade-in (default: 0)
            fadeout_color: Fade-out color (default: same as fadein_color)
            fadeout_numf: Number of frames for fade-out (default: 0)
            speed_function: Speed transition function (default: desi)
            fade_function: Fade transition function (default: desi)
            fps: Output video frame rate (default: auto-calculated for proper timing)
            verbose: Enable verbose logging (default: False)
        
        Returns:
            Path to the output video file
        """
        if verbose:
            logger.enable(__name__)
        
        # Validate input file
        input_path = Path(path)
        if not input_path.exists():
            raise FileNotFoundError(f"Input video not found: {path}")
        
        # Generate output path if not provided
        if output is None:
            output_path = input_path.parent / f"{input_path.stem}_processed{input_path.suffix}"
        else:
            output_path = Path(output)
        
        # Set default fadeout color
        if fadeout_color is None:
            fadeout_color = fadein_color
        
        logger.info(f"Processing video: {input_path}")
        logger.info(f"Output: {output_path}")
        
        # Get video information
        video_info = self._get_video_info(str(input_path))
        logger.info(f"Video info: {video_info['total_frames']} frames, {video_info['fps']:.2f} fps")
        
        # Process video with frame-by-frame precision using OpenCV
        temp_video_path = str(output_path).replace('.mp4', '_temp_video.mp4')
        
        self._process_video_with_precise_speed(
            str(input_path), temp_video_path, video_info,
            start_speed, start_numf, mid_speed, end_speed, end_numf, speed_function,
            fadein_color, fadeout_color, fadein_numf, fadeout_numf, fade_function, fps
        )
        
        # Merge audio from original video using FFmpeg
        try:
            # Check if original video has audio
            audio_cmd = [
                "ffprobe", "-v", "quiet", "-select_streams", "a", 
                "-show_entries", "stream=codec_name", "-of", "csv=p=0", str(input_path)
            ]
            audio_result = subprocess.run(audio_cmd, capture_output=True, text=True)
            
            if audio_result.stdout.strip():  # Has audio
                logger.info("Merging audio from original video...")
                merge_cmd = [
                    "ffmpeg", "-y",
                    "-i", temp_video_path,
                    "-i", str(input_path),
                    "-c:v", "copy", "-c:a", "aac",
                    "-map", "0:v:0", "-map", "1:a:0",
                    str(output_path)
                ]
                if not verbose:
                    merge_cmd.extend(["-v", "warning"])
                
                subprocess.run(merge_cmd, check=True, capture_output=True, text=True)
                Path(temp_video_path).unlink()  # Remove temp file
                logger.info("Audio merged successfully")
            else:
                # No audio, just rename temp file
                Path(temp_video_path).rename(output_path)
                logger.info("No audio stream found, keeping video-only output")
                
        except subprocess.CalledProcessError as e:
            logger.warning(f"Audio merge failed: {e}, keeping video without audio")
            if Path(temp_video_path).exists():
                Path(temp_video_path).rename(output_path)
        
        logger.info(f"Successfully processed video: {output_path}")
        return str(output_path)

def main():
    """Main entry point for Fire CLI."""
    processor = VideoProcessor()
    fire.Fire(processor.process_video)

if __name__ == "__main__":
    main()