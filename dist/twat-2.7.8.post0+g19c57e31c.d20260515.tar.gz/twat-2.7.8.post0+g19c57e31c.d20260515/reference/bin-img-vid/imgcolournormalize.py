#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["colour-science", "fire", "Pillow", "numpy", "rich"]
# ///
# this_file: imgcolournormalize.py
"""Harmonize image colors to a reference using Reinhard's Lab transfer (colour-science)."""

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message='.*"SciPy" related API features are not available.*')
warnings.filterwarnings("ignore", message='.*"Matplotlib" related API features are not available.*')

import colour
import fire
import numpy as np
from PIL import Image
from rich.console import Console

# Suppress colour-science runtime warnings (noisy with out-of-gamut pixels)
colour.utilities.filter_warnings(colour_usage_warnings=False)

EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp"}
LOSSY_EXTENSIONS = {".jpg", ".jpeg", ".webp"}
EPSILON = 1e-6
SRGB = colour.RGB_COLOURSPACES["sRGB"]
console = Console()


def load_image(path: Path) -> np.ndarray:
    """Load image as float64 [0,1] sRGB array (H, W, 3)."""
    with Image.open(path) as image:
        return np.asarray(image.convert("RGB"), dtype=np.float64) / 255.0


def save_kwargs(path: Path) -> dict[str, int]:
    """Return Pillow save options appropriate for the target extension."""
    if path.suffix.lower() in LOSSY_EXTENSIONS:
        return {"quality": 95}
    return {}


def save_image(arr: np.ndarray, path: Path) -> None:
    """Save float64 [0,1] array as 8-bit image, format from extension."""
    out = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    Image.fromarray(out).save(path, **save_kwargs(path))


def srgb_to_lab(img: np.ndarray) -> np.ndarray:
    """sRGB [0,1] float → CIE L*a*b* via colour-science (D65 illuminant)."""
    linear = SRGB.cctf_decoding(img)
    xyz = colour.RGB_to_XYZ(linear, SRGB)
    return colour.XYZ_to_Lab(xyz)


def lab_to_srgb(lab: np.ndarray) -> np.ndarray:
    """CIE L*a*b* → sRGB [0,1] float, clipped to gamut."""
    xyz = colour.Lab_to_XYZ(lab)
    linear = colour.XYZ_to_RGB(xyz, SRGB)
    srgb = SRGB.cctf_encoding(np.clip(linear, 0, None))
    return np.clip(srgb, 0, 1)


def compute_lab_stats(img: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return (mean, std) per Lab channel, shape (3,) each."""
    lab = srgb_to_lab(img)
    pixels = lab.reshape(-1, 3)
    return pixels.mean(axis=0), pixels.std(axis=0)


def reinhard_transfer(
    src: np.ndarray, ref_mean: np.ndarray, ref_std: np.ndarray
) -> np.ndarray:
    """Reinhard et al. color transfer: match Lab channel statistics."""
    src_lab = srgb_to_lab(src)
    s_mean = src_lab.reshape(-1, 3).mean(axis=0)
    s_std = src_lab.reshape(-1, 3).std(axis=0)
    result = (src_lab - s_mean) * (ref_std / (s_std + EPSILON)) + ref_mean
    return lab_to_srgb(result)


def validate_paths(reference: str, input_dir: str, output_dir: str) -> tuple[Path, Path, Path]:
    """Resolve paths and reject missing inputs or unsafe output locations."""
    ref_path = Path(reference).expanduser().resolve()
    in_dir = Path(input_dir).expanduser().resolve()
    out_dir = Path(output_dir).expanduser().resolve()

    if not ref_path.is_file():
        console.print(f"[red]Reference image not found: {ref_path}[/red]")
        sys.exit(1)
    if not in_dir.is_dir():
        console.print(f"[red]Input directory not found: {in_dir}[/red]")
        sys.exit(1)
    if out_dir == in_dir or out_dir.is_relative_to(in_dir):
        console.print(f"[red]Output directory must not be the input directory or inside it: {out_dir}[/red]")
        sys.exit(1)

    return ref_path, in_dir, out_dir


def collect_images(in_dir: Path) -> list[Path]:
    """Collect supported image files from the input tree."""
    return sorted(
        path for path in in_dir.rglob("*") if path.is_file() and path.suffix.lower() in EXTENSIONS
    )


def harmonize(reference: str, input_dir: str, output_dir: str) -> None:
    """Harmonize all images in input_dir to match the reference image's colors.

    Args:
        reference:  Path to the hero/reference image.
        input_dir:  Folder to scan recursively for images.
        output_dir: Destination folder (structure mirrors input_dir).
    """
    ref_path, in_dir, out_dir = validate_paths(reference, input_dir, output_dir)

    # Precompute reference Lab statistics (done once)
    console.print(f"[bold]Reference:[/bold] {ref_path}")
    ref_img = load_image(ref_path)
    ref_mean, ref_std = compute_lab_stats(ref_img)
    console.print(f"  Lab mean: L={ref_mean[0]:.1f}  a={ref_mean[1]:.1f}  b={ref_mean[2]:.1f}")
    console.print(f"  Lab std:  L={ref_std[0]:.1f}  a={ref_std[1]:.1f}  b={ref_std[2]:.1f}")

    # Collect images
    images = collect_images(in_dir)
    if not images:
        console.print(f"[yellow]No images found in {in_dir}[/yellow]")
        return
    console.print(f"\n[bold]Processing {len(images)} images[/bold] → {out_dir}\n")

    ok, fail = 0, 0
    for src_path in images:
        rel = src_path.relative_to(in_dir)
        dst = out_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            src_img = load_image(src_path)
            result = reinhard_transfer(src_img, ref_mean, ref_std)
            save_image(result, dst)
            ok += 1
            console.print(f"  [green]OK[/green]   {rel}")
        except Exception as e:
            fail += 1
            console.print(f"  [red]FAIL[/red] {rel}: {e}")

    console.print(f"\n[bold]Done:[/bold] {ok} processed, {fail} errors")
    if fail:
        raise SystemExit(1)


if __name__ == "__main__":
    fire.Fire(harmonize)
