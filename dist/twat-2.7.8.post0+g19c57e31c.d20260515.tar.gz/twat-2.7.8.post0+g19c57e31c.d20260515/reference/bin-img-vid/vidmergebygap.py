#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["av", "ffmpeg-python", "fire", "pillow", "rich"]
# ///
# this_file: vidmergebygap.py

import asyncio
import concurrent.futures
import logging
from pathlib import Path

import av
import ffmpeg
import fire
from PIL import Image, ImageDraw, ImageFont
from rich.console import Console
from rich.logging import RichHandler
from rich.progress import Progress

console = Console()


def setup_logging(verbose=False):
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(rich_tracebacks=True)],
    )
    return logging.getLogger("rich")


def probe_video(video_path):
    try:
        probe = ffmpeg.probe(video_path)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )
        audio_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "audio"),
            None,
        )

        return {
            "width": int(video_stream["width"]),
            "height": int(video_stream["height"]),
            "video_codec": video_stream["codec_name"],
            "audio_codec": audio_stream["codec_name"] if audio_stream else None,
            "pix_fmt": video_stream["pix_fmt"],
            "sample_rate": int(audio_stream["sample_rate"]) if audio_stream else None,
            "duration": float(probe["format"]["duration"]),
        }
    except ffmpeg.Error as e:
        console.print(
            f"[bold red]Error probing video {video_path}:[/bold red] {e.stderr.decode()}"
        )
        raise


def create_title_frame(text, width, height, bg_color, output_path):
    # Convert bg_color from hex to RGB
    bg_rgb = tuple(int(bg_color[i : i + 2], 16) for i in (0, 2, 4))

    # Calculate text color as black or white based on background color brightness
    brightness = (0.299 * bg_rgb[0] + 0.587 * bg_rgb[1] + 0.114 * bg_rgb[2]) / 255
    text_rgb = (0, 0, 0) if brightness > 0.5 else (255, 255, 255)

    image = Image.new("RGB", (width, height), bg_rgb)
    draw = ImageDraw.Draw(image)

    if text:
        font = font = ImageFont.load_default(size=int(height / 15))
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_position = ((width - text_bbox[2]) / 2, (height - text_bbox[3]) / 2)
        draw.text(text_position, text, font=font, fill=text_rgb)

    image.save(output_path)


async def extract_frames(video_path, intro_path, outro_path):
    with av.open(video_path) as container:
        stream = container.streams.video[0]
        container.seek(0)
        if not Path(intro_path).exists():
            for frame in container.decode(video=0):
                frame.to_image().save(intro_path)
                break
        container.seek(-1, any_frame=False, backward=True, stream=stream)
        if not Path(outro_path).exists():
            for packet in container.demux(stream):
                for frame in packet.decode():
                    pass  # Decode all frames to get the last one
            frame.to_image().save(outro_path)


async def create_video_segment(frame_path, duration, video_info, output_path):
    try:
        frame_input = ffmpeg.input(frame_path, loop=1, t=duration)
        silent_audio = ffmpeg.input(
            f"anullsrc=channel_layout=stereo:sample_rate={video_info['sample_rate']}:d={duration}",
            f="lavfi",
        )
        output = ffmpeg.output(
            frame_input,
            silent_audio,
            str(output_path),
            vcodec=video_info["video_codec"],
            acodec=video_info["audio_codec"],
            t=duration,
            pix_fmt=video_info["pix_fmt"],
        )
        output = output.overwrite_output()
        await asyncio.to_thread(output.run, capture_stdout=True, capture_stderr=True)
    except ffmpeg.Error as e:
        console.print("[bold red]Error in `create_video_segment`:[/bold red]")
        console.print(f"[red]STDOUT:[/red]\n{e.stdout.decode()}")
        console.print(f"[red]STDERR:[/red]\n{e.stderr.decode()}")
        raise


async def create_intro_outro(frame_path, duration, video_info, output_path):
    try:
        frame_input = ffmpeg.input(frame_path, loop=1, t=duration)
        silent_audio = ffmpeg.input(
            f"anullsrc=channel_layout=stereo:sample_rate={video_info['sample_rate']}:d={duration}",
            f="lavfi",
        )
        output = ffmpeg.output(
            frame_input,
            silent_audio,
            str(output_path),  # Convert output_path to string
            vcodec=video_info["video_codec"],
            acodec=video_info["audio_codec"],
            t=duration,
            pix_fmt=video_info["pix_fmt"],
        )
        output = output.overwrite_output()
        await asyncio.to_thread(output.run, capture_stdout=True, capture_stderr=True)
    except ffmpeg.Error as e:
        console.print("[bold red]Error in `create_intro_outro`:[/bold red]")
        console.print(f"{frame_path=}, {duration=}, {video_info=}, {output_path=}")
        console.print(f"[red]STDOUT:[/red]\n{e.stdout.decode()}")
        console.print(f"[red]STDERR:[/red]\n{e.stderr.decode()}")
        raise


async def process_video(
    video_path,
    intro_duration,
    gap_duration,
    title_duration,
    color,
    video_info,
    temp_dir,
    progress,
    task,
    logger,
):
    base_name = Path(video_path).stem
    output_path = temp_dir / f"{base_name}-merged.mp4"

    segments = []

    # Create gap slide
    if gap_duration > 0:
        gap_frame = temp_dir / "gap.png"
        if not gap_frame.exists():
            logger.debug(f"Creating gap slide: {gap_frame}")
            create_title_frame(
                "", video_info["width"], video_info["height"], color, gap_frame
            )

        gap_video = temp_dir / "gap.mp4"
        if not gap_video.exists():
            logger.debug(f"Creating gap video: {gap_video}")
            await create_video_segment(gap_frame, gap_duration, video_info, gap_video)
        segments.append(gap_video)

    # Create title slide
    if title_duration > 0:
        title_frame = temp_dir / f"{base_name}-title.png"
        if not Path(title_frame).exists():
            logger.debug(f"Creating title slide: {title_frame}")
            create_title_frame(
                base_name, video_info["width"], video_info["height"], color, title_frame
            )
        title_video = temp_dir / f"{base_name}-title.mp4"
        if not Path(title_video).exists():
            logger.debug(f"Creating title video: {title_video}")
            await create_video_segment(
                title_frame, title_duration, video_info, title_video
            )
        segments.append(title_video)

    if intro_duration > 0:
        intro_frame = temp_dir / f"{base_name}-intro.png"
        outro_frame = temp_dir / f"{base_name}-outro.png"
        if not Path(intro_frame).exists() or not Path(outro_frame).exists():
            logger.debug(f"Extracting intro and outro frame: {intro_frame}")
            await extract_frames(video_path, intro_frame, outro_frame)

        intro_video = temp_dir / f"{base_name}-intro.mp4"
        if not Path(intro_video).exists():
            logger.debug(f"Creating intro video: {intro_video}")
            await create_video_segment(
                intro_frame, intro_duration, video_info, intro_video
            )

        outro_video = temp_dir / f"{base_name}-outro.mp4"
        if not Path(outro_video).exists():
            logger.debug(f"Creating outro video: {outro_video}")
            await create_video_segment(
                outro_frame, intro_duration, video_info, outro_video
            )

        segments.extend([intro_video, str(video_path), outro_video])
    else:
        segments.append(str(video_path))

    if gap_duration > 0:
        segments.append(gap_video)

    # Concatenate all segments
    inputs = []
    for segment in segments:
        logger.debug(f"Adding segment to concat list: {segment}")
        input_file = ffmpeg.input(str(segment))
        inputs.extend([input_file["v"], input_file["a"]])

    if not Path(output_path).exists():
        try:
            logger.debug(f"Concatenating segments into output video: {output_path}")
            (
                ffmpeg.concat(*inputs, v=1, a=1)
                .output(
                    str(output_path),
                    vcodec=video_info["video_codec"],
                    acodec=video_info["audio_codec"],
                    pix_fmt=video_info["pix_fmt"],
                )
                .overwrite_output()
                .run(capture_stdout=True, capture_stderr=True)
            )
        except ffmpeg.Error as e:
            console.print(
                "[bold red]Error during final video concatenation:[/bold red]"
            )
            console.print(f"[red]STDOUT:[/red]\n{e.stdout.decode()}")
            console.print(f"[red]STDERR:[/red]\n{e.stderr.decode()}")
            raise

    progress.update(task, advance=1)
    return output_path


async def merge_videos(
    input_dir: str,
    output: str,
    intro: float = 2.0,
    gap: float = 2.0,
    title: float = 0.5,
    color: str = "000000",
    verbose: bool = False,
):
    logger = setup_logging(verbose)

    logger.info("Starting video merge process")
    logger.info(f"  Input directory: {input_dir}")
    logger.info(f"  Output file: {output}")
    logger.info(f"  Intro duration: {intro} seconds")
    logger.info(f"  Gap duration: {gap} seconds")
    logger.info(f"  Gap color: #{color}")

    input_path = Path(input_dir)
    output_path = Path(output)

    if not input_path.is_dir():
        console.print(
            f"[bold red]Error:[/bold red] The input directory {input_dir} does not exist."
        )
        return

    video_files = sorted(input_path.glob("*.mp4"))
    if not video_files:
        console.print(
            f"[bold red]Error:[/bold red] No MP4 files found in the directory {input_dir}."
        )
        return

    logger.info(f"Found {len(video_files)} MP4 files in {input_dir}.")

    # Probe the first video
    logger.debug(f"Probing video: {video_files[0]}")
    video_info = await asyncio.to_thread(probe_video, str(video_files[0]))

    # Create temp directory in the same folder as the output file
    temp_dir = output_path.with_suffix(".tmp")
    temp_dir.mkdir(exist_ok=True, parents=True)

    with Progress() as progress:
        task = progress.add_task("[cyan]Processing videos...", total=len(video_files))

        # Process videos in parallel
        with concurrent.futures.ThreadPoolExecutor():
            futures = [
                asyncio.ensure_future(
                    process_video(
                        str(video_file),
                        intro,
                        gap,
                        title,
                        color,
                        video_info,
                        temp_dir,
                        progress,
                        task,
                        logger,
                    )
                )
                for video_file in video_files
            ]
            processed_videos = await asyncio.gather(*futures)

    # Concatenate all processed videos
    logger.info("Concatenating final video...")
    try:
        inputs = []
        for video in processed_videos:
            logger.debug(f"Adding processed video to concat list: {video}")
            input_file = ffmpeg.input(str(video))
            inputs.extend([input_file["v"], input_file["a"]])

        logger.debug(f"Concatenating processed videos into final output: {output_path}")
        (
            ffmpeg.concat(*inputs, v=1, a=1)
            .output(
                str(output_path),
                vcodec=video_info["video_codec"],
                acodec=video_info["audio_codec"],
                pix_fmt=video_info["pix_fmt"],
            )
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
    except ffmpeg.Error as e:
        console.print("[bold red]Error during final video concatenation:[/bold red]")
        console.print(f"[red]STDOUT:[/red]\n{e.stdout.decode()}")
        console.print(f"[red]STDERR:[/red]\n{e.stderr.decode()}")
        raise

    logger.info("Video merge completed successfully!")
    logger.info(f"Output video saved to {output}")
    logger.info(f"Temporary files are kept in the '{temp_dir}' folder for inspection.")


def run_merge_videos(
    input_dir: str,
    output: str,
    padding: float = 2.0,
    gap: float = 2.0,
    title: float = 0.5,
    color: str = "000000",
    verbose: bool = False,
):
    asyncio.run(
        merge_videos(
            input_dir=input_dir,
            output=output,
            intro=padding,
            gap=gap,
            title=title,
            color=color,
            verbose=verbose,
        )
    )


if __name__ == "__main__":
    fire.Fire(run_merge_videos)
