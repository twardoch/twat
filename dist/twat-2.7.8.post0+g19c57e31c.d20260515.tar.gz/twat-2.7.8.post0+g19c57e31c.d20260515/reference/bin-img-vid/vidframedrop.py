#!/usr/bin/env -S uv run -s
# /// script
# dependencies = [
#     'opencv-python>=4.8.0',  # Using full package for potentially better type hinting
#     'numpy>=1.24.0',
#     'fire',
#     'rich',
# ]
# ///
# this_file: vidframedrop.py

"""
Video Frame Selector

This script processes a video file and selects the sharpest frame from each batch
of N consecutive frames, creating a new video with reduced frame rate but optimized
for frame quality.

The script uses the Tenengrad (Sobel) method for sharpness detection, which is more
robust to noise compared to simple Laplacian variance. It processes frames in batches,
keeping only the sharpest frame from each batch while maintaining the video's original
duration by adjusting the output frame rate.

Features:
- Robust sharpness detection using Sobel gradients
- Memory-efficient batch processing
- Progress bar with detailed statistics
- Configurable output codec
- Detailed logging with verbose mode
- Error handling with graceful fallbacks

Examples:
    # Keep sharpest frame from every 3 frames (reduces to 1/3 frame count)
    vidframedrop.py --input video.mp4 --keep_every 3

    # Keep sharpest from every 5 frames with verbose output
    vidframedrop.py --input video.mp4 --keep_every 5 --verbose

    # Custom output path
    vidframedrop.py --input video.mp4 --keep_every 3 --output sharp_video.mp4

    # Aggressive reduction (1/10 frames) for timelapse effect
    vidframedrop.py --input video.mp4 --keep_every 10

Use cases:
    - Reduce video file size while keeping sharpest frames
    - Remove motion blur from handheld footage
    - Create smoother slow-motion from high-fps footage
    - Timelapse-like effect with quality preservation

Note:
    Output video will not contain audio (OpenCV limitation).
    Use viddub-av.py or viddub-ffm.py to add audio back afterward.
"""

import logging
import sys
import time
from pathlib import Path

import cv2
import fire
import numpy as np
from rich.logging import RichHandler
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
)

# --- Constants ---
DEFAULT_SUFFIX_FORMAT = "_window{window}_keep{keep}{fps_note}"
DEFAULT_FOURCC = "mp4v"  # Common FourCC codes: 'mp4v' (MPEG-4), 'avc1' (H.264)
FALLBACK_FPS = 30.0  # Default FPS if cannot be determined from input
MIN_FRAME_DIMENSION = 16  # Minimum allowed frame dimension

# --- Logging Setup ---
log = logging.getLogger(__name__)


def setup_logging(verbose: bool) -> None:
    """Configure logging using RichHandler with proper formatting."""
    log_level = logging.DEBUG if verbose else logging.INFO
    if not log.handlers:
        log.setLevel(log_level)
        handler = RichHandler(markup=True, rich_tracebacks=True, show_path=False)
        handler.setFormatter(logging.Formatter("%(message)s"))
        log.addHandler(handler)
        log.propagate = False  # Prevent duplicate logs if root logger is configured
    log.debug("Verbose logging enabled.")


def calculate_sharpness(frame: np.ndarray) -> float:
    """
    Calculate frame sharpness using the Tenengrad (Sobel) method.

    This method is more robust to noise compared to Laplacian variance. It uses
    Sobel operators to compute gradient magnitude, which effectively captures
    edge strength and overall image sharpness.

    Args:
        frame: Input video frame (BGR format)

    Returns:
        float: Sharpness score (higher is sharper). Returns -1.0 on error.

    Technical Details:
        1. Converts frame to grayscale
        2. Applies Sobel operators in X and Y directions
        3. Computes gradient magnitude
        4. Returns mean gradient magnitude as sharpness score
    """
    if frame is None or frame.size == 0:
        log.warning("Received invalid frame for sharpness calculation.")
        return -1.0

    try:
        # Convert to grayscale for edge detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Apply Sobel operators
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)

        # Compute gradient magnitude
        magnitude = cv2.magnitude(grad_x, grad_y)

        # Use mean gradient magnitude as sharpness score
        # Ensure magnitude is treated as a numerical array for np.mean
        score = float(np.mean(magnitude.astype(np.float64)))

        log.debug(f"Calculated sharpness score: {score:.2f}")
        return score

    except cv2.error as cv_err:
        log.error(f"OpenCV error calculating sharpness: {cv_err}")
        return -1.0
    except Exception as e:
        log.error(f"Error calculating sharpness: {e}")
        return -1.0


def validate_video_properties(
    frame_width: int, frame_height: int, input_fps: float
) -> tuple[bool, str]:
    """
    Validate video properties to ensure they are within acceptable ranges.

    Args:
        frame_width: Width of video frames
        frame_height: Height of video frames
        input_fps: Input video frame rate

    Returns:
        Tuple[bool, str]: (is_valid, error_message)
    """
    if frame_width < MIN_FRAME_DIMENSION or frame_height < MIN_FRAME_DIMENSION:
        return False, f"Invalid frame dimensions: {frame_width}x{frame_height}"

    # Allow 0 FPS as it might indicate an issue handled later
    if input_fps < 0:
        return False, f"Invalid input FPS: {input_fps}"

    return True, ""


def setup_paths(
    input_path_str: str,
    output_path_str: str | None,
    window: int,
    keep: int,
    fps_recalc: bool = False,
) -> tuple[Path, Path]:
    """
    Validate input path, determine and create output path.

    Args:
        input_path_str: Path to input video file.
        output_path_str: Optional output path.
        window: Number of consecutive frames to analyze.
        keep: Number of frames to keep from each window.
        fps_recalc: Whether FPS is recalculated to maintain runtime.

    Returns:
        Tuple[Path, Path]: (input_path, output_path).

    Raises:
        FileNotFoundError: If input file doesn't exist.
        ValueError: If input and output paths are the same or parameters are invalid.
    """
    if window <= 0:
        raise ValueError(f"window must be positive, got {window}")

    if keep <= 0:
        raise ValueError(f"keep must be positive, got {keep}")

    if keep > window:
        raise ValueError(
            f"keep cannot be greater than window (got keep={keep}, window={window})"
        )

    input_path = Path(input_path_str)
    if not input_path.is_file():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if output_path_str:
        output_path = Path(output_path_str)
    else:
        # Add note about FPS to the filename
        fps_note = "_fps_orig" if not fps_recalc else "_fps_adjusted"
        suffix = DEFAULT_SUFFIX_FORMAT.format(
            window=window, keep=keep, fps_note=fps_note
        )
        output_filename = f"{input_path.stem}{suffix}{input_path.suffix}"
        output_path = input_path.with_name(output_filename)

    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if input_path.resolve() == output_path.resolve():
        raise ValueError("Output path cannot be the same as input path")

    log.info(f"Input path: {input_path}")
    log.info(f"Output path: {output_path}")
    return input_path, output_path


def initialize_video_reader(
    input_path: Path,
) -> tuple[cv2.VideoCapture, int, int, float, int | None]:
    """
    Open video file, read properties, validate them.

    Args:
        input_path: Path to the input video file.

    Returns:
        Tuple: (capture_object, frame_width, frame_height, input_fps, total_frames).
               total_frames can be None if count is unavailable.

    Raises:
        RuntimeError: If video cannot be opened.
        ValueError: If video properties are invalid.
    """
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {input_path}")

    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    input_fps = cap.get(cv2.CAP_PROP_FPS)
    # Get frame count, handle potential non-integer or zero return
    _total_frames_raw = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    total_frames: int | None = None
    if _total_frames_raw is not None and _total_frames_raw > 0:
        total_frames = int(_total_frames_raw)
    else:
        log.warning("Could not determine total frame count reliably.")

    is_valid, error_msg = validate_video_properties(
        frame_width, frame_height, input_fps
    )
    if not is_valid:
        cap.release()
        raise ValueError(f"Invalid video properties: {error_msg}")

    if input_fps <= 0:
        log.warning(
            f"Could not determine input FPS or invalid FPS ({input_fps}). Using fallback: {FALLBACK_FPS}"
        )
        input_fps = FALLBACK_FPS  # Assign fallback

    log.info(f"Input video: {frame_width}x{frame_height} @ {input_fps:.2f} FPS")
    if total_frames:
        log.info(f"Total frames: {total_frames:,}")

    return cap, frame_width, frame_height, input_fps, total_frames


def initialize_video_writer(
    output_path: Path, fourcc_str: str, output_fps: float, frame_size: tuple[int, int]
) -> cv2.VideoWriter:
    """
    Initialize the video writer object.

    Args:
        output_path: Path for the output video.
        fourcc_str: FourCC code for the codec.
        output_fps: Frame rate for the output video.
        frame_size: Dimensions (width, height) of the video frames.

    Returns:
        cv2.VideoWriter: Initialized video writer object.

    Raises:
        RuntimeError: If the writer cannot be created or opened.
    """
    try:
        fourcc = cv2.VideoWriter_fourcc(*fourcc_str)
        out = cv2.VideoWriter(str(output_path), fourcc, output_fps, frame_size)
        if not out.isOpened():
            # Provide more specific error hints
            raise RuntimeError(
                f"Could not create output video '{output_path}'. "
                f"Check codec '{fourcc_str}' compatibility, permissions, and disk space."
            )
        log.info(f"Output video settings: {fourcc_str} codec, {output_fps:.2f} FPS")
        return out
    except Exception as e:
        # Catch potential errors during FourCC creation or VideoWriter init
        raise RuntimeError(f"Error creating output video writer: {e}")


def process_frame_batch(
    frame_batch: list[np.ndarray], batch_number: int, num_to_keep: int = 1
) -> list[np.ndarray]:
    """
    Calculate sharpness for a batch of frames and return the sharpest ones in original order.

    Args:
        frame_batch: List of frames in the current batch.
        batch_number: The sequence number of this batch (for logging).
        num_to_keep: Number of sharpest frames to return (default: 1).

    Returns:
        List[np.ndarray]: List of the sharpest frames in their original order, or empty list if all frames failed.
    """
    if not frame_batch:
        log.warning(f"Batch {batch_number}: Received empty batch.")
        return []

    # Calculate sharpness for each frame
    sharpness_scores = [calculate_sharpness(f) for f in frame_batch]
    log.debug(f"Batch {batch_number} scores: {[f'{s:.2f}' for s in sharpness_scores]}")

    # Filter out invalid scores
    valid_indices = [i for i, s in enumerate(sharpness_scores) if s > -1.0]
    valid_scores = [sharpness_scores[i] for i in valid_indices]

    if not valid_indices:
        log.warning(
            f"Batch {batch_number}: All frames failed sharpness calculation. Skipping batch."
        )
        return []  # Indicate failure to find best frames

    # Find indices of the top N frames by sharpness
    if len(valid_indices) <= num_to_keep:
        # If we have fewer valid frames than requested, use all of them
        selected_indices = valid_indices
    else:
        # Select the indices of the top N scores
        # First create (index, score) pairs for valid frames
        index_score_pairs = [
            (valid_indices[i], valid_scores[i]) for i in range(len(valid_indices))
        ]
        # Sort by score in descending order
        sorted_pairs = sorted(index_score_pairs, key=lambda x: x[1], reverse=True)
        # Take the indices of the top N frames
        selected_indices = [pair[0] for pair in sorted_pairs[:num_to_keep]]
        # Sort these indices to preserve original frame order
        selected_indices.sort()

    # Create list of selected frames in original order
    best_frames = [frame_batch[i] for i in selected_indices]

    # Log information about selected frames
    score_info = ", ".join(
        [f"frame {i} (score: {sharpness_scores[i]:.2f})" for i in selected_indices]
    )
    log.debug(
        f"Batch {batch_number}: Selected {len(selected_indices)} frames: {score_info}"
    )

    return best_frames


def process_all_frames(
    cap: cv2.VideoCapture,
    out: cv2.VideoWriter,
    total_frames: int | None,
    input_path_name: str,
    keep: int,
    window: int,
) -> tuple[int, int]:
    """
    Read frames, process in batches, write sharpest frames, and show progress.

    Args:
        cap: Initialized video capture object.
        out: Initialized video writer object.
        total_frames: Estimated total frames (for progress bar), can be None.
        input_path_name: Name of the input file for progress display.
        keep: Number of sharpest frames to keep from each window.
        window: Number of consecutive frames to analyze in each batch.

    Returns:
        Tuple[int, int]: (total_frames_processed, total_frames_written).
    """
    frame_batch: list[np.ndarray] = []
    frames_processed = 0
    frames_written = 0
    batch_number = 0

    progress_columns = [
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn(
            "Frames: {task.completed}/{task.total} (Written: {task.fields[written]})"
        ),
        TimeRemainingColumn(),
    ]

    with Progress(*progress_columns, transient=True) as progress:
        task_description = f"Processing [cyan]{input_path_name}[/]"
        # Use float('inf') if total_frames is None, but rich handles None gracefully now
        task = progress.add_task(task_description, total=total_frames, written=0)

        while True:
            ret, frame = cap.read()
            if not ret:
                log.debug("End of video stream reached.")
                break  # End of video

            frames_processed += 1
            # Ensure frame data is copied if needed, especially if modifying frame_batch later
            frame_batch.append(frame)

            if len(frame_batch) == window:
                batch_number += 1
                best_frames = process_frame_batch(frame_batch, batch_number, keep)
                for best_frame in best_frames:
                    out.write(best_frame)
                frames_written += len(best_frames)
                frame_batch.clear()  # Clear batch for next set

            # Update progress bar
            progress.update(task, completed=frames_processed, written=frames_written)

        # Process any remaining frames in the last incomplete batch
        if frame_batch:
            batch_number += 1
            log.info(f"Processing final batch of {len(frame_batch)} frames...")
            # For the last batch, adjust the number of frames to keep proportionally
            num_to_keep = max(1, int(keep * len(frame_batch) / window))
            log.debug(
                f"Last batch: keeping {num_to_keep} frames from {len(frame_batch)} frames"
            )
            best_frames = process_frame_batch(frame_batch, batch_number, num_to_keep)
            for best_frame in best_frames:
                out.write(best_frame)
            frames_written += len(best_frames)
            # No need to clear frame_batch here as loop is ending

        # Ensure progress bar completes if total_frames was known
        if total_frames is not None:
            progress.update(task, completed=total_frames, written=frames_written)

    return frames_processed, frames_written


def log_summary(
    start_time: float, frames_processed: int, frames_written: int, output_path: Path
) -> None:
    """Log summary statistics after processing."""
    duration = time.monotonic() - start_time
    frames_per_second = frames_processed / duration if duration > 0 else 0

    log.info(f"Processed {frames_processed:,} frames, wrote {frames_written:,} frames")
    log.info(f"Processing speed: {frames_per_second:.1f} frames/second")
    log.info(f"Total processing time: {duration:.2f} seconds")
    log.info(f"[bold green]Output saved to:[/bold green] {output_path}")


def process_video(
    input_path_str: str,
    keep: int = 3,
    window: int = 6,
    output_path_str: str | None = None,
    verbose: bool = False,
    fourcc_str: str = DEFAULT_FOURCC,
    fps_recalc: bool = False,
) -> None:
    """
    Main function to process video: reads, selects sharpest frames, and writes output.

    Orchestrates the setup, processing, and cleanup steps.

    Args:
        input_path_str: Path to input video file.
        keep: Number of sharpest frames to keep from each window.
        window: Number of consecutive frames to analyze in each batch.
        output_path_str: Optional output path (default: input path + suffix).
        verbose: Enable verbose logging.
        fourcc_str: FourCC codec code for output video (e.g., 'mp4v', 'avc1').
        fps_recalc: If True, recalculate FPS to maintain original runtime.
                    If False (default), keep original FPS, making video run faster.

    Raises:
        RuntimeError: If video cannot be opened, processed, or written.
        ValueError: If input parameters are invalid or video properties are unsuitable.
        FileNotFoundError: If the input video file does not exist.
    """
    setup_logging(verbose)
    start_time = time.monotonic()
    log.info(
        f"Starting video processing: window={window}, keep={keep}, codec={fourcc_str}, fps_recalc={fps_recalc}"
    )

    cap = None
    out = None
    frames_processed = 0
    frames_written = 0

    try:
        # 1. Setup Paths
        input_path, output_path = setup_paths(
            input_path_str, output_path_str, window, keep, fps_recalc
        )

        # 2. Initialize Video Reader
        cap, frame_width, frame_height, input_fps, total_frames = (
            initialize_video_reader(input_path)
        )
        frame_size = (frame_width, frame_height)
        # Adjust output FPS based on fps_recalc setting
        if fps_recalc:
            # Recalculate FPS to maintain original runtime
            output_fps = input_fps * keep / window
            log.info(
                f"Recalculating FPS: {input_fps:.2f} → {output_fps:.2f} to maintain original runtime"
            )
        else:
            # Keep original FPS, which will make the video run faster
            output_fps = input_fps
            runtime_factor = window / keep
            log.info(
                f"Keeping original FPS: {input_fps:.2f}, video will run {runtime_factor:.1f}x faster"
            )

        # 3. Initialize Video Writer
        out = initialize_video_writer(output_path, fourcc_str, output_fps, frame_size)

        # 4. Process Frames
        frames_processed, frames_written = process_all_frames(
            cap, out, total_frames, input_path.name, keep, window
        )

        # 5. Log Summary (if successful)
        log_summary(start_time, frames_processed, frames_written, output_path)

    except (FileNotFoundError, ValueError, RuntimeError) as e:
        log.error(f"Processing failed: {e}")
        # Re-raise the caught exception to be handled by main()
        raise
    except KeyboardInterrupt:
        log.warning("Processing interrupted by user.")
        # Re-raise to allow main() to handle exit code
        raise
    except Exception as e:
        log.exception(f"An unexpected error occurred during processing: {e}")
        # Re-raise to allow main() to handle exit code
        raise
    finally:
        # 6. Cleanup Resources
        log.debug("Cleaning up resources...")
        if cap is not None and cap.isOpened():
            cap.release()
            log.debug("Video capture released.")
        if out is not None and out.isOpened():
            out.release()
            log.debug("Video writer released.")
        # cv2.destroyAllWindows() # Generally not needed for non-interactive scripts


def main():
    """CLI entry point using Google Fire."""
    try:
        fire.Fire(process_video)
    except (ValueError, FileNotFoundError, RuntimeError):
        # Error already logged in process_video, just set exit code
        sys.exit(1)
    except KeyboardInterrupt:
        # Message already logged in process_video
        sys.exit(130)  # Standard exit code for Ctrl+C
    except Exception as e:
        # Catch-all for unexpected errors not logged elsewhere
        log.exception(f"Unexpected error in main: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
