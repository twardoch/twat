

The video `/Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06.mp4` is approx 3 seconds and is 60 fps (I think the video in total is 160 frames). 

I run the @vidinout.py tool like so: 

```
 $ ~/bin/img/vidinout.py /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06.mp4 -o /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_33.mp4 --start_speed 33 --start_numf 60 --end_speed 33 --end_numf 60 --verbose
2025-08-21 02:11:24.794 | INFO | __main__:process_video:257 - Processing video: /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06.mp4
2025-08-21 02:11:24.794 | INFO | __main__:process_video:258 - Output: /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_processed.mp4
2025-08-21 02:11:25.437 | INFO | __main__:process_video:262 - Video info: 160 frames, 60.00 fps
2025-08-21 02:11:25.438 | INFO | __main__:_create_accurate_speed_filter:179 - Speed curve sample: frames 0-9: [0.1, 0.1005, 0.10200000000000001, 0.10450000000000001, 0.10800000000000001, 0.1125, 0.11800000000000001, 0.1245, 0.132, 0.1405]
2025-08-21 02:11:25.438 | INFO | __main__:_create_accurate_speed_filter:180 - Speed curve sample: frames 150-159: [0.15000000000000002, 0.14050000000000007, 0.132, 0.12450000000000006, 0.118, 0.11250000000000004, 0.10799999999999998, 0.10450000000000004, 0.10199999999999998, 0.10049999999999992]
2025-08-21 02:11:25.438 | INFO | __main__:_create_accurate_speed_filter:187 - Expected output duration: 7.206s (vs original 2.683s)
2025-08-21 02:11:25.439 | INFO | __main__:_create_accurate_speed_filter:192 - Using average speed multiplier: 0.6625
2025-08-21 02:11:25.439 | INFO | __main__:process_video:282 - Running FFmpeg command: ffmpeg -y -i /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06.mp4 -vf setpts=PTS/0.662500 -c:a copy /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_processed.mp4
2025-08-21 02:11:48.167 | INFO | __main__:process_video:295 - Successfully processed video: /Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_processed.mp4
/Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_processed.mp4
```

The resulting `/Users/adam/Movies/250820/test/vl-3840x2160-2s60f-250820-013748-06_processed.mp4` is 4 seconds. And the speed seems constant. 

The way @vidinout.py.md specs it, the resulting video should start 10x SLOWER (--start_speed 10) and then for 1 second speeds up at a double-exponential sigmoid curve. Then for < 1 second (40 frames) it runs at the original speed and then for 1 second it should slow down a double-exponential sigmoid curve all the way to 10x slower. 

Think hard and verify that this is what the tool does. Are you 100% sure? (I’m really not convinced).

If not, re-think the tool radically and rewrite it so that it does EXACTLY what I’ve specified. We don’t HAVE TO use ffmpeg. Let’s use what’s most appropriate! (Maybe ffmpeg IS the most appropriate.)

