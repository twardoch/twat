#!/usr/bin/env bash
# this_file: vidhalfsharpen.sh
# Resize video to half dimensions and apply slight sharpening

set -euo pipefail

# Check if an input file was provided
if [ -z "$1" ]; then
    echo "Usage: $0 input_video"
    exit 1
fi

input_file="$1"
# Get the base name of the file to construct the output filename
base_name=$(basename "$input_file")
output_file="half-$base_name"

# Execute ffmpeg to resize and slightly sharpen the video
ffmpeg -i "$input_file" -vf "scale=iw/2:ih/2,unsharp=3:3:0.5" -c:a copy "$output_file"
