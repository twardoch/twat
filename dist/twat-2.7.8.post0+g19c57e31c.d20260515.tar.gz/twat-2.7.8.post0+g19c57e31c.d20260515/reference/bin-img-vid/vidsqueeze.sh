#!/usr/bin/env bash
# this_file: vidsqueeze.sh
# Usage: fd -L -e mov -e mp4 -x ~/bin/img/vidsqueeze.sh {}
set -euo pipefail

echo ">>> $1"
python ~/bin/img/vidsqueeze.py "$1" -s --mp4
echo
