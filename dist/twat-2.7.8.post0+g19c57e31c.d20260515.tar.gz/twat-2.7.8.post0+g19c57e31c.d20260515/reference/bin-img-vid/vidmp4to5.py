#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "loguru", "rich", "static-ffmpeg"]
# ///
# this_file: vidmp4to5.py

"""
Transcode videos to H.265/HEVC in an .mp4 container with smart CRF selection.

Behaviour summary:
- Accepts one or more positional paths (or `--input_path`). All paths must be
  EITHER all files OR all folders — mixing is rejected.
- Files mode: each file is transcoded with the existing per-file pipeline.
- Folders mode: videos are gathered recursively across all input folders,
  HEVC files dropped, content-duplicate copies grouped across volumes by a
  fast (size + head/tail SHA-256) signature; transcoding runs once on the
  copy living on the fastest volume, then the result is propagated to all
  duplicate locations via hardlink (same volume) or copy (cross volume).
- Videos already encoded with H.265/HEVC are skipped (logged).
- Smart quality: for inputs longer than ~30 seconds we extract a short snippet
  from the middle, encode it at a few candidate CRF values, measure SSIM
  against the original snippet via ffmpeg's built-in `ssim` filter, and pick
  the highest CRF whose SSIM stays at or above ~0.97. Shorter inputs use a
  sensible default. Pass `--crf` to bypass the probe.
- `--keep` controls whether the original is preserved. For `.mp4` originals
  the kept output uses the `_hevc` suffix; for other extensions the new `.mp4`
  output uses the original stem (the extension change avoids a collision).
- Audio is copied if already AAC, otherwise re-encoded to AAC 128k.
- libx265 is used with `-preset medium` and `-tag:v hvc1` for QuickTime
  compatibility.

Examples:
    vidmp4to5.py clip.mov
    vidmp4to5.py /path/a.mov /path/b.mp4
    vidmp4to5.py /Volumes/Backup/vids /Users/me/vids --keep --verbose
    vidmp4to5.py clip.mp4 --crf 24
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import fire
import static_ffmpeg
from loguru import logger
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

console = Console()

logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
)

# --- constants ---------------------------------------------------------------

VIDEO_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".mp4",
        ".m4v",
        ".avi",
        ".mkv",
        ".mov",
        ".mpg",
        ".mpeg",
        ".webm",
        ".wmv",
    }
)

# CRF candidates ordered low-to-high (lower CRF = higher quality, larger file).
CRF_CANDIDATES: tuple[int, ...] = (23, 26, 28, 30)
DEFAULT_SHORT_VIDEO_CRF = 26
SHORT_VIDEO_THRESHOLD_SECONDS = 30.0
SSIM_THRESHOLD = 0.97
SNIPPET_DURATION_SECONDS = 8.0
HEVC_CODEC_NAMES: frozenset[str] = frozenset({"hevc", "h265", "h.265"})

# Duplicate signature: hash this many bytes from head and tail.
DUP_HASH_WINDOW_BYTES = 1 * 1024 * 1024  # 1 MiB
SMALL_FILE_THRESHOLD_BYTES = 2 * 1024 * 1024  # below this, hash whole file
# Volume speed probe size.
VOLUME_PROBE_BYTES = 16 * 1024 * 1024  # 16 MiB
WORST_VOLUME_SCORE = float("inf")


@dataclass(frozen=True)
class VideoInfo:
    duration: float
    video_codec: str
    audio_codec: str | None


# --- ffmpeg/ffprobe helpers --------------------------------------------------


def ensure_ffmpeg_available() -> None:
    """Install (if needed) and add bundled ffmpeg/ffprobe to PATH."""
    static_ffmpeg.add_paths()
    missing = [tool for tool in ("ffmpeg", "ffprobe") if shutil.which(tool) is None]
    if missing:
        names = ", ".join(missing)
        raise RuntimeError(
            f"Missing required tool(s): {names}. static-ffmpeg failed to provision them."
        )


def probe_video(input_path: Path) -> VideoInfo:
    """Return duration + codec info for a video file."""
    command = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration:stream=codec_type,codec_name",
        "-of",
        "json",
        str(input_path),
    ]
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() if exc.stderr else str(exc)
        raise RuntimeError(f"ffprobe failed for {input_path}: {stderr}") from exc

    payload = json.loads(result.stdout or "{}")
    streams = payload.get("streams") or []
    video_stream = next(
        (s for s in streams if s.get("codec_type") == "video"),
        None,
    )
    if video_stream is None:
        raise ValueError(f"No video stream found in {input_path}")
    audio_stream = next(
        (s for s in streams if s.get("codec_type") == "audio"),
        None,
    )

    duration_text = str((payload.get("format") or {}).get("duration", "")).strip()
    try:
        duration = float(duration_text) if duration_text else 0.0
    except ValueError:
        duration = 0.0

    return VideoInfo(
        duration=duration,
        video_codec=str(video_stream.get("codec_name", "")).lower(),
        audio_codec=(
            str(audio_stream.get("codec_name", "")).lower() if audio_stream else None
        ),
    )


def is_hevc(codec_name: str) -> bool:
    return codec_name.lower() in HEVC_CODEC_NAMES


# --- snippet probing ---------------------------------------------------------


def extract_snippet(input_path: Path, snippet_path: Path, duration: float) -> None:
    """Extract a lossless reference snippet from the middle of the input."""
    start = max(0.0, (duration - SNIPPET_DURATION_SECONDS) / 2.0)
    length = min(SNIPPET_DURATION_SECONDS, max(1.0, duration))
    command = [
        "ffmpeg",
        "-y",
        "-ss",
        f"{start:.3f}",
        "-i",
        str(input_path),
        "-t",
        f"{length:.3f}",
        "-an",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-qp",
        "0",
        "-pix_fmt",
        "yuv420p",
        str(snippet_path),
    ]
    logger.debug(f"Extracting snippet: {' '.join(command)}")
    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip() or str(exc)
        raise RuntimeError(f"snippet extraction failed: {stderr}") from exc


def encode_snippet_hevc(reference: Path, candidate: Path, crf: int) -> None:
    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(reference),
        "-an",
        "-c:v",
        "libx265",
        "-preset",
        "medium",
        "-crf",
        str(crf),
        "-tag:v",
        "hvc1",
        "-pix_fmt",
        "yuv420p",
        str(candidate),
    ]
    logger.debug(f"Encoding snippet at CRF {crf}")
    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip() or str(exc)
        raise RuntimeError(f"snippet encode (CRF {crf}) failed: {stderr}") from exc


def measure_ssim(reference: Path, candidate: Path) -> float:
    """Run ffmpeg's ssim filter and parse the overall `All:` score."""
    command = [
        "ffmpeg",
        "-i",
        str(candidate),
        "-i",
        str(reference),
        "-lavfi",
        "[0:v][1:v]ssim",
        "-f",
        "null",
        "-",
    ]
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip() or str(exc)
        raise RuntimeError(f"SSIM measurement failed: {stderr}") from exc

    stderr_text = result.stderr or ""
    # The ssim filter writes a line ending with `... All:0.xxxxxx (yy.yy)`.
    score: float | None = None
    for token in stderr_text.split():
        if token.startswith("All:"):
            try:
                score = float(token.split(":", 1)[1])
            except ValueError:
                continue
    if score is None:
        raise RuntimeError(
            "Could not parse SSIM score from ffmpeg output; "
            "the `ssim` filter may be unavailable in this build."
        )
    return score


def choose_smart_crf(input_path: Path, duration: float) -> int:
    """Probe a snippet at several CRFs and pick the highest CRF that keeps SSIM high."""
    if duration <= SHORT_VIDEO_THRESHOLD_SECONDS:
        logger.debug(
            f"Duration {duration:.1f}s <= {SHORT_VIDEO_THRESHOLD_SECONDS}s; "
            f"using default CRF {DEFAULT_SHORT_VIDEO_CRF}."
        )
        return DEFAULT_SHORT_VIDEO_CRF

    with tempfile.TemporaryDirectory(prefix="vidmp4to5_probe_") as tmp_dir:
        tmp = Path(tmp_dir)
        reference = tmp / "ref.mp4"
        extract_snippet(input_path, reference, duration)

        chosen: int | None = None
        for crf in CRF_CANDIDATES:
            candidate = tmp / f"cand_{crf}.mp4"
            try:
                encode_snippet_hevc(reference, candidate, crf)
                score = measure_ssim(reference, candidate)
            except RuntimeError as exc:
                logger.warning(f"Probe CRF {crf} failed: {exc}")
                continue
            logger.debug(f"CRF {crf} -> SSIM {score:.4f}")
            if score >= SSIM_THRESHOLD:
                chosen = crf
            else:
                break

        if chosen is None:
            chosen = CRF_CANDIDATES[0]
            logger.warning(
                f"All probe candidates fell below SSIM {SSIM_THRESHOLD}; "
                f"falling back to CRF {chosen}."
            )
        return chosen


# --- transcoding -------------------------------------------------------------


def build_output_path(input_path: Path, keep: bool) -> Path:
    """Compute final output path based on extension and keep flag."""
    stem = input_path.stem
    parent = input_path.parent
    if keep:
        if input_path.suffix.lower() == ".mp4":
            return parent / f"{stem}_hevc.mp4"
        return parent / f"{stem}.mp4"
    # Not keeping: still need a temp side-by-side path; final rename happens
    # after success. Resolved by `transcode_file`.
    if input_path.suffix.lower() == ".mp4":
        return parent / f"{stem}_hevc.mp4"
    return parent / f"{stem}.mp4"


def run_hevc_transcode(
    input_path: Path,
    output_path: Path,
    crf: int,
    audio_codec: str | None,
    verbose: bool,
) -> None:
    audio_args: list[str]
    if audio_codec == "aac":
        audio_args = ["-c:a", "copy"]
    elif audio_codec is None:
        audio_args = ["-an"]
    else:
        audio_args = ["-c:a", "aac", "-b:a", "128k"]

    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(input_path),
        "-map",
        "0:v:0",
    ]
    if audio_codec is not None:
        command.extend(["-map", "0:a:0?"])
    command.extend(
        [
            "-c:v",
            "libx265",
            "-preset",
            "medium",
            "-crf",
            str(crf),
            "-tag:v",
            "hvc1",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
        ]
    )
    command.extend(audio_args)
    command.append(str(output_path))

    if verbose:
        logger.debug(f"Running: {' '.join(command)}")

    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = (exc.stderr or "").strip() or str(exc)
        raise RuntimeError(f"HEVC transcode failed: {stderr}") from exc


def transcode_file(
    input_path: Path,
    keep: bool,
    crf_override: int | None,
    verbose: bool,
) -> tuple[str, Path | None]:
    """Process one file. Returns (status, output_path)."""
    info = probe_video(input_path)
    if is_hevc(info.video_codec):
        logger.info(f"Skipping (already HEVC): {input_path}")
        return "skipped", None

    final_path = build_output_path(input_path, keep)

    # When not keeping the original, we transcode to a temp file first to keep
    # the operation atomic — only delete and rename on success.
    if not keep and input_path.suffix.lower() == ".mp4":
        temp_path = input_path.with_name(f"{input_path.stem}.__hevc_tmp__.mp4")
    else:
        temp_path = final_path

    if temp_path.exists():
        temp_path.unlink()

    crf = (
        crf_override
        if crf_override is not None
        else choose_smart_crf(input_path, info.duration)
    )
    logger.info(f"Transcoding {input_path.name} -> {temp_path.name} (CRF {crf})")

    try:
        run_hevc_transcode(input_path, temp_path, crf, info.audio_codec, verbose)
    except Exception:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                pass
        raise

    if not keep:
        # Replace the original.
        try:
            input_path.unlink()
        except OSError as exc:
            raise RuntimeError(
                f"Could not remove original {input_path}: {exc}"
            ) from exc
        if input_path.suffix.lower() == ".mp4":
            target = input_path  # rename temp -> original .mp4 name
            temp_path.replace(target)
            final_path = target
        else:
            # temp_path == final_path already (new .mp4 stem-named file).
            final_path = temp_path

    logger.success(f"Wrote: {final_path}")
    return "transcoded", final_path


# --- folder traversal --------------------------------------------------------


def _is_excluded(path: Path) -> bool:
    """Skip CloudStorage paths (network/cloud mounts that frequently time out)."""
    return "CloudStorage" in path.parts


SCAN_PROGRESS_EVERY = 200  # log every N videos found during scan
MIN_VIDEO_SIZE_BYTES = 400 * 1024  # skip files smaller than this


def collect_videos(root: Path) -> list[Path]:
    if root.is_symlink() or _is_excluded(root):
        return []
    if root.is_file():
        if root.suffix.lower() in VIDEO_EXTENSIONS:
            return [root]
        return []
    files: list[Path] = []
    dirs_seen = 0
    last_logged = 0
    logger.info(f"Scanning {root} ...")
    # os.walk with followlinks=False skips symlinked directories; we also
    # skip symlinked files and any path containing a CloudStorage component.
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dp = Path(dirpath)
        dirs_seen += 1
        if _is_excluded(dp):
            dirnames[:] = []
            continue
        # Prune symlinked subdirs and CloudStorage subdirs in-place.
        dirnames[:] = [
            d
            for d in dirnames
            if not (dp / d).is_symlink() and d != "CloudStorage"
        ]
        for name in filenames:
            fp = dp / name
            if fp.is_symlink():
                continue
            if fp.suffix.lower() not in VIDEO_EXTENSIONS:
                continue
            try:
                st = fp.stat()
                if not fp.is_file():
                    continue
            except OSError:
                continue
            if st.st_size < MIN_VIDEO_SIZE_BYTES:
                logger.debug(f"Skipping (too small, {st.st_size}B): {fp}")
                continue
            files.append(fp)
            if len(files) - last_logged >= SCAN_PROGRESS_EVERY:
                last_logged = len(files)
                logger.info(
                    f"  ...found {len(files)} video(s) so far in {root} "
                    f"({dirs_seen} dirs scanned). Latest: {fp}"
                )
    files.sort()
    logger.info(
        f"Scanned {root}: {len(files)} video(s) in {dirs_seen} dirs."
    )
    return files


def _iter_videos(folders: list[Path]) -> list[Path]:
    """Recursively gather videos from all folders, de-duplicated by resolved path."""
    seen: set[Path] = set()
    out: list[Path] = []
    for folder in folders:
        for video in collect_videos(folder):
            try:
                resolved = video.resolve()
            except OSError:
                resolved = video.absolute()
            if resolved in seen:
                continue
            seen.add(resolved)
            out.append(resolved)
    return out


# --- volume identification + speed ranking -----------------------------------


def _volume_id(path: Path) -> tuple[int, Path]:
    """Return (st_dev, mount_path) for a path. Mount path found by walking up."""
    st_dev = os.stat(path).st_dev
    current = path if path.is_dir() else path.parent
    current = current.resolve()
    while True:
        if current.is_mount() or current == current.parent:
            return st_dev, current
        current = current.parent


def _probe_volume_speed(mount_path: Path) -> float:
    """Write+read a 16 MiB file on the volume; return total seconds. Higher = slower."""
    payload = random.randbytes(VOLUME_PROBE_BYTES)
    tmp_dir: tempfile.TemporaryDirectory[str] | None = None
    try:
        # Try volume-local temp first; fall back to mount root if needed.
        try:
            tmp_dir = tempfile.TemporaryDirectory(
                prefix=".vidmp4to5_probe_", dir=str(mount_path)
            )
            tmp_root = Path(tmp_dir.name)
        except OSError as exc:
            logger.warning(
                f"Could not create temp dir on {mount_path}: {exc}; using worst score."
            )
            return WORST_VOLUME_SCORE

        probe_file = tmp_root / "probe.bin"
        # Write + fsync.
        t0 = time.perf_counter()
        with probe_file.open("wb") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        write_seconds = time.perf_counter() - t0

        # Read back (after dropping fd, but the OS page cache may make this fast;
        # still useful as a relative metric).
        t0 = time.perf_counter()
        with probe_file.open("rb") as fh:
            while fh.read(1024 * 1024):
                pass
        read_seconds = time.perf_counter() - t0

        return write_seconds + read_seconds
    except (OSError, PermissionError) as exc:
        logger.warning(f"Volume speed probe on {mount_path} failed: {exc}")
        return WORST_VOLUME_SCORE
    finally:
        if tmp_dir is not None:
            try:
                tmp_dir.cleanup()
            except OSError:
                pass


def _rank_volumes(volumes: dict[int, Path]) -> dict[int, int]:
    """Rank volumes fastest -> slowest. Home volume forced to rank 0."""
    if not volumes:
        return {}
    home = Path.home().resolve()
    home_dev: int | None = None
    try:
        home_dev = os.stat(home).st_dev
    except OSError:
        home_dev = None

    scores: dict[int, float] = {}
    for st_dev, mount in volumes.items():
        if st_dev == home_dev:
            scores[st_dev] = -1.0  # ensure home wins regardless of probe
            logger.info(f"Volume {mount} (home) -> rank 0 (forced)")
            continue
        score = _probe_volume_speed(mount)
        scores[st_dev] = score
        logger.info(f"Volume {mount} -> probe score {score:.3f}s")

    ordered = sorted(scores.items(), key=lambda kv: kv[1])
    return {st_dev: rank for rank, (st_dev, _) in enumerate(ordered)}


# --- duplicate signature + grouping ------------------------------------------


def _dup_signature(path: Path) -> tuple[int, str]:
    """Fast content signature: (size, sha256(head_1MiB + tail_1MiB)).

    For files smaller than SMALL_FILE_THRESHOLD_BYTES, hash the whole file.
    """
    size = path.stat().st_size
    h = hashlib.sha256()
    with path.open("rb") as fh:
        if size <= SMALL_FILE_THRESHOLD_BYTES:
            while chunk := fh.read(1024 * 1024):
                h.update(chunk)
        else:
            head = fh.read(DUP_HASH_WINDOW_BYTES)
            h.update(head)
            fh.seek(max(0, size - DUP_HASH_WINDOW_BYTES))
            tail = fh.read(DUP_HASH_WINDOW_BYTES)
            h.update(tail)
    return size, h.hexdigest()


def _group_duplicates(
    paths: list[Path], vol_rank: dict[int, int]
) -> list[tuple[Path, list[Path]]]:
    """Group paths sharing a signature; primary is on fastest-ranked volume."""
    logger.info(f"Computing duplicate signatures for {len(paths)} file(s) ...")
    by_sig: dict[tuple[int, str], list[Path]] = {}
    progress = _make_progress()
    with progress:
        task_id = progress.add_task("Sign", total=len(paths))
        for i, p in enumerate(paths, 1):
            try:
                sig = _dup_signature(p)
            except OSError as exc:
                logger.warning(f"Could not signature {p}: {exc}; treating as unique.")
                sig = (-1, f"_unique_{p}")
            by_sig.setdefault(sig, []).append(p)
            progress.update(task_id, advance=1)
            if i % 100 == 0:
                logger.info(f"  signed {i}/{len(paths)}")

    groups: list[tuple[Path, list[Path]]] = []
    for members in by_sig.values():
        # Sort by volume rank ascending (fastest first); tiebreak on path string.
        def _key(member: Path) -> tuple[int, str]:
            try:
                dev = os.stat(member).st_dev
            except OSError:
                return (10**9, str(member))
            return (vol_rank.get(dev, 10**9), str(member))

        members_sorted = sorted(members, key=_key)
        primary = members_sorted[0]
        dups = members_sorted[1:]
        groups.append((primary, dups))
    return groups


# --- duplicate propagation ---------------------------------------------------


def _propagate_to_duplicate(
    converted: Path, duplicate: Path, keep: bool
) -> Literal["hardlink", "copy", "skipped"]:
    """Place `converted` next to `duplicate`. Returns the action taken."""
    target = duplicate.parent / converted.name

    if not keep:
        # Remove the original duplicate first.
        if duplicate.exists():
            try:
                duplicate.unlink()
            except OSError as exc:
                raise RuntimeError(
                    f"Could not remove duplicate {duplicate}: {exc}"
                ) from exc

    if target.exists():
        logger.warning(f"Target already exists, skipping: {target}")
        return "skipped"

    # Decide hardlink vs copy by st_dev of the destination directory.
    try:
        src_dev = os.stat(converted).st_dev
        dst_dev = os.stat(target.parent).st_dev
    except OSError as exc:
        raise RuntimeError(f"stat failed during propagate: {exc}") from exc

    if src_dev == dst_dev:
        try:
            os.link(converted, target)
            return "hardlink"
        except OSError as exc:
            logger.warning(f"Hardlink failed ({exc}); falling back to copy.")
            shutil.copy2(converted, target)
            return "copy"
    else:
        shutil.copy2(converted, target)
        return "copy"


# --- mode dispatch -----------------------------------------------------------


@dataclass
class FolderModeStats:
    groups: int = 0
    converted: int = 0
    skipped_hevc: int = 0
    failed: int = 0
    dups_hardlinked: int = 0
    dups_copied: int = 0
    dups_skipped: int = 0
    dups_failed: int = 0


def _make_progress() -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    )


# --- job queue (resumable JSON log) ------------------------------------------


def _default_log_path() -> Path:
    """Default log: alongside this script, basename + .json."""
    return Path(__file__).resolve().with_suffix(".json")


def _atomic_save_log(log_path: Path, data: dict) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = log_path.with_suffix(log_path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(log_path)


def _load_log(log_path: Path) -> dict:
    return json.loads(log_path.read_text())


def _setup_logging(verbose: bool) -> None:
    if not verbose:
        return
    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
        level="DEBUG",
    )


# --- CLI subcommands ---------------------------------------------------------


def plan(
    *paths: str,
    keep: bool = False,
    crf: int | None = None,
    log: str | None = None,
    verbose: bool = False,
) -> int:
    """Scan input paths/folders, group duplicates, and write a resumable JSON job queue."""
    _setup_logging(verbose)

    if crf is not None and not (0 <= int(crf) <= 51):
        raise ValueError("--crf must be an integer in [0, 51]")
    crf_value = int(crf) if crf is not None else None

    raw_paths = list(paths)
    if not raw_paths:
        raise ValueError("No input paths. Pass one or more files/folders positionally.")

    log_path = Path(log).expanduser() if log else _default_log_path()
    ensure_ffmpeg_available()

    targets: list[Path] = []
    for raw in raw_paths:
        t = Path(raw).expanduser()
        if not t.exists():
            logger.warning(f"Input path not found: {t}; skipping.")
            continue
        targets.append(t)

    files = [
        t for t in targets if t.is_file() and t.suffix.lower() in VIDEO_EXTENSIONS
    ]
    folders = [t for t in targets if t.is_dir()]

    videos: list[Path] = list(files)
    if folders:
        videos.extend(_iter_videos(folders))

    seen: set[Path] = set()
    unique: list[Path] = []
    for v in videos:
        try:
            r = v.resolve()
        except OSError:
            r = v.absolute()
        if r in seen:
            continue
        seen.add(r)
        unique.append(r)

    logger.info(f"Discovered {len(unique)} candidate video(s).")

    skipped_hevc = 0
    non_hevc: list[Path] = []
    logger.info(f"Probing codecs for {len(unique)} video(s) ...")
    progress = _make_progress()
    with progress:
        task_id = progress.add_task("Probe codec", total=len(unique))
        for i, v in enumerate(unique, 1):
            try:
                info = probe_video(v)
            except Exception as exc:
                logger.warning(f"Probe failed for {v}: {exc}; treating as non-HEVC.")
                non_hevc.append(v)
            else:
                if is_hevc(info.video_codec):
                    logger.debug(f"Skipping (already HEVC): {v}")
                    skipped_hevc += 1
                else:
                    non_hevc.append(v)
            progress.update(task_id, advance=1)
            if i % 50 == 0:
                logger.info(
                    f"  probed {i}/{len(unique)} (non-HEVC so far: {len(non_hevc)})"
                )
    logger.info(
        f"Codec probe done: {len(non_hevc)} to transcode, {skipped_hevc} already HEVC."
    )

    base_data: dict = {
        "version": 1,
        "inputs": [str(Path(p).expanduser()) for p in raw_paths],
        "keep": keep,
        "crf": crf_value,
        "skipped_hevc": skipped_hevc,
        "volumes": {},
        "jobs": [],
    }

    if not non_hevc:
        _atomic_save_log(log_path, base_data)
        logger.success(f"Plan written: {log_path} (0 jobs; {skipped_hevc} HEVC skipped)")
        return 0

    path_to_vol: dict[Path, tuple[int, Path]] = {}
    volumes: dict[int, Path] = {}
    for p in non_hevc:
        try:
            dev, mount = _volume_id(p)
        except OSError as exc:
            logger.warning(f"Could not stat {p}: {exc}; skipping.")
            continue
        path_to_vol[p] = (dev, mount)
        volumes.setdefault(dev, mount)

    vol_rank = _rank_volumes(volumes)
    groups = _group_duplicates(list(path_to_vol.keys()), vol_rank)
    total_dups = sum(len(d) for _, d in groups)
    logger.info(
        f"Planned {len(groups)} unique video(s), {total_dups} duplicate copies "
        f"across {len(volumes)} volume(s)."
    )

    base_data["volumes"] = {
        str(dev): {"mount": str(volumes[dev]), "rank": vol_rank.get(dev, -1)}
        for dev in volumes
    }
    base_data["jobs"] = [
        {"primary": str(primary), "duplicates": [str(d) for d in dups]}
        for primary, dups in groups
    ]
    _atomic_save_log(log_path, base_data)
    logger.success(
        f"Plan written: {log_path} ({len(base_data['jobs'])} job(s); "
        f"{skipped_hevc} HEVC skipped)"
    )
    return 0


def convert(
    log: str | None = None,
    verbose: bool = False,
) -> int:
    """Process the JSON job queue. Each completed job is removed and the log re-saved."""
    _setup_logging(verbose)

    log_path = Path(log).expanduser() if log else _default_log_path()
    if not log_path.exists():
        raise FileNotFoundError(
            f"Log not found: {log_path}. Run `plan` first."
        )
    data = _load_log(log_path)
    keep = bool(data.get("keep", False))
    crf_value = data.get("crf")
    if crf_value is not None:
        crf_value = int(crf_value)

    initial_total = len(data.get("jobs", []))
    if initial_total == 0:
        logger.info("No pending jobs.")
        return 0

    ensure_ffmpeg_available()

    stats = FolderModeStats()
    progress = _make_progress()
    with progress:
        overall_id = progress.add_task("Jobs", total=initial_total)
        while data.get("jobs"):
            job = data["jobs"][0]
            primary = Path(job["primary"])
            dups = [Path(d) for d in job.get("duplicates", [])]
            sub_total = 1 + len(dups)
            sub_id = progress.add_task(f"  {primary.name}", total=sub_total)

            converted_path: Path | None = None
            try:
                if not primary.exists():
                    logger.warning(f"Primary missing: {primary}; skipping.")
                    stats.failed += 1
                else:
                    status, converted_path = transcode_file(
                        primary, keep, crf_value, verbose
                    )
                    if status == "skipped":
                        stats.skipped_hevc += 1
                    else:
                        stats.converted += 1
            except Exception as exc:
                stats.failed += 1
                logger.error(f"Failed primary transcode for {primary}: {exc}")
                data["jobs"].pop(0)
                _atomic_save_log(log_path, data)
                progress.update(sub_id, completed=sub_total)
                progress.update(overall_id, advance=1)
                progress.remove_task(sub_id)
                stats.groups += 1
                continue

            progress.update(sub_id, advance=1)

            if converted_path is not None:
                for dup in dups:
                    try:
                        if not dup.exists():
                            logger.warning(f"Duplicate missing: {dup}; skipping.")
                            stats.dups_skipped += 1
                        else:
                            action = _propagate_to_duplicate(
                                converted_path, dup, keep
                            )
                            if action == "hardlink":
                                stats.dups_hardlinked += 1
                            elif action == "copy":
                                stats.dups_copied += 1
                            else:
                                stats.dups_skipped += 1
                            logger.info(f"Propagated to {dup.parent} via {action}")
                    except Exception as exc:
                        stats.dups_failed += 1
                        logger.error(f"Propagate failed for {dup}: {exc}")
                    finally:
                        progress.update(sub_id, advance=1)
            else:
                for _ in dups:
                    progress.update(sub_id, advance=1)

            # Remove the completed job and persist immediately so we can resume.
            data["jobs"].pop(0)
            _atomic_save_log(log_path, data)

            progress.update(overall_id, advance=1)
            progress.remove_task(sub_id)
            stats.groups += 1

    logger.info(
        "Done. groups=%d converted=%d skipped_hevc=%d failed=%d "
        "dups_hardlinked=%d dups_copied=%d dups_skipped=%d dups_failed=%d"
        % (
            stats.groups,
            stats.converted,
            stats.skipped_hevc,
            stats.failed,
            stats.dups_hardlinked,
            stats.dups_copied,
            stats.dups_skipped,
            stats.dups_failed,
        )
    )
    return 0 if (stats.failed == 0 and stats.dups_failed == 0) else 1


def _install_sigint_handler() -> None:
    def handler(_signum: int, _frame: object) -> None:  # noqa: ARG001
        del _signum, _frame
        logger.warning("Interrupted by user (SIGINT). Exiting.")
        sys.exit(130)

    signal.signal(signal.SIGINT, handler)


def main() -> int:
    _install_sigint_handler()
    try:
        result = fire.Fire({"plan": plan, "convert": convert})
    except SystemExit:
        raise
    except Exception as exc:
        logger.error(f"Error: {exc}")
        return 1
    return int(result) if isinstance(result, int) else 0


if __name__ == "__main__":
    sys.exit(main())
