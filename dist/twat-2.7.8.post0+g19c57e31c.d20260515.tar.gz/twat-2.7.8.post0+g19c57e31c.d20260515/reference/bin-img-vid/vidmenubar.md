Write `videmenubar.py`, a Fire CLI app that uses ffmpeg and other libs in an optimized way. The tool’s purpose is to cover the menubar icons in the topright corner of a macOS screen recording. 

- Takes an --input_video : path to a macOS screen recording video clip
- Optionally takes the --height : height of the menubar in pixels, default 60 because that’s the Retina height of the menubar
- Optionally takes the --width: that’s supposed to be in %, defaulting to 10
- Optionally takes an --output_video : default is the input video’s folder and basename + `_menubar.mp4`

The idea is: in the topright corner of the screen recording is the "target area" where some menubar icons are visible. The target area has the width of the "width" param expressed as % of the screen width, and has the height of the "height" param specified in pixels. 

Immediately to the left of the target area is the source area —— which is of the same width and height as the target area, but contains a clean menubar (the area between the actual menus, which are far to the left, and the icon-filled area). 

The goal of the tool is to snapshot the source area of the first frame (= a still image showing the 'blank' menubar area) and composite it over the target area of the 1st frame an of all subsequent frames. Effectively the tool will cover the icon area with a copy of the blank menubar area. 

The tool should copy the audiotrack if present and generally not degrade the input video, but also not blow it up in size. 