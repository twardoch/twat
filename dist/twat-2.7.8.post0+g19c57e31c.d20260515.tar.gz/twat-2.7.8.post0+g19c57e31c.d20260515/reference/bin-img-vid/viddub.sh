#!/usr/bin/env bash
# this_file: viddub.sh
set -euo pipefail

# Function to print usage
print_usage() {
    echo "Usage: $0 <video_path> <audio_path> [output_path]"
    echo "If output_path is not provided, it will be automatically generated."
}

# Check if correct number of arguments are provided
if [ "$#" -lt 2 ] || [ "$#" -gt 3 ]; then
    print_usage
    exit 1
fi

VIDEO_PATH="$1"
AUDIO_PATH="$2"
OUTPUT_PATH="$3"

# Extract parts from paths using parameter expansion
VIDEO_EXTENSION="${VIDEO_PATH##*.}"
AUDIO_DIR="${AUDIO_PATH%/*}"
AUDIO_FILENAME="${AUDIO_PATH##*/}"
AUDIO_BASENAME="${AUDIO_FILENAME%.*}"

# If OUTPUT_PATH is not provided, construct it
if [ -z "$OUTPUT_PATH" ]; then
    # If AUDIO_DIR is empty (i.e., no directory in path), use current directory
    [ -z "$AUDIO_DIR" ] && AUDIO_DIR="."
    mkdir -p "$AUDIO_DIR"
    OUTPUT_PATH="${AUDIO_DIR}/${AUDIO_BASENAME}.${VIDEO_EXTENSION}"
fi

# Run ffmpeg command
ffmpeg -i "$VIDEO_PATH" -i "$AUDIO_PATH" -c:v copy -map 0:v:0 -map 1:a:0 -shortest "$OUTPUT_PATH"

echo "Output saved as: $OUTPUT_PATH"
