#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "rich", "opencv-python", "numpy", "numba", "loguru"]
# ///
# this_file: vidrenmatch.py

"""
Video Rename Matcher - Rename videos based on visual similarity.

This tool analyzes videos by extracting representative frames and computing
visual similarity using optimized distance calculations. Videos in the source
directory are renamed to match the most visually similar reference videos.

Uses Numba JIT compilation for 5-20x speedup on distance computations.

Examples:
    # Rename videos in ./processed/ to match names from ./originals/
    vidrenmatch.py ./processed ./originals

    # Preview renames without applying (dry run)
    vidrenmatch.py ./processed ./originals --dry-run

    # Match exported clips to source files
    vidrenmatch.py ./exports ./source_videos

Use cases:
    - Renaming re-encoded videos to match original names
    - Matching exported clips to their source files
    - Organizing videos by visual similarity to references
    - Recovering original filenames after processing

Supported formats: .mp4, .avi, .mov, .mkv, .webm, .m4v, .flv, .wmv
"""

import shutil
from pathlib import Path

import fire
import numpy as np
import numba  # type: ignore
from rich.console import Console
from rich.progress import Progress

console = Console()

# Constants for configuration
TARGET_FRAME_SIZE = (256, 256)  # Size for frame downsampling
VIDEO_EXTENSIONS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v", ".flv", ".wmv"}


@numba.jit(nopython=True, parallel=True, cache=True)
def compute_mse_distances_numba(
    source_frames: np.ndarray, ref_frames: np.ndarray
) -> np.ndarray:
    """Compute MSE distance matrix between source and reference frames.

    Optimized with Numba JIT compilation for 5-20x speedup.
    Uses parallel processing for maximum performance.

    Args:
        source_frames: Flattened source frames array (n_source, pixels)
        ref_frames: Flattened reference frames array (n_ref, pixels)

    Returns:
        Distance matrix (n_source, n_ref) with normalized MSE values
    """
    n_source, n_pixels = source_frames.shape
    n_ref = ref_frames.shape[0]

    # Pre-allocate result matrix
    distances = np.zeros((n_source, n_ref), dtype=np.float32)

    # Parallel computation across source frames
    for i in numba.prange(n_source):
        for j in range(n_ref):
            # Compute squared differences and mean
            diff_sum = 0.0
            for k in range(n_pixels):
                diff = source_frames[i, k] - ref_frames[j, k]
                diff_sum += diff * diff

            # Normalize by number of pixels
            distances[i, j] = diff_sum / n_pixels

    return distances


@numba.jit(nopython=True, cache=True)
def find_best_matches_numba(distance_matrix: np.ndarray) -> np.ndarray:
    """Find index of minimum distance for each source video.

    Args:
        distance_matrix: Distance matrix (n_source, n_ref)

    Returns:
        Array of best match indices for each source video
    """
    n_source = distance_matrix.shape[0]
    matches = np.zeros(n_source, dtype=np.int32)

    for i in range(n_source):
        min_idx = 0
        min_val = distance_matrix[i, 0]

        for j in range(1, distance_matrix.shape[1]):
            if distance_matrix[i, j] < min_val:
                min_val = distance_matrix[i, j]
                min_idx = j

        matches[i] = min_idx

    return matches


def extract_representative_frame(
    video_path: Path,
    target_size: tuple[int, int] = TARGET_FRAME_SIZE,
) -> tuple[np.ndarray, int, int]:
    """Extract and downsample a representative frame from video.

    Extracts the middle frame as it's most likely to contain stable content
    rather than opening/closing credits or transitions.

    Args:
        video_path: Path to the video file
        target_size: Desired (width, height) for downsampling

    Returns:
        Tuple of (normalized frame array, actual width, actual height)

    Raises:
        ValueError: If video cannot be opened or read
    """
    import cv2  # Import here to avoid linter warnings at module level

    try:
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            msg = f"Cannot open video: {video_path}"
            raise ValueError(msg)

        # Get total frames and seek to middle for representative sample
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if total_frames == 0:
            msg = f"Video has no frames: {video_path}"
            raise ValueError(msg)

        # Seek to middle frame for most stable content
        middle_frame = total_frames // 2
        cap.set(cv2.CAP_PROP_POS_FRAMES, middle_frame)

        ret, frame = cap.read()
        cap.release()

        if not ret:
            msg = f"Cannot read frame from video: {video_path}"
            raise ValueError(msg)

        # Convert BGR to RGB and resize with high-quality interpolation
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        width, height = target_size
        frame_resized = cv2.resize(
            frame_rgb, (width, height), interpolation=cv2.INTER_LANCZOS4
        )

        # Normalize to float32 for consistent computation
        return frame_resized.astype(np.float32), width, height

    except Exception as e:
        console.print(f"[red]Error processing {video_path}: {e!s}[/red]")
        raise


def get_video_files(directory: Path) -> list[Path]:
    """Get all supported video files from a directory.

    Args:
        directory: Directory to scan for video files

    Returns:
        Sorted list of video file paths
    """
    return sorted(
        p
        for p in directory.iterdir()
        if p.is_file() and p.suffix.lower() in VIDEO_EXTENSIONS
    )


def load_videos_from_dir(
    directory: Path, target_size: tuple[int, int], label: str
) -> tuple[list[np.ndarray], list[Path]]:
    """Load and extract representative frames from videos in directory.

    Processes all video files and extracts representative frames for comparison.
    Shows progress bar and handles errors gracefully by skipping invalid files.

    Args:
        directory: Directory containing videos
        target_size: Size to which each frame is downsampled
        label: Descriptive label for progress display

    Returns:
        Tuple of (list of frame arrays, list of corresponding file paths)
    """
    files = get_video_files(directory)
    frames = []
    valid_paths = []

    with Progress() as progress:
        task = progress.add_task(f"Loading {label}...", total=len(files))
        for path in files:
            try:
                frame, _, _ = extract_representative_frame(path, target_size)
                frames.append(frame)
                valid_paths.append(path)
            except Exception:
                console.print(f"[yellow]Skipping invalid video: {path.name}[/yellow]")
            progress.advance(task)

    return frames, valid_paths


def compute_distance_matrix_optimized(
    source_frames: list[np.ndarray], ref_frames: list[np.ndarray]
) -> np.ndarray:
    """Compute optimized distance matrix between source and reference frames.

    Uses Numba JIT compilation for 5-20x speedup over pure NumPy.
    Flattens frames for efficient parallel processing.

    Args:
        source_frames: List of source video frame arrays
        ref_frames: List of reference video frame arrays

    Returns:
        2D array where each row is a source video, each column a reference
    """
    if not source_frames or not ref_frames:
        return np.array([])

    # Stack and flatten frames for efficient computation
    source_stack = np.stack(source_frames)  # (n_source, h, w, c)
    ref_stack = np.stack(ref_frames)  # (n_ref, h, w, c)

    # Flatten to (n_videos, n_pixels) for distance computation
    source_flat = source_stack.reshape(source_stack.shape[0], -1)
    ref_flat = ref_stack.reshape(ref_stack.shape[0], -1)

    # Use Numba-optimized distance computation
    return compute_mse_distances_numba(source_flat, ref_flat)


def find_closest_matches_optimized(distance_matrix: np.ndarray) -> list[int]:
    """Find closest reference video for each source video using Numba.

    Args:
        distance_matrix: Computed distance matrix

    Returns:
        List of indices corresponding to closest reference video
        for each source video
    """
    if distance_matrix.size == 0:
        return []

    # Use Numba-optimized matching
    matches_array = find_best_matches_numba(distance_matrix)
    return matches_array.tolist()


def generate_rename_mapping(
    source_paths: list[Path], ref_paths: list[Path], matches: list[int]
) -> list[tuple[Path, Path]]:
    """Generate mapping from source videos to new names based on matches.

    Handles naming conflicts by appending numerical suffixes to duplicates.
    Preserves original file extensions.

    Args:
        source_paths: List of source video paths
        ref_paths: List of reference video paths
        matches: List of indices indicating best matching reference
                for each source video

    Returns:
        List of tuples (original_path, new_path)
    """
    mapping = []
    used_names: dict[str, int] = {}

    for i, ref_idx in enumerate(matches):
        src_path = source_paths[i]
        base_name = ref_paths[ref_idx].stem
        candidate = f"{base_name}{src_path.suffix}"

        # Handle naming conflicts with numerical suffixes
        if candidate in used_names:
            used_names[candidate] += 1
            candidate = f"{base_name}_{used_names[candidate]}{src_path.suffix}"
        else:
            used_names[candidate] = 0

        new_path = src_path.parent / candidate
        mapping.append((src_path, new_path))

    return mapping


def rename_files(mapping: list[tuple[Path, Path]], dry_run: bool) -> None:
    """Rename files according to mapping or display planned changes.

    Args:
        mapping: List of (original_path, new_path) tuples
        dry_run: If True, only display planned renames without changes
    """
    if dry_run:
        console.print("\n[bold]Dry run - no files will be renamed[/bold]")
        console.print("[bold]Planned renames:[/bold]")
        for old, new in mapping:
            console.print(f"{old.name} -> {new.name}")
    else:
        console.print("\nRenaming files...")
        with Progress() as progress:
            task = progress.add_task("Renaming...", total=len(mapping))
            for old, new in mapping:
                if new.exists() and old != new:
                    console.print(
                        f"[yellow]Skipping {old.name} -> {new.name} "
                        f"(target exists)[/yellow]"
                    )
                else:
                    shutil.move(str(old), str(new))
                progress.advance(task)
        console.print("[green]Successfully renamed all files![/green]")


def cli(input_dir: str | Path, ref_dir: str | Path, dry_run: bool = False) -> None:
    """Rename videos in input_dir based on closest visual match from ref_dir.

    This tool analyzes representative frames from videos and uses optimized
    distance calculations to find the most visually similar matches.
    Uses Numba JIT compilation for 5-20x performance improvement.

    Args:
        input_dir: Directory containing videos to be renamed
        ref_dir: Directory containing reference videos for naming
        dry_run: If True, only display planned renames without applying
    """
    source_dir = Path(input_dir)
    reference_dir = Path(ref_dir)

    # Validate input directories
    if not source_dir.exists():
        console.print("[red]Error: Source directory does not exist[/red]")
        return
    if not reference_dir.exists():
        console.print("[red]Error: Reference directory does not exist[/red]")
        return

    # Load video frames from both directories
    console.print("[blue]Loading and analyzing videos...[/blue]")
    src_frames, src_paths = load_videos_from_dir(
        source_dir, TARGET_FRAME_SIZE, "source videos"
    )
    ref_frames, ref_paths = load_videos_from_dir(
        reference_dir, TARGET_FRAME_SIZE, "reference videos"
    )

    # Validate we have videos to process
    if not src_frames:
        console.print("[yellow]No valid source videos found[/yellow]")
        return
    if not ref_frames:
        console.print("[yellow]No valid reference videos found[/yellow]")
        return

    # Process matches using optimized algorithms
    console.print(
        f"[blue]Computing similarities for {len(src_frames)} source videos "
        f"and {len(ref_frames)} reference videos...[/blue]"
    )

    distance_matrix = compute_distance_matrix_optimized(src_frames, ref_frames)
    matches = find_closest_matches_optimized(distance_matrix)
    mapping = generate_rename_mapping(src_paths, ref_paths, matches)

    # Apply or preview the renames
    rename_files(mapping, dry_run)


if __name__ == "__main__":
    fire.Fire(cli)
