# vidrenmatch.py

A command-line tool for renaming videos based on visual similarity. This tool extracts representative frames from videos and renames source videos to match the most visually similar reference videos.

## Features

- **Visual Similarity Matching**: Extracts middle frames from videos and compares them using MSE distance
- **Batch Processing**: Processes entire directories of videos efficiently
- **Dry Run Mode**: Preview rename operations without making changes
- **Progress Tracking**: Rich progress bars and status updates
- **Error Handling**: Graceful handling of invalid or corrupted video files
- **Wide Format Support**: Supports MP4, AVI, MOV, MKV, WebM, M4V, FLV, WMV formats

## Installation

The script uses `uv` for dependency management. Simply run it directly:

```bash
python vidrenmatch.py --help
```

## Usage

### Basic Usage

```bash
# Rename videos in source_dir based on visual matches from reference_dir
python vidrenmatch.py source_videos/ reference_videos/

# Dry run to preview changes without renaming
python vidrenmatch.py source_videos/ reference_videos/ --dry_run
```

### Example Workflow

1. **Prepare directories**: Place videos to be renamed in one directory, and reference videos (with desired names) in another
2. **Preview changes**: Run with `--dry_run` to see planned renames
3. **Execute renames**: Run without `--dry_run` to apply changes

```bash
# Step 1: Preview what will be renamed
python vidrenmatch.py ./to_rename/ ./references/ --dry_run

# Step 2: Apply the renames
python vidrenmatch.py ./to_rename/ ./references/
```

## How It Works

1. **Frame Extraction**: Extracts the middle frame from each video for comparison
2. **Preprocessing**: Resizes frames to 256x256 and converts to RGB for consistent comparison
3. **Distance Calculation**: Computes MSE (Mean Squared Error) distance matrix between all source and reference frames
4. **Matching**: Finds the closest visual match for each source video
5. **Renaming**: Generates new filenames based on reference video names, handling conflicts with numerical suffixes

## Algorithm Details

- **Representative Frame**: Uses the middle frame (50% position) of each video as most representative content
- **Similarity Metric**: MSE distance between flattened pixel arrays after normalization
- **Conflict Resolution**: Appends `_1`, `_2`, etc. when multiple source videos match the same reference
- **Format Preservation**: Maintains original file extensions during renaming

## Performance

- **Frame Processing**: ~256x256 downsampling for fast comparison while preserving visual structure
- **Memory Efficient**: Processes videos sequentially with minimal memory footprint
- **Vectorized Operations**: Uses NumPy for efficient distance matrix computation

## Requirements

- Python 3.10+
- OpenCV (cv2)
- NumPy
- Rich (for progress bars)
- Fire (for CLI)

## Example Output

```
Loading source videos... ████████████████████████████████████████ 100% 0:00:02
Loading reference videos... ████████████████████████████████████████ 100% 0:00:01
Processing 5 source videos and 3 reference videos...

Dry run - no files will be renamed
Planned renames:
video1.mp4 -> reference_a.mp4
video2.mp4 -> reference_b.mp4
video3.mp4 -> reference_a_1.mp4
video4.mp4 -> reference_c.mp4
video5.mp4 -> reference_b_1.mp4
```

## Related Tools

This tool is inspired by `imgrenmatch` but adapted for video content, extracting representative frames for comparison rather than comparing images directly. 