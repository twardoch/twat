#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["pedalboard", "fire", "rich", "numpy", "ffmpeg-python", "loguru", "soundfile"]
# ///
# this_file: vidreverb.py
"""
VidReverb - Add room reverb to the audio of MP4 video clips

This tool extracts audio from a video file, applies reverb effects using
the pedalboard library, and then merges the processed audio back with
the original video.
"""

import tempfile
from pathlib import Path
from typing import Literal

import fire
import ffmpeg
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

try:
    # Import directly from _pedalboard to avoid linter issues
    from pedalboard._pedalboard import Pedalboard
    from pedalboard import Reverb
    from pedalboard.io import AudioFile

    PEDALBOARD_AVAILABLE = True
except ImportError:
    PEDALBOARD_AVAILABLE = False
    print("WARNING: pedalboard not available. Will use soundfile instead.")
    import soundfile as sf

    # Create dummy classes to prevent unbound errors
    class Pedalboard:
        def __init__(self, plugins):
            self.plugins = plugins

        def __call__(self, audio, sample_rate):
            return audio

    class Reverb:
        def __init__(
            self,
            room_size=0.5,
            damping=0.5,
            wet_level=0.33,
            dry_level=0.4,
            width=1.0,
            freeze_mode=0.0,
        ):
            self.room_size = room_size
            self.damping = damping
            self.wet_level = wet_level
            self.dry_level = dry_level
            self.width = width
            self.freeze_mode = freeze_mode


from loguru import logger
import numpy as np
import shutil

console = Console()


def setup_logger(verbose: bool = False) -> None:
    """
    Configure loguru logger with appropriate verbosity level.

    Args:
        verbose: Whether to use DEBUG level logging instead of INFO
    """
    logger.remove()
    log_level = "DEBUG" if verbose else "INFO"
    logger.add(lambda msg: console.print(f"[bold blue]LOG:[/] {msg}"), level=log_level)


def extract_audio(
    video_path: Path, temp_audio_path: Path, verbose: bool = False
) -> tuple[int, int]:
    """
    Extract audio from video file using ffmpeg.

    Args:
        video_path: Path to the input video file
        temp_audio_path: Path where the extracted audio will be saved
        verbose: Whether to print verbose output

    Returns:
        Tuple of (sample_rate, num_channels)

    Raises:
        ValueError: If no audio stream is found in the video
        ffmpeg.Error: If ffmpeg encounters an error during extraction
    """
    logger.debug(f"Extracting audio from {video_path} to {temp_audio_path}")

    try:
        # Extract audio with ffmpeg and get info
        probe = ffmpeg.probe(str(video_path))
        audio_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "audio"),
            None,
        )

        if not audio_stream:
            raise ValueError(f"No audio stream found in {video_path}")

        # Get sample rate from the audio stream
        sample_rate = int(audio_stream.get("sample_rate", 44100))
        channels = int(audio_stream.get("channels", 2))

        logger.debug(f"Audio info: {sample_rate}Hz, {channels} channels")

        # Extract audio to temporary WAV file
        (
            ffmpeg.input(str(video_path))
            .output(
                str(temp_audio_path), acodec="pcm_s16le", ar=sample_rate, ac=channels
            )
            .global_args("-loglevel", "error" if not verbose else "info")
            .overwrite_output()
            .run()
        )

        return sample_rate, channels

    except ffmpeg.Error as e:
        logger.error(
            f"Error extracting audio: {e.stderr.decode() if e.stderr else str(e)}"
        )
        raise
    except Exception as e:
        logger.error(f"Unexpected error during audio extraction: {str(e)}")
        raise


def direct_apply_reverb(
    audio_path: Path,
    output_path: Path,
    room_size: float = 0.5,
    damping: float = 0.5,
    wet_level: float = 0.33,
    dry_level: float = 0.4,
    width: float = 1.0,
    freeze_mode: float = 0.0,
    delay_ms: int = 0,
    verbose: bool = False,
) -> None:
    """
    Apply reverb using soundfile instead of pedalboard, for systems where pedalboard isn't working.
    Uses a simple convolution-based approach.
    """
    logger.info("Using soundfile-based processing (fallback mode)")

    # For simplicity, we'll use a simple impulse response approach
    # This is much simpler than pedalboard but can create basic reverb

    try:
        # Read input file
        logger.debug(f"Reading audio file: {audio_path}")
        audio_data, sample_rate = sf.read(str(audio_path))
        logger.debug(f"Audio shape: {audio_data.shape}, sample rate: {sample_rate}")

        # Create simple impulse response
        ir_length = int(sample_rate * (room_size * 2))  # Room size determines IR length
        ir = np.zeros(ir_length)

        # Early reflections
        early_reflection_count = 5
        for i in range(early_reflection_count):
            pos = int(sample_rate * 0.05 * (i + 1))
            if pos < ir_length:
                ir[pos] = 0.7 * (1 - damping) * (1 - (i / early_reflection_count))

        # Late reverb
        decay = np.exp(
            -np.arange(ir_length) / (sample_rate * room_size * (1 - damping) * 0.5)
        )
        noise = np.random.rand(ir_length) * 0.1
        late_reverb = noise * decay

        # Combine
        ir += late_reverb
        ir = ir / np.max(np.abs(ir))  # Normalize

        logger.debug(f"Created impulse response of length {ir_length} samples")

        # Apply delay if needed
        if delay_ms != 0:
            delay_samples = int(abs(delay_ms) * sample_rate / 1000)
            logger.debug(f"Applying delay of {delay_ms}ms = {delay_samples} samples")

            # Implement true audio delay
            if len(audio_data.shape) > 1:  # Multi-channel
                audio_data.shape[1]
                orig_len = audio_data.shape[0]

                # Create new buffer of same size as original
                buffer = np.zeros_like(audio_data)

                if delay_ms > 0:
                    # Positive delay - audio plays LATER
                    # Add silence at beginning, cut from end
                    if delay_samples < orig_len:
                        # Copy audio, but shifted later
                        buffer[delay_samples:, :] = audio_data[:-delay_samples, :]
                    else:
                        # If delay is longer than audio, just silence
                        pass  # buffer is already zeros
                else:
                    # Negative delay - audio plays EARLIER
                    # Cut from beginning, add silence at end
                    if delay_samples < orig_len:
                        # Copy audio, but shifted earlier
                        buffer[:-delay_samples, :] = audio_data[delay_samples:, :]
                    else:
                        # If delay is longer than audio, just silence
                        pass  # buffer is already zeros

                audio_data = buffer
            else:  # Mono audio
                orig_len = len(audio_data)
                buffer = np.zeros_like(audio_data)

                if delay_ms > 0:
                    # Positive delay - audio plays LATER
                    # Add silence at beginning, cut from end
                    if delay_samples < orig_len:
                        buffer[delay_samples:] = audio_data[:-delay_samples]
                    else:
                        pass  # buffer is already zeros
                else:
                    # Negative delay - audio plays EARLIER
                    # Cut from beginning, add silence at end
                    if delay_samples < orig_len:
                        buffer[:-delay_samples] = audio_data[delay_samples:]
                    else:
                        pass  # buffer is already zeros

                audio_data = buffer

            # Add debug info
            if delay_ms > 0:
                logger.debug(
                    f"Delayed audio by adding {delay_samples} samples of silence at start"
                )
            else:
                logger.debug(
                    f"Advanced audio by removing {delay_samples} samples from start"
                )

        # Create wet signal through convolution
        import scipy.signal

        # Ensure multi-channel convolution if needed
        if len(audio_data.shape) > 1 and audio_data.shape[1] > 1:
            # Stereo processing
            wet_signal = np.zeros_like(audio_data)
            for ch in range(audio_data.shape[1]):
                wet_ch = scipy.signal.fftconvolve(audio_data[:, ch], ir, mode="same")
                wet_signal[:, ch] = wet_ch
        else:
            # Mono processing
            wet_signal = scipy.signal.fftconvolve(audio_data, ir, mode="same")

        # Mix dry and wet
        processed = (audio_data * dry_level) + (wet_signal * wet_level)

        # Ensure we're not clipping or amplifying overall
        if wet_level > 0:
            # Only normalize if we're actually adding reverb
            max_val = np.max(np.abs(processed))
            if max_val > 0.99:
                processed = processed / max_val * 0.99
                logger.debug("Applied gain reduction to avoid clipping")

            # Adjust volume to match original level more closely
            orig_rms = np.sqrt(np.mean(np.square(audio_data)))
            proc_rms = np.sqrt(np.mean(np.square(processed)))

            if proc_rms > orig_rms * 1.1:  # Allow only 10% volume increase
                gain_adjust = orig_rms / proc_rms
                processed = processed * gain_adjust
                logger.debug(
                    f"Applied gain adjustment factor of {gain_adjust:.4f} to match original volume"
                )
        else:
            # For delay-only mode, preserve the original volume exactly
            orig_rms = np.sqrt(np.mean(np.square(audio_data)))
            proc_rms = np.sqrt(np.mean(np.square(processed)))

            if (
                abs(proc_rms / orig_rms - 1.0) > 0.05
            ):  # If volume differs by more than 5%
                gain_adjust = orig_rms / proc_rms
                processed = processed * gain_adjust
                logger.debug(
                    f"Applied gain adjustment factor of {gain_adjust:.4f} to preserve original volume in delay-only mode"
                )

        # Diagnostic output
        logger.debug(
            f"Original min/max: {np.min(audio_data):.4f}/{np.max(audio_data):.4f}"
        )
        logger.debug(
            f"Processed min/max: {np.min(processed):.4f}/{np.max(processed):.4f}"
        )
        logger.debug(
            f"Average abs difference: {np.mean(np.abs(audio_data - processed)):.4f}"
        )

        # Write processed audio
        logger.debug(f"Writing processed audio to {output_path}")
        sf.write(str(output_path), processed, sample_rate)

        logger.debug("Reverb applied successfully")

    except Exception as e:
        logger.error(f"Error applying reverb with soundfile: {e}")
        # Copy original as fallback
        shutil.copy(audio_path, output_path)
        logger.warning("Falling back to original audio due to processing error")


def apply_reverb(
    audio_path: Path,
    output_path: Path,
    room_size: float = 0.5,
    damping: float = 0.5,
    wet_level: float = 0.33,
    dry_level: float = 0.4,
    width: float = 1.0,
    freeze_mode: float = 0.0,
    delay_ms: int = 0,
    verbose: bool = False,
) -> None:
    """
    Apply reverb effect to audio file using pedalboard.

    Args:
        audio_path: Path to the input audio file
        output_path: Path where the processed audio will be saved
        room_size: Size of the simulated room (0.0 to 1.0)
        damping: Amount of high frequency damping (0.0 to 1.0)
        wet_level: Level of reverb effect (0.0 to 1.0)
        dry_level: Level of original signal (0.0 to 1.0)
        width: Stereo width of the reverb (0.0 to 1.0)
        freeze_mode: Freeze mode level (0.0 to 1.0)
        delay_ms: Milliseconds to delay the audio (positive = shift later, negative = shift earlier)
        verbose: Whether to print verbose output

    Raises:
        ValueError: If parameters are outside valid range
        Exception: For other errors during processing
    """
    # Validate parameters
    for param_name, param_value in [
        ("room_size", room_size),
        ("damping", damping),
        ("wet_level", wet_level),
        ("dry_level", dry_level),
        ("width", width),
        ("freeze_mode", freeze_mode),
    ]:
        if not 0.0 <= param_value <= 1.0:
            raise ValueError(
                f"Parameter '{param_name}' must be between 0.0 and 1.0, got {param_value}"
            )

    logger.debug(
        f"Applying reverb to {audio_path} with room_size={room_size}, wet={wet_level}, dry={dry_level}"
    )

    if delay_ms != 0:
        logger.info(f"Audio will be delayed by {delay_ms} ms")

    # If pedalboard isn't available, use our direct implementation
    if not PEDALBOARD_AVAILABLE:
        direct_apply_reverb(
            audio_path,
            output_path,
            room_size=room_size,
            damping=damping,
            wet_level=wet_level,
            dry_level=dry_level,
            width=width,
            freeze_mode=freeze_mode,
            delay_ms=delay_ms,
            verbose=verbose,
        )
        return

    try:
        # Create direct dump of original file for debugging
        temp_debug_dir = Path("/tmp/vidreverb_debug")
        temp_debug_dir.mkdir(exist_ok=True)
        debug_orig_copy = temp_debug_dir / "original.wav"
        debug_output_copy = temp_debug_dir / "processed.wav"

        # Copy original file for debugging
        try:
            shutil.copy(audio_path, debug_orig_copy)
            logger.debug(f"Debug: Copied original to {debug_orig_copy}")
        except Exception as e:
            logger.debug(f"Debug: Failed to copy debug file: {e}")

        # Create reverb effect
        logger.debug("Creating reverb effect with parameters:")
        for name, value in [
            ("room_size", room_size),
            ("damping", damping),
            ("wet_level", wet_level),
            ("dry_level", dry_level),
            ("width", width),
            ("freeze_mode", freeze_mode),
        ]:
            logger.debug(f"  {name}: {value}")

        reverb = Reverb(
            room_size=room_size,
            damping=damping,
            wet_level=wet_level,
            dry_level=dry_level,
            width=width,
            freeze_mode=freeze_mode,
        )

        # Load audio with soundfile to get a reliable copy
        import soundfile as sf

        original_audio, sample_rate = sf.read(str(audio_path))
        logger.debug(
            f"Read audio with soundfile: shape={original_audio.shape}, sr={sample_rate}"
        )

        # Handle delay first if requested
        if delay_ms != 0:
            delay_samples = int(abs(delay_ms) * sample_rate / 1000)
            logger.debug(f"Applying delay of {delay_ms}ms = {delay_samples} samples")

            # Implement true audio delay
            if len(original_audio.shape) > 1:  # Multi-channel
                original_audio.shape[1]
                orig_len = original_audio.shape[0]

                # Create new buffer of same size as original
                buffer = np.zeros_like(original_audio)

                if delay_ms > 0:
                    # Positive delay - audio plays LATER
                    # Add silence at beginning, cut from end
                    if delay_samples < orig_len:
                        # Copy audio, but shifted later
                        buffer[delay_samples:, :] = original_audio[:-delay_samples, :]
                    else:
                        # If delay is longer than audio, just silence
                        pass  # buffer is already zeros
                else:
                    # Negative delay - audio plays EARLIER
                    # Cut from beginning, add silence at end
                    if delay_samples < orig_len:
                        # Copy audio, but shifted earlier
                        buffer[:-delay_samples, :] = original_audio[delay_samples:, :]
                    else:
                        # If delay is longer than audio, just silence
                        pass  # buffer is already zeros

                original_audio = buffer
            else:  # Mono audio
                orig_len = len(original_audio)
                buffer = np.zeros_like(original_audio)

                if delay_ms > 0:
                    # Positive delay - audio plays LATER
                    # Add silence at beginning, cut from end
                    if delay_samples < orig_len:
                        buffer[delay_samples:] = original_audio[:-delay_samples]
                    else:
                        pass  # buffer is already zeros
                else:
                    # Negative delay - audio plays EARLIER
                    # Cut from beginning, add silence at end
                    if delay_samples < orig_len:
                        buffer[:-delay_samples] = original_audio[delay_samples:]
                    else:
                        pass  # buffer is already zeros

                original_audio = buffer

            # Add debug info
            if delay_ms > 0:
                logger.debug(
                    f"Delayed audio by adding {delay_samples} samples of silence at start"
                )
            else:
                logger.debug(
                    f"Advanced audio by removing {delay_samples} samples from start"
                )

        # Now use pedalboard to apply reverb
        try:
            # Create the pedalboard and process directly
            board = Pedalboard([reverb])
            logger.debug(f"Processing audio with Pedalboard: {board}")

            # Process audio directly using pedalboard's processor
            processed_audio = board(original_audio, sample_rate)

            # Check if processing made a difference
            abs_diff = np.abs(original_audio - processed_audio)
            avg_diff = np.mean(abs_diff)

            # Show diagnostics
            logger.info(f"Average difference after processing: {avg_diff:.6f}")
            logger.info(
                f"Original range: {np.min(original_audio):.4f} to {np.max(original_audio):.4f}"
            )
            logger.info(
                f"Processed range: {np.min(processed_audio):.4f} to {np.max(processed_audio):.4f}"
            )

            if avg_diff < 0.0001:
                logger.warning(
                    "WARNING: Very little change in audio! Reverb might not be working correctly."
                )

                # Try processing manually by creating wet signal and mixing
                logger.debug("Trying direct manual processing...")

                # Create wet signal (only reverb)
                wet_reverb = Reverb(
                    room_size=room_size,
                    damping=damping,
                    wet_level=1.0,  # Full wet
                    dry_level=0.0,  # No dry
                    width=width,
                    freeze_mode=freeze_mode,
                )
                wet_board = Pedalboard([wet_reverb])
                wet_signal = wet_board(original_audio, sample_rate)

                # Mix manually
                processed_audio = (original_audio * dry_level) + (
                    wet_signal * wet_level
                )

                # Check difference again
                new_diff = np.mean(np.abs(original_audio - processed_audio))
                logger.info(f"After manual mixing, difference: {new_diff:.6f}")

            # Adjust volume to match original level more closely when wet level is significant
            if wet_level > 0:
                orig_rms = np.sqrt(np.mean(np.square(original_audio)))
                proc_rms = np.sqrt(np.mean(np.square(processed_audio)))

                if proc_rms > orig_rms * 1.1:  # Allow only 10% volume increase
                    gain_adjust = orig_rms / proc_rms
                    processed_audio = processed_audio * gain_adjust
                    logger.debug(
                        f"Applied gain adjustment factor of {gain_adjust:.4f} to match original volume"
                    )
            else:
                # For delay-only mode, preserve the original volume exactly
                orig_rms = np.sqrt(np.mean(np.square(original_audio)))
                proc_rms = np.sqrt(np.mean(np.square(processed_audio)))

                if (
                    abs(proc_rms / orig_rms - 1.0) > 0.05
                ):  # If volume differs by more than 5%
                    gain_adjust = orig_rms / proc_rms
                    processed_audio = processed_audio * gain_adjust
                    logger.debug(
                        f"Applied gain adjustment factor of {gain_adjust:.4f} to preserve original volume in delay-only mode"
                    )

            # Write the processed audio
            logger.debug(f"Writing processed audio to {output_path}")
            sf.write(str(output_path), processed_audio, sample_rate)

            # Also save debug copy
            sf.write(str(debug_output_copy), processed_audio, sample_rate)
            logger.debug(f"Saved debug processed audio to {debug_output_copy}")

        except Exception as e:
            logger.error(f"Error processing with pedalboard: {e}")
            logger.warning("Falling back to direct implementation")

            # Use the direct implementation as fallback
            direct_apply_reverb(
                audio_path,
                output_path,
                room_size=room_size,
                damping=damping,
                wet_level=wet_level,
                dry_level=dry_level,
                width=width,
                freeze_mode=freeze_mode,
                delay_ms=delay_ms,
                verbose=verbose,
            )

        logger.debug(f"Reverb applied successfully, saved to {output_path}")

    except Exception as e:
        logger.error(f"Error applying reverb: {str(e)}")
        # Final fallback - just copy the file
        try:
            shutil.copy(audio_path, output_path)
            logger.warning("Reverb failed completely, copying original audio")
        except:
            logger.error("Even copying failed. Cannot proceed.")
            raise


def merge_audio_with_video(
    video_path: Path,
    audio_path: Path,
    output_path: Path,
    audio_bitrate: str = "192k",
    verbose: bool = False,
) -> None:
    """
    Merge processed audio with original video using ffmpeg.

    Args:
        video_path: Path to the original video file
        audio_path: Path to the processed audio file
        output_path: Path where the final video will be saved
        audio_bitrate: Bitrate for the output audio (e.g. '128k', '192k', '256k')
        verbose: Whether to print verbose output

    Raises:
        ffmpeg.Error: If ffmpeg encounters an error during merging
        Exception: For other unexpected errors
    """
    logger.debug(
        f"Merging processed audio with video to {output_path} (audio bitrate: {audio_bitrate})"
    )

    try:
        # Check if output file already exists and warn
        if output_path.exists():
            logger.warning(
                f"Output file already exists and will be overwritten: {output_path}"
            )

        # Verify that audio file is valid and not empty
        try:
            import soundfile as sf

            audio_data, sr = sf.read(str(audio_path))
            logger.debug(
                f"Audio file for merging: {audio_path}, shape={audio_data.shape}, sr={sr}"
            )
            logger.debug(
                f"Audio range: min={audio_data.min():.4f}, max={audio_data.max():.4f}"
            )
        except Exception as e:
            logger.error(f"Error checking audio file: {e}")

        # Use direct ffmpeg command for full control
        cmd = [
            "ffmpeg",
            "-y",  # Overwrite output without asking
            "-i",
            str(video_path),  # Input video
            "-i",
            str(audio_path),  # Input audio
            "-c:v",
            "copy",  # Copy video stream unchanged
            "-c:a",
            "aac",  # AAC audio codec
            "-b:a",
            audio_bitrate,  # Audio bitrate
            "-map",
            "0:v:0",  # Take video from first input
            "-map",
            "1:a:0",  # Take audio from second input
            "-shortest",  # End when shortest input ends
            "-loglevel",
            "info" if verbose else "error",
            str(output_path),
        ]

        # Run ffmpeg command directly
        import subprocess

        logger.debug(f"Running ffmpeg command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr}")
            raise RuntimeError(f"FFmpeg failed with code {result.returncode}")

        # Verify the output file exists and has reasonable size
        if not output_path.exists():
            raise FileNotFoundError(f"Output file not created: {output_path}")

        output_size = output_path.stat().st_size
        if output_size < 1000:  # Arbitrary small size check
            raise ValueError(f"Output file suspiciously small ({output_size} bytes)")

        logger.debug(
            f"Merge completed successfully, output size: {output_size / 1024 / 1024:.2f} MB"
        )

    except ffmpeg.Error as e:
        logger.error(
            f"Error merging audio with video: {e.stderr.decode() if e.stderr else str(e)}"
        )
        raise
    except Exception as e:
        logger.error(f"Unexpected error during merging: {str(e)}")
        raise


def verify_audio_change(
    input_path: Path,
    output_path: Path,
    verbose: bool = False,
) -> tuple[float, float]:
    """
    Verify that the processed audio actually differs from the original.

    This extracts the audio from both the original and processed video files,
    then compares them to measure how much the audio changed.

    Args:
        input_path: Path to the original video file
        output_path: Path to the processed video file
        verbose: Whether to print verbose output

    Returns:
        Tuple of (difference_score, ratio) where:
        - difference_score: Average absolute difference between original and processed audio
        - ratio: Ratio of processed vs original RMS (volume)

    Raises:
        Exception: If there's an error extracting or comparing the audio
    """
    logger.debug(f"Verifying audio changes between {input_path} and {output_path}")

    # Make sure numpy is available at the module level for both paths
    import numpy as np

    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            # Extract audio from both files
            original_audio = Path(temp_dir) / "original_audio.wav"
            processed_audio = Path(temp_dir) / "processed_audio.wav"

            # Extract audio from original video
            logger.debug(f"Extracting audio from original video: {input_path}")
            (
                ffmpeg.input(str(input_path))
                .output(str(original_audio), acodec="pcm_s16le")
                .global_args("-loglevel", "error" if not verbose else "info")
                .overwrite_output()
                .run()
            )

            # Extract audio from processed video
            logger.debug(f"Extracting audio from processed video: {output_path}")
            (
                ffmpeg.input(str(output_path))
                .output(str(processed_audio), acodec="pcm_s16le")
                .global_args("-loglevel", "error" if not verbose else "info")
                .overwrite_output()
                .run()
            )

            # Load both audio files using numpy to avoid pedalboard API issues
            try:
                # Use scipy or numpy to read WAV files directly
                import scipy.io.wavfile as wavfile

                # Read original audio
                orig_sr, original = wavfile.read(original_audio)
                # Read processed audio
                proc_sr, processed = wavfile.read(processed_audio)

                logger.debug(
                    f"Original shape: {original.shape}, Processed shape: {processed.shape}"
                )

                # Convert to float for processing
                if original.dtype != np.float32:
                    original = (
                        original.astype(np.float32) / 32768.0
                    )  # Normalize 16-bit audio

                if processed.dtype != np.float32:
                    processed = (
                        processed.astype(np.float32) / 32768.0
                    )  # Normalize 16-bit audio

            except ImportError:
                logger.warning("scipy not available, trying alternate method")
                try:
                    # Alternative method using numpy directly (no need to reimport np)
                    original = np.memmap(original_audio, dtype="int16", mode="r")
                    processed = np.memmap(processed_audio, dtype="int16", mode="r")

                    # Reshape based on channels

                    # Convert to float and normalize
                    original = original.astype(np.float32) / 32768.0
                    processed = processed.astype(np.float32) / 32768.0

                except Exception as e:
                    logger.error(f"Error reading audio files: {e}")
                    return 0.0, 1.0

            except Exception as e:
                logger.error(f"Error reading audio files for verification: {str(e)}")
                return 0.0, 1.0

            # Calculate difference metrics
            if original is None or processed is None:
                logger.error("Failed to read audio data for verification")
                return 0.0, 1.0

            # Handle different shapes properly by truncating to the shorter length
            logger.debug(
                f"Original shape: {original.shape}, Processed shape: {processed.shape}"
            )

            # Handle multi-dimensional arrays (stereo audio)
            if len(original.shape) > 1 and len(processed.shape) > 1:
                # Get minimum length in both dimensions
                min_length = min(original.shape[0], processed.shape[0])
                # Truncate both arrays to the same length
                original = original[:min_length, :]
                processed = processed[:min_length, :]
            else:
                # For mono audio or flattened arrays
                min_length = min(len(original), len(processed))
                original = original[:min_length]
                processed = processed[:min_length]

            logger.debug(
                f"After truncation - Original shape: {original.shape}, Processed shape: {processed.shape}"
            )

            # Normalize processed audio to match original volume for delay-only mode
            # This is necessary for our verification to accurately reflect just the delay effect
            orig_rms = np.sqrt(np.mean(original**2))
            proc_rms = np.sqrt(np.mean(processed**2))

            # Calculate ratio of processed to original volume
            ratio = proc_rms / orig_rms if orig_rms > 0 else 1.0

            # If there's a significant volume difference, normalize for true comparison
            if ratio > 1.1 or ratio < 0.9:
                logger.info(
                    f"Normalizing processed audio for verification (ratio: {ratio:.2f})"
                )
                processed_normalized = processed / ratio
                # Calculate absolute difference with normalized audio
                abs_diff = np.abs(original - processed_normalized)
                avg_diff = np.mean(abs_diff)
            else:
                # Calculate absolute difference
                abs_diff = np.abs(original - processed)
                avg_diff = np.mean(abs_diff)

            # Report statistics
            logger.info(f"Original min/max: {original.min():.4f}/{original.max():.4f}")
            logger.info(
                f"Processed min/max: {processed.min():.4f}/{processed.max():.4f}"
            )
            logger.info(f"Avg absolute difference: {avg_diff:.4f}")
            logger.info(f"Original RMS: {orig_rms:.4f}, Processed RMS: {proc_rms:.4f}")
            logger.info(f"Volume ratio (processed/original): {ratio:.2f}x")

            return float(avg_diff), float(
                ratio
            )  # Ensure we return float not numpy types

    except Exception as e:
        logger.error(f"Error verifying audio change: {str(e)}")
        return 0.0, 1.0


def process_video(
    input_path: str,
    output_path: str,
    room_size: float = 0.5,
    damping: float = 0.5,
    wet_level: float = 0.33,
    dry_level: float = 0.7,
    width: float = 1.0,
    freeze_mode: float = 0.0,
    preset: Literal["tiny", "small", "medium", "large", "church", "extreme"]
    | None = None,
    audio_bitrate: str = "192k",
    verbose: bool = False,
    verify: bool = False,
    delay: int = 0,
) -> None:
    """
    Add room reverb to a video file's audio track.

    This tool makes your video sound like it was recorded in a real space instead of a
    studio. It works in three steps:

    1. Extracts the audio from your video
    2. Applies reverb effects to make it sound more natural and spacious
    3. Combines the enhanced audio with your original video

    Instead of adjusting individual settings, you can use presets like 'tiny', 'small', 'medium',
    'large', or 'church' for quick results.

    Args:
        input_path: Location of your video file (MP4, MOV, etc.)

        output_path: Where to save the processed video

        room_size: How big the virtual room sounds (0.0 to 1.0)
            - 0.2: Small room like a bathroom
            - 0.5: Medium room like a living room (default)
            - 0.8: Large hall or auditorium
            - 1.0: Massive cathedral-like space

        damping: How much the room absorbs high frequencies (0.0 to 1.0)
            - 0.0: Reflective surfaces like marble/glass (bright echo)
            - 0.5: Balanced room with some soft furnishings (default)
            - 1.0: Heavily dampened room with carpets/curtains (muffled echo)

        wet_level: How much reverb to add (0.0 to 1.0)
            - 0.0: No reverb at all
            - 0.33: Subtle, natural reverb (default)
            - 0.7: Obvious reverb effect
            - 1.0: Extremely wet, dramatic reverb

        dry_level: How much of the original audio to keep (0.0 to 1.0)
            - 0.0: Only reverb, no original sound
            - 0.7: Good balance with reverb (default)
            - 1.0: Full original audio plus reverb

        width: How wide the reverb spreads in stereo (0.0 to 1.0)
            - 0.0: Mono reverb (centered)
            - 0.5: Moderate stereo width
            - 1.0: Full stereo spread (default)

        freeze_mode: Creates an infinite sustain effect (0.0 to 1.0)
            - 0.0: Normal reverb that fades out (default)
            - 0.5: Some sustained reverb
            - 1.0: Infinite sustain (special effect)

        preset: Quick presets that set multiple parameters for you
            - "tiny": Extremely subtle ambience, barely noticeable
            - "small": Bathroom or small room, very subtle
            - "medium": Living room or office (balanced)
            - "large": Concert hall or auditorium
            - "church": Cathedral or large reverberant space
            - "extreme": Maximum dramatic reverb effect
            - None: Use your custom settings instead (default)

        audio_bitrate: Quality of the output audio
            - "128k": Lower quality, smaller file size
            - "192k": Good quality, moderate file size (default)
            - "256k": Higher quality, larger file size

        verbose: Whether to show detailed progress information

        verify: After processing, verify the audio has been changed by comparing
               the original and processed audio tracks

        delay: Milliseconds to delay audio relative to video
            - Positive values: Audio plays later (e.g. 250 = audio lags by 250ms)
            - Negative values: Audio plays earlier (e.g. -100 = audio is ahead by 100ms)
            - 0: No delay adjustment (default)

    Raises:
        FileNotFoundError: If the input video file doesn't exist
        ValueError: If any parameter is invalid

    Example usage:
        # Basic usage with default settings (no reverb, just copies audio)
        process_video("myvideo.mp4", "myvideo_out.mp4")

        # Add tiny ambient reverb
        process_video("myvideo.mp4", "myvideo_tiny.mp4", preset="tiny")

        # Add subtle room reverb
        process_video("myvideo.mp4", "myvideo_reverb.mp4", preset="small")

        # Using a preset for quick results
        process_video("myvideo.mp4", "myvideo_church.mp4", preset="church")

        # Fine-tuning reverb parameters
        process_video("myvideo.mp4", "myvideo_custom.mp4",
                      room_size=0.7, wet_level=0.4, damping=0.3)

        # Verify that the audio was changed
        process_video("myvideo.mp4", "myvideo_reverb.mp4", preset="medium", verify=True)

        # Fixing audio sync issues (+250ms delay)
        process_video("myvideo.mp4", "myvideo_synced.mp4", delay=250)

        # Maximum reverb effect
        process_video("myvideo.mp4", "myvideo_extreme.mp4", preset="extreme")

        # Only adjust audio delay without adding reverb
        process_video("myvideo.mp4", "myvideo_fixed.mp4", delay=-150)
    """
    # Initialize logger
    setup_logger(verbose)

    # Apply preset if specified
    if preset:
        if preset == "tiny":
            # Extremely subtle ambient reverb, practically imperceptible
            room_size, damping, wet_level, dry_level = 0.08, 0.85, 0.03, 0.97
        elif preset == "small":
            # Very subtle small room effect
            room_size, damping, wet_level, dry_level = 0.10, 0.75, 0.05, 0.95
        elif preset == "medium":
            # Subtle but noticeable room ambience
            room_size, damping, wet_level, dry_level = 0.15, 0.65, 0.10, 0.90
        elif preset == "large":
            # Use the previous "medium" values for large
            room_size, damping, wet_level, dry_level = 0.4, 0.5, 0.25, 0.8
        elif preset == "church":
            # Use the previous "large" values for church
            room_size, damping, wet_level, dry_level = 0.7, 0.4, 0.35, 0.75
        elif preset == "extreme":
            # Maximum reverb effect
            room_size, damping, wet_level, dry_level = 0.95, 0.1, 0.7, 0.5
            # Add slight freeze for more drama
            freeze_mode = 0.1
        logger.info(
            f"Using '{preset}' preset: room_size={room_size}, damping={damping}, "
            f"wet={wet_level}, dry={dry_level}"
        )
    else:
        # If no preset but also no reverb parameters changed, check if this is just a delay adjustment
        default_values = {
            "room_size": 0.5,
            "damping": 0.5,
            "wet_level": 0.33,
            "dry_level": 0.7,
            "width": 1.0,
            "freeze_mode": 0.0,
        }

        is_default_values = (
            room_size == default_values["room_size"]
            and damping == default_values["damping"]
            and wet_level == default_values["wet_level"]
            and dry_level == default_values["dry_level"]
            and width == default_values["width"]
            and freeze_mode == default_values["freeze_mode"]
        )

        if is_default_values and delay != 0:
            # This appears to be just a delay adjustment without reverb
            # Set wet to 0 to disable reverb effect
            wet_level = 0.0
            dry_level = 1.0
            logger.info(
                "No reverb preset specified, delay-only mode with no reverb effect"
            )
        elif is_default_values:
            # Clearly state that no preset is being used but default values will apply some reverb
            logger.info(
                "No preset specified. Using default reverb settings (subtle effect)."
            )

    # Log delay if specified
    if delay != 0:
        logger.info(
            f"Audio will be {'delayed' if delay > 0 else 'advanced'} by {abs(delay)}ms"
        )

    # Convert paths to Path objects - modify parameters but use local variables for Path objects
    input_path_str = input_path  # Keep original string
    output_path_str = output_path  # Keep original string

    # Create Path objects for actual operations
    input_path_obj = Path(input_path_str).expanduser().resolve()
    output_path_obj = Path(output_path_str).expanduser().resolve()

    # Validate input file
    if not input_path_obj.exists():
        raise FileNotFoundError(f"Input file not found: {input_path_obj}")

    # Check if input is actually a video file
    if input_path_obj.suffix.lower() not in (".mp4", ".mov", ".avi", ".mkv", ".webm"):
        logger.warning(
            f"File '{input_path_obj}' doesn't have a common video extension. "
            f"Will attempt to process anyway but may fail."
        )

    # Create output directory if it doesn't exist
    output_path_obj.parent.mkdir(parents=True, exist_ok=True)

    # Remove output file if it exists
    if output_path_obj.exists():
        logger.info(f"Removing existing output file: {output_path_obj}")
        try:
            output_path_obj.unlink()
        except Exception as e:
            logger.warning(f"Could not remove existing output file: {e}")

    # Process with progress indication
    with Progress(
        SpinnerColumn(), TextColumn("[bold blue]{task.description}"), console=console
    ) as progress:
        task_count = 4 if verify else 3
        task = progress.add_task("Processing video...", total=task_count)

        with tempfile.TemporaryDirectory() as temp_dir:
            # Create temporary file paths
            temp_audio = Path(temp_dir) / "extracted_audio.wav"
            temp_processed_audio = Path(temp_dir) / "processed_audio.wav"

            # Extract audio from video
            progress.update(task, description="Extracting audio...")
            sample_rate, channels = extract_audio(input_path_obj, temp_audio, verbose)
            progress.update(task, advance=1)

            # Apply reverb effect
            progress.update(task, description="Applying reverb effect...")
            apply_reverb(
                temp_audio,
                temp_processed_audio,
                room_size=room_size,
                damping=damping,
                wet_level=wet_level,
                dry_level=dry_level,
                width=width,
                freeze_mode=freeze_mode,
                delay_ms=delay,
                verbose=verbose,
            )
            progress.update(task, advance=1)

            # Merge audio with video
            progress.update(task, description="Merging audio with video...")
            merge_audio_with_video(
                input_path_obj,
                temp_processed_audio,
                output_path_obj,
                audio_bitrate=audio_bitrate,
                verbose=verbose,
            )
            progress.update(task, advance=1)

            # Verify the audio was changed if requested
            if verify:
                progress.update(task, description="Verifying audio changes...")
                avg_diff, ratio = verify_audio_change(
                    input_path_obj, output_path_obj, verbose
                )
                progress.update(task, advance=1)

                if avg_diff < 0.001:
                    console.print(
                        f"\n[bold yellow]Warning:[/] Very small difference detected between original and processed audio ({avg_diff:.4f})."
                        f"\nThe reverb effect may be too subtle or not applied correctly."
                    )
                elif avg_diff > 0.1:
                    console.print(
                        f"\n[bold green]Verification:[/] Strong audio effect detected with an average difference of {avg_diff:.4f}"
                        f"\nVolume ratio (processed/original): {ratio:.2f}x"
                    )
                else:
                    console.print(
                        f"\n[bold green]Verification:[/] Audio successfully modified with an average difference of {avg_diff:.4f}"
                        f"\nVolume ratio (processed/original): {ratio:.2f}x"
                    )

    console.print(
        f"\n[bold green]Success![/] Video saved to: [bold]{output_path_str}[/]"
    )


def main():
    """Run the VidReverb tool with Fire CLI."""
    try:
        fire.Fire(process_video)
    except KeyboardInterrupt:
        console.print("\n[bold red]Process interrupted by user.[/]")
        return 1
    except Exception as e:
        console.print(f"\n[bold red]Error:[/] {str(e)}")
        logger.exception("An unexpected error occurred")
        return 1
    return 0


if __name__ == "__main__":
    main()
