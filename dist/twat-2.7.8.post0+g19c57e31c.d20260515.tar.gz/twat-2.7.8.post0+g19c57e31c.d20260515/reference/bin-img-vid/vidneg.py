#!/usr/bin/env python3
from pathlib import Path
import fire
import subprocess

def create_negative(input_path: str, output_path: str = None):
    if output_path is None:
        input_file = Path(input_path)
        output_path = str(input_file.parent / f"{input_file.stem}_neg{input_file.suffix}")
    
    cmd = [
        'ffmpeg',
        '-i', input_path,
        '-vf', 'negate',
        '-c:a', 'copy',
        output_path
    ]
    
    subprocess.run(cmd, check=True)
    print(f"Created negative video: {output_path}")

if __name__ == '__main__':
    fire.Fire(create_negative)
