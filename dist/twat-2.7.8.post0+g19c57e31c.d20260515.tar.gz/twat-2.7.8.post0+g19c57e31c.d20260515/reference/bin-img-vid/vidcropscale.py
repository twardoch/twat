#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "loguru", "rich"]
# ///
# this_file: vidcropscale.py

"""
Crop and scale a video with explicit numeric geometry.

This command keeps the stubbed CLI intentionally small:
- `scale` accepts `WIDTHx`, `WIDTHxHEIGHT`, or `xHEIGHT`
- `crop` accepts `WIDTHx`, `WIDTHxHEIGHT`, `xHEIGHT`, or `WRATIO:HRATIO`
- `top/right/bottom/left` accept pixels, percentages, or `auto`
- resolved crop/scale dimensions must be even for codec-safe output
- `post_scale=False` applies scale before crop
- `post_scale=True` applies crop before scale

Examples:
    vidcropscale.py --input clip.mp4 --scale 1280x
    vidcropscale.py --input clip.mp4 --crop 4:3
    vidcropscale.py --input clip.mp4 --crop 1280x720 --left 100 --top 40
    vidcropscale.py --input clip.mp4 --crop 4:3 --left 5% --right 5% --post_scale True
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Literal, TypedDict

import fire
from loguru import logger
from rich.console import Console


logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
)

console = Console()
AUTO = "auto"


class RatioCropSpec(TypedDict):
    kind: Literal["ratio"]
    ratio: tuple[int, int]


class DimensionCropSpec(TypedDict):
    kind: Literal["dimensions"]
    width: str | None
    height: str | None


CropSpec = RatioCropSpec | DimensionCropSpec


def check_ffmpeg_tools() -> None:
    missing = [tool for tool in ("ffmpeg", "ffprobe") if shutil.which(tool) is None]
    if missing:
        names = ", ".join(missing)
        raise RuntimeError(
            f"Missing required tool(s): {names}. Install FFmpeg first, for example with `brew install ffmpeg`."
        )


def validate_input_path(input_path: Path) -> None:
    if not input_path.exists():
        raise FileNotFoundError(f"Input video not found: {input_path}")
    if not input_path.is_file():
        raise ValueError(f"Input path is not a file: {input_path}")


def parse_measure(
    value: str | int | None,
    axis_size: int,
    allow_auto: bool = False,
    allow_zero: bool = False,
) -> int | str | None:
    if value is None:
        return None

    if isinstance(value, int):
        minimum_label = "non-negative" if allow_zero else "positive"
        if value < 0 or (value == 0 and not allow_zero):
            raise ValueError(f"Expected a {minimum_label} integer, got {value}")
        return value

    text = str(value).strip()
    if not text:
        raise ValueError("Expected a non-empty value")

    if allow_auto and text.lower() == AUTO:
        return AUTO

    if text.endswith("%"):
        number_text = text[:-1].strip()
        if not number_text:
            raise ValueError(f"Invalid percentage value: {value}")
        percentage = float(number_text)
        resolved = int(axis_size * (percentage / 100.0))
        if resolved < 0 or (resolved == 0 and not allow_zero):
            minimum_label = "non-negative" if allow_zero else "positive"
            raise ValueError(f"Resolved percentage must be {minimum_label}: {value}")
        return resolved

    resolved = int(text)
    minimum_label = "non-negative" if allow_zero else "positive"
    if resolved < 0 or (resolved == 0 and not allow_zero):
        raise ValueError(f"Expected a {minimum_label} integer, got {value}")
    return resolved


def parse_scale_spec(spec: str | None) -> tuple[str | None, str | None]:
    if spec is None:
        return None, None

    text = spec.strip()
    if text.count("x") != 1:
        raise ValueError(f"Invalid scale spec: {spec}")

    width_text, height_text = text.split("x", 1)
    width = width_text.strip() or None
    height = height_text.strip() or None
    if width is None and height is None:
        raise ValueError(f"Invalid scale spec: {spec}")
    validate_dimension_token(width, "scale width")
    validate_dimension_token(height, "scale height")
    return width, height


def parse_crop_spec(spec: str | None) -> CropSpec | None:
    if spec is None:
        return None

    text = spec.strip()
    if not text:
        raise ValueError("Crop spec must not be empty")

    if ":" in text:
        if text.count(":") != 1:
            raise ValueError(f"Invalid crop ratio: {spec}")
        width_text, height_text = text.split(":", 1)
        ratio_w = int(width_text.strip())
        ratio_h = int(height_text.strip())
        if ratio_w <= 0 or ratio_h <= 0:
            raise ValueError(f"Invalid crop ratio: {spec}")
        return {"kind": "ratio", "ratio": (ratio_w, ratio_h)}

    if text.count("x") != 1:
        raise ValueError(f"Invalid crop spec: {spec}")

    width_text, height_text = text.split("x", 1)
    width = width_text.strip() or None
    height = height_text.strip() or None
    if width is None and height is None:
        raise ValueError(f"Invalid crop spec: {spec}")
    validate_dimension_token(width, "crop width")
    validate_dimension_token(height, "crop height")
    return {"kind": "dimensions", "width": width, "height": height}


def validate_dimension_token(value: str | None, label: str) -> None:
    if value is None:
        return

    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"Invalid {label}: {value}") from exc

    if parsed <= 0:
        raise ValueError(f"Invalid {label}: {value}")


def resolve_numeric_measure(
    value: str | int,
    axis_size: int,
    *,
    allow_zero: bool = False,
) -> int:
    parsed = parse_measure(value, axis_size, allow_zero=allow_zero)
    if not isinstance(parsed, int):
        raise ValueError(f"Expected a numeric value, got {value!r}")
    return parsed


def require_even_dimension(value: int, label: str) -> int:
    if value <= 0:
        raise ValueError(f"Resolved {label} must be positive")
    if value % 2 != 0:
        raise ValueError(
            f"Resolved {label} must be even for codec compatibility, got {value}"
        )
    return value


def probe_video_size(input_path: Path) -> tuple[int, int]:
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height",
        "-of",
        "json",
        str(input_path),
    ]
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    payload = json.loads(result.stdout)
    streams = payload.get("streams") or []
    if not streams:
        raise ValueError(f"No video stream found in input file: {input_path}")

    stream = streams[0]
    width = int(stream["width"])
    height = int(stream["height"])
    if width <= 0 or height <= 0:
        raise ValueError(f"Invalid video dimensions reported for {input_path}")
    return width, height


def build_output_path(input_path: Path, output: str | None) -> Path:
    if output:
        return Path(output).expanduser()
    return input_path.with_name(f"{input_path.stem}_cropscale{input_path.suffix}")


def resolve_scale_dimensions(
    scale_spec: tuple[str | None, str | None],
    frame_w: int,
    frame_h: int,
    original_w: int,
    original_h: int,
) -> tuple[int, int] | None:
    width_token, height_token = scale_spec
    if width_token is None and height_token is None:
        return None

    if width_token is None:
        assert height_token is not None
        height = resolve_numeric_measure(height_token, original_h)
        width = max(1, int(frame_w * (height / frame_h)))
    elif height_token is None:
        width = resolve_numeric_measure(width_token, original_w)
        height = max(1, int(frame_h * (width / frame_w)))
    else:
        width = resolve_numeric_measure(width_token, original_w)
        height = resolve_numeric_measure(height_token, original_h)

    width = require_even_dimension(width, "scale width")
    height = require_even_dimension(height, "scale height")

    if width <= 0 or height <= 0:
        raise ValueError("Resolved scale dimensions must be positive")
    return width, height


def _parse_side_value(value: str | int | None, axis_size: int) -> int | str:
    parsed = parse_measure(
        value if value is not None else AUTO,
        axis_size,
        allow_auto=True,
        allow_zero=True,
    )
    return AUTO if parsed is None else parsed


def _resolve_axis_bounds(
    frame_size: int,
    start_side: int | str,
    end_side: int | str,
    target_size: int | None,
    axis_name: str,
) -> tuple[int, int]:
    start_fixed = start_side != AUTO
    end_fixed = end_side != AUTO
    start_value = 0 if start_side == AUTO else int(start_side)
    end_value = 0 if end_side == AUTO else int(end_side)

    if start_fixed and end_fixed:
        size = frame_size - start_value - end_value
        if size <= 0:
            raise ValueError(f"{axis_name} paddings leave no space to crop")
        size = require_even_dimension(size, f"{axis_name} crop size")
        return start_value, size

    if target_size is None:
        if start_fixed:
            size = frame_size - start_value
            if size <= 0:
                raise ValueError(f"{axis_name} crop leaves no remaining space")
            size = require_even_dimension(size, f"{axis_name} crop size")
            return start_value, size
        if end_fixed:
            size = frame_size - end_value
            if size <= 0:
                raise ValueError(f"{axis_name} crop leaves no remaining space")
            size = require_even_dimension(size, f"{axis_name} crop size")
            return 0, size
        return 0, require_even_dimension(frame_size, f"{axis_name} crop size")

    if target_size <= 0:
        raise ValueError(f"Resolved {axis_name} crop size must be positive")
    if target_size > frame_size:
        raise ValueError(
            f"Resolved {axis_name} crop size {target_size} exceeds frame size {frame_size}"
        )

    target_size = require_even_dimension(target_size, f"{axis_name} crop size")

    remaining = frame_size - target_size
    if start_fixed and start_value > remaining:
        raise ValueError(f"{axis_name} start padding pushes crop outside the frame")
    if end_fixed and end_value > remaining:
        raise ValueError(f"{axis_name} end padding pushes crop outside the frame")

    if start_fixed:
        return start_value, target_size
    if end_fixed:
        return frame_size - end_value - target_size, target_size
    return remaining // 2, target_size


def _resolve_ratio_crop(
    ratio: tuple[int, int],
    available_w: int,
    available_h: int,
) -> tuple[int, int]:
    ratio_w, ratio_h = ratio
    if available_w <= 0 or available_h <= 0:
        raise ValueError("Fixed paddings leave no space for ratio crop")

    if available_w * ratio_h <= available_h * ratio_w:
        width = available_w
        height = int(width * ratio_h / ratio_w)
    else:
        height = available_h
        width = int(height * ratio_w / ratio_h)

    if width <= 0 or height <= 0:
        raise ValueError("Resolved ratio crop dimensions must be positive")
    return width, height


def resolve_crop_rect(
    crop_spec: CropSpec | None,
    top: str | int | None,
    right: str | int | None,
    bottom: str | int | None,
    left: str | int | None,
    frame_w: int,
    frame_h: int,
) -> tuple[int, int, int, int] | None:
    top_value = _parse_side_value(top, frame_h)
    right_value = _parse_side_value(right, frame_w)
    bottom_value = _parse_side_value(bottom, frame_h)
    left_value = _parse_side_value(left, frame_w)

    has_fixed_sides = any(
        side != AUTO for side in (top_value, right_value, bottom_value, left_value)
    )
    if crop_spec is None and not has_fixed_sides:
        return None

    left_fixed = left_value != AUTO
    right_fixed = right_value != AUTO
    top_fixed = top_value != AUTO
    bottom_fixed = bottom_value != AUTO

    available_w = (
        frame_w
        - (0 if left_value == AUTO else int(left_value))
        - (0 if right_value == AUTO else int(right_value))
    )
    available_h = (
        frame_h
        - (0 if top_value == AUTO else int(top_value))
        - (0 if bottom_value == AUTO else int(bottom_value))
    )
    if available_w <= 0 or available_h <= 0:
        raise ValueError("Fixed paddings leave no space to crop")

    target_width: int | None = None
    target_height: int | None = None

    if crop_spec is not None:
        if crop_spec["kind"] == "dimensions":
            width_token = crop_spec["width"]
            height_token = crop_spec["height"]
            if width_token is not None and not (left_fixed and right_fixed):
                target_width = resolve_numeric_measure(width_token, frame_w)
            if height_token is not None and not (top_fixed and bottom_fixed):
                target_height = resolve_numeric_measure(height_token, frame_h)
        elif crop_spec["kind"] == "ratio":
            if not (left_fixed and right_fixed and top_fixed and bottom_fixed):
                ratio_width, ratio_height = _resolve_ratio_crop(
                    crop_spec["ratio"],
                    available_w,
                    available_h,
                )
                if not (left_fixed and right_fixed):
                    target_width = ratio_width
                if not (top_fixed and bottom_fixed):
                    target_height = ratio_height
    x, crop_w = _resolve_axis_bounds(
        frame_w, left_value, right_value, target_width, "horizontal"
    )
    y, crop_h = _resolve_axis_bounds(
        frame_h, top_value, bottom_value, target_height, "vertical"
    )

    if x < 0 or y < 0 or x + crop_w > frame_w or y + crop_h > frame_h:
        raise ValueError("Resolved crop rectangle exceeds frame bounds")
    return crop_w, crop_h, x, y


def build_filter_chain(
    scale_dims: tuple[int, int] | None,
    crop_rect: tuple[int, int, int, int] | None,
    post_scale: bool,
) -> str:
    filters: list[str] = []
    if post_scale:
        if crop_rect is not None:
            crop_w, crop_h, crop_x, crop_y = crop_rect
            filters.append(f"crop={crop_w}:{crop_h}:{crop_x}:{crop_y}")
        if scale_dims is not None:
            scale_w, scale_h = scale_dims
            filters.append(f"scale={scale_w}:{scale_h}")
    else:
        if scale_dims is not None:
            scale_w, scale_h = scale_dims
            filters.append(f"scale={scale_w}:{scale_h}")
        if crop_rect is not None:
            crop_w, crop_h, crop_x, crop_y = crop_rect
            filters.append(f"crop={crop_w}:{crop_h}:{crop_x}:{crop_y}")

    if not filters:
        raise ValueError("Nothing to do: specify scale, crop, or fixed crop sides")
    return ",".join(filters)


def run_ffmpeg(
    input_path: Path,
    output_path: Path,
    filter_chain: str,
    verbose: bool,
) -> None:
    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(input_path),
        "-vf",
        filter_chain,
        "-c:a",
        "copy",
        str(output_path),
    ]
    if verbose:
        logger.debug(f"Running command: {' '.join(command)}")

    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() or str(exc)
        raise RuntimeError(f"FFmpeg failed: {stderr}") from exc


def vidcropscale(
    input: str,
    output: str | None = None,
    crop: str | None = None,
    top: str | int | None = AUTO,
    right: str | int | None = AUTO,
    bottom: str | int | None = AUTO,
    left: str | int | None = AUTO,
    scale: str | None = None,
    post_scale: bool = False,
    verbose: bool = False,
) -> str:
    if verbose:
        logger.remove()
        logger.add(
            sys.stderr,
            format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
            level="DEBUG",
        )

    input_path = Path(input).expanduser()
    validate_input_path(input_path)
    check_ffmpeg_tools()

    output_path = build_output_path(input_path, output)
    if output_path == input_path:
        raise ValueError("Output path must differ from the input path")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    crop_spec = parse_crop_spec(crop)
    scale_spec = parse_scale_spec(scale)

    original_width, original_height = probe_video_size(input_path)
    logger.info(f"Input: {input_path}")
    logger.info(f"Original dimensions: {original_width}x{original_height}")

    if post_scale:
        crop_rect = resolve_crop_rect(
            crop_spec,
            top,
            right,
            bottom,
            left,
            original_width,
            original_height,
        )
        scale_frame_w = original_width if crop_rect is None else crop_rect[0]
        scale_frame_h = original_height if crop_rect is None else crop_rect[1]
        scale_dims = resolve_scale_dimensions(
            scale_spec,
            scale_frame_w,
            scale_frame_h,
            original_width,
            original_height,
        )
    else:
        scale_dims = resolve_scale_dimensions(
            scale_spec,
            original_width,
            original_height,
            original_width,
            original_height,
        )
        crop_frame_w = original_width if scale_dims is None else scale_dims[0]
        crop_frame_h = original_height if scale_dims is None else scale_dims[1]
        crop_rect = resolve_crop_rect(
            crop_spec,
            top,
            right,
            bottom,
            left,
            crop_frame_w,
            crop_frame_h,
        )

    filter_chain = build_filter_chain(scale_dims, crop_rect, post_scale)
    if scale_dims is not None:
        logger.info(f"Scale stage dimensions: {scale_dims[0]}x{scale_dims[1]}")
    if crop_rect is not None:
        crop_w, crop_h, crop_x, crop_y = crop_rect
        logger.info(f"Crop rectangle: {crop_w}x{crop_h} at ({crop_x}, {crop_y})")
    logger.info(f"Output: {output_path}")
    logger.debug(f"Filter chain: {filter_chain}")

    with console.status("Processing video..."):
        run_ffmpeg(input_path, output_path, filter_chain, verbose)

    logger.success(f"Video processed successfully: {output_path}")
    return str(output_path)


def main() -> int:
    try:
        fire.Fire(vidcropscale)
    except Exception as exc:
        logger.error(f"Error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
