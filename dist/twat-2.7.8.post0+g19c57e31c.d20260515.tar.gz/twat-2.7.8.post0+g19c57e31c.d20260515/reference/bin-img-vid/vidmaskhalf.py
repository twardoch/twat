#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["opencv-python", "fire", "rich", "loguru"]
# ///
# this_file: vidmaskhalf.py

"""Video masking/cropping tool that processes videos by either masking or cropping half of the frame.

This script provides functionality to:
1. Mask half of a video with a solid color
2. Crop half of a video (removing either left or right side)

The output filename is automatically generated based on the operation and parameters used.

Examples:
    # Mask the left half with white (default)
    vidmaskhalf.py video.mp4

    # Mask the right half with white
    vidmaskhalf.py video.mp4 --half R

    # Mask the left half with black
    vidmaskhalf.py video.mp4 --mask-color 000000

    # Mask the left half with red
    vidmaskhalf.py video.mp4 --mask-color FF0000

    # Crop (remove) the left half instead of masking
    vidmaskhalf.py video.mp4 --crop

    # Crop (remove) the right half
    vidmaskhalf.py video.mp4 --half R --crop

    # Specify custom output path
    vidmaskhalf.py video.mp4 --output-path masked_video.mp4
"""

from pathlib import Path
from typing import Literal
import cv2  # type: ignore
import fire  # type: ignore
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)
from loguru import logger

HalfType = Literal["L", "R"]


def validate_hex_color(hex_color: str) -> tuple[int, int, int]:
    """Validate and convert hex color string to BGR tuple.

    Args:
        hex_color: RGB hex color string (e.g. "FFFFFF" for white)

    Returns:
        tuple[int, int, int]: BGR color tuple

    Raises:
        ValueError: If hex_color is invalid
    """
    if not (
        len(hex_color) == 6 and all(c in "0123456789ABCDEFabcdef" for c in hex_color)
    ):
        raise ValueError(
            f"Invalid hex color: {hex_color}. Must be 6 hex digits (e.g. 'FFFFFF')"
        )

    # Convert RGB hex to BGR tuple
    r, g, b = int(hex_color[:2], 16), int(hex_color[2:4], 16), int(hex_color[4:], 16)
    return (b, g, r)  # OpenCV uses BGR


def process_video(
    input_path: str | Path,
    output_path: str | Path | None = None,
    half: HalfType = "L",
    crop: bool = False,
    mask_color: str = "FFFFFF",
) -> None:
    """Process a video by either masking or cropping half of each frame.

    Args:
        input_path: Path to input video file
        output_path: Path to save output video (auto-generated if None)
        half: Which half to process ("L" for left, "R" for right)
        crop: Whether to crop the video instead of masking
        mask_color: RGB hex color for masking (e.g. "FFFFFF" for white)

    Raises:
        ValueError: If parameters are invalid
        RuntimeError: If video processing fails
    """
    input_path = Path(input_path)
    if not input_path.exists():
        raise ValueError(f"Input video not found: {input_path}")

    # Generate output path if not provided
    if output_path is None:
        suffix = (
            f"_cropped_{half.lower()}.mp4"
            if crop
            else f"_{mask_color}_{half.lower()}.mp4"
        )
        output_path = input_path.with_name(input_path.stem + suffix)
    else:
        output_path = Path(output_path)

    logger.info(f"Processing video: {input_path}")
    logger.info(f"Output will be saved to: {output_path}")

    # Initialize bgr_color with a default value
    bgr_color = (255, 255, 255)  # Default white

    # Validate color if masking
    if not crop:
        bgr_color = validate_hex_color(mask_color)

    # Open input video
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video: {input_path}")

    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Calculate dimensions
    half_width = width // 2
    new_width = half_width if crop else width

    # Create video writer using cv2 constants directly
    fourcc = int(cv2.VideoWriter_fourcc("m", "p", "4", "v"))
    out = cv2.VideoWriter(str(output_path), fourcc, fps, (new_width, height))

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
    ) as progress:
        task = progress.add_task("Processing frames...", total=total_frames)

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if crop:
                # Crop the frame
                frame = frame[:, half_width:] if half == "L" else frame[:, :half_width]
            else:
                # Apply mask color directly to the frame half
                if half == "L":
                    frame[:, :half_width] = bgr_color  # Set left half to mask color
                else:  # half == "R"
                    frame[:, half_width:] = bgr_color  # Set right half to mask color

            out.write(frame)
            progress.advance(task)

    # Clean up
    cap.release()
    out.release()
    logger.success(f"Video processing complete! Output saved to: {output_path}")


def main(
    input_path: str,
    output_path: str | None = None,
    half: HalfType = "L",
    crop: bool = False,
    mask_color: str = "FFFFFF",
) -> None:
    """CLI entrypoint for video processing tool.

    Args:
        input_path: Path to input video file
        output_path: Path to save output video (auto-generated if None)
        half: Which half to process ("L" for left, "R" for right)
        crop: Whether to crop the video instead of masking
        mask_color: RGB hex color for masking (e.g. "FFFFFF" for white)
    """
    try:
        process_video(input_path, output_path, half, crop, mask_color)
    except Exception as e:
        logger.error(f"Error processing video: {e}")
        raise


if __name__ == "__main__":
    fire.Fire(main)
