Write 'vidmp4to5.py' that takes --input_path which can be a video file or a folder. 

If --input_path is a video file, the tool checks if the video is H.265/HEVC. Skip if it is. If it’s not, it converts it to H.265/HEVC with .mp4 extension, with quality that will make the file smaller but will not degrade the video quality. It needs to make it smart. If the video is long, quite possibly the tool should first take out a short snippet, convert, then compare some corresponding frames and check for artefacts (find an appropriate tool/lib to do it), and determine the optimal compression params. 

If --keep is given, then the original file is kept (if the original file has the extension .mp4, then the output file should use the same basename plus `_hevc` suffix, if any other original extension, then we use the basename without any suffix (because the otuput extension will be .mp4 so there is no conflict). 

If --keep is not given, then the original file is removed, and if the has the extension .mp4, then after the removal of the original we rename the new file to be the same as the original. 

If --input_path is a folder, the tool locates all video files in the folder recursively, and performs the conversion. 

Use Fire CLI, rich progress bars. Use https://pypi.org/project/static-ffmpeg/ 

