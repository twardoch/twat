#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "Pillow", "numpy", "rich", "pyobjc-framework-Vision", "pyobjc-framework-Quartz", "pyobjc-framework-Cocoa"]
# ///
# this_file: imgrmbg2.py
"""Remove, extract, or uniformize image backgrounds using Apple Vision foreground masks."""

import io
import sys
from pathlib import Path

import fire
import numpy as np
from PIL import Image, ImageFilter
from rich.console import Console

import Vision
from AppKit import NSBitmapImageRep, NSImage
from Quartz import CIContext, CIImage

EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp"}
LOSSY_EXTENSIONS = {".jpg", ".jpeg", ".webp"}
console = Console()


def save_kwargs(path: Path) -> dict[str, int]:
    """Return Pillow save options appropriate for the target extension."""
    if path.suffix.lower() in LOSSY_EXTENSIONS:
        return {"quality": 95}
    return {}


def _generate_mask(input_path: str) -> Image.Image:
    """Generate foreground mask using Apple Vision API. Returns PIL grayscale Image (white=fg)."""
    abs_path = str(Path(input_path).expanduser().resolve())

    # Load image via AppKit
    ns_image = NSImage.alloc().initWithContentsOfFile_(abs_path)
    if not ns_image:
        raise ValueError(f"Failed to load image: {abs_path}")

    cg_image = ns_image.CGImageForProposedRect_context_hints_(None, None, None)[0]
    if not cg_image:
        raise ValueError(f"Failed to convert to CGImage: {abs_path}")

    # Create and run Vision request
    request = Vision.VNGenerateForegroundInstanceMaskRequest.alloc().init()
    handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(cg_image, {})

    success, error = handler.performRequests_error_([request], None)
    if not success:
        raise RuntimeError(f"Vision request failed: {error}")

    results = request.results()
    if not results or len(results) == 0:
        raise RuntimeError("Vision returned no mask results")

    result = results[0]

    # Generate scaled mask CVPixelBuffer
    mask_buffer = result.generateScaledMaskForImageForInstances_fromRequestHandler_error_(
        result.allInstances(), handler, None
    )
    if isinstance(mask_buffer, tuple):
        mask_buffer = mask_buffer[0]
    if mask_buffer is None:
        raise RuntimeError("Failed to generate scaled mask")

    # Convert CVPixelBuffer → CIImage → CGImage → PNG bytes → PIL Image
    mask_ci = CIImage.imageWithCVPixelBuffer_(mask_buffer)
    extent = mask_ci.extent()

    ci_context = CIContext.contextWithOptions_(None)
    cg_mask = ci_context.createCGImage_fromRect_(mask_ci, extent)

    bitmap_rep = NSBitmapImageRep.alloc().initWithCGImage_(cg_mask)
    png_data = bitmap_rep.representationUsingType_properties_(4, None)  # 4 = NSPNGFileType

    mask_pil = Image.open(io.BytesIO(png_data)).convert("L")
    return mask_pil


class ImageBgTool:
    """Remove, extract, or uniformize image backgrounds using Apple Vision."""

    def _auto_output_path(self, input_path: str, suffix: str, force_png: bool = False) -> Path:
        """Generate output path: photo.jpg → photo_suffix.jpg (or .png if force_png)."""
        p = Path(input_path)
        ext = ".png" if force_png else p.suffix
        return p.with_name(f"{p.stem}_{suffix}{ext}")

    def _apply_transform(self, mask: Image.Image, transform: int) -> Image.Image:
        """Dilate (positive) or erode (negative) the mask by N pixels."""
        if transform > 0:
            for _ in range(transform):
                mask = mask.filter(ImageFilter.MaxFilter(3))
        elif transform < 0:
            for _ in range(-transform):
                mask = mask.filter(ImageFilter.MinFilter(3))
        return mask

    def _apply_blur(self, mask: Image.Image, blur: int) -> Image.Image:
        """Apply Gaussian blur to mask if blur > 0."""
        if blur > 0:
            return mask.filter(ImageFilter.GaussianBlur(radius=blur))
        return mask

    def _process_single(self, cmd: str, input_path: str, output_path: str, blur: int, transform: int = 0, **kwargs) -> None:
        """Process a single image file."""
        mask = _generate_mask(input_path)
        img = Image.open(input_path)

        # Resize mask to match image if needed
        if mask.size != img.size:
            mask = mask.resize(img.size, Image.Resampling.LANCZOS)

        # For unibg --keep_foreground: save raw mask before transform/blur
        keep_foreground = kwargs.get("keep_foreground", False)
        mask_raw = mask.copy() if keep_foreground else None

        mask = self._apply_transform(mask, transform)
        mask = self._apply_blur(mask, blur)
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if cmd == "mask":
            mask.save(out_path, **save_kwargs(out_path))

        elif cmd == "rmbg":
            rgba = img.convert("RGBA")
            rgba.putalpha(mask)
            rgba.save(out_path, format="PNG")

        elif cmd == "unibg":
            color = kwargs.get("color")
            strength = kwargs.get("strength", 75)

            img_rgb = img.convert("RGB")
            arr = np.asarray(img_rgb, dtype=np.float64)
            mask_arr = np.asarray(mask, dtype=np.float64)

            # Background pixels: where mask < 128
            bg_mask = mask_arr < 128.0

            # Determine target color
            if color is None:
                # Mean of background pixels
                if np.any(bg_mask):
                    bg_pixels = arr[bg_mask]
                    target = bg_pixels.mean(axis=0)
                else:
                    target = np.array([255.0, 255.0, 255.0])
            elif color == "white":
                target = np.array([255.0, 255.0, 255.0])
            elif color == "black":
                target = np.array([0.0, 0.0, 0.0])
            elif color.startswith("#") and len(color) == 7:
                target = np.array([
                    int(color[1:3], 16),
                    int(color[3:5], 16),
                    int(color[5:7], 16),
                ], dtype=np.float64)
            else:
                raise ValueError(f"Invalid color: {color}. Use 'white', 'black', or '#RRGGBB'.")

            result = arr.copy()

            if np.any(bg_mask):
                bg_pixels = arr[bg_mask]
                # Euclidean distance from each bg pixel to target color
                distances = np.sqrt(np.sum((bg_pixels - target) ** 2, axis=1))

                # Threshold at strength-th percentile
                threshold = np.percentile(distances, strength)

                close = distances <= threshold
                far = ~close

                # Close pixels → set exactly to target
                new_bg = bg_pixels.copy()
                new_bg[close] = target

                # Far pixels → blend toward target with factor strength/100
                blend = strength / 100.0
                new_bg[far] = bg_pixels[far] * (1.0 - blend) + target * blend

                result[bg_mask] = new_bg

            # Composite original foreground on top using unprocessed mask
            if mask_raw is not None:
                fg_alpha = np.asarray(mask_raw, dtype=np.float64)[:, :, np.newaxis] / 255.0
                result = arr * fg_alpha + result * (1.0 - fg_alpha)

            out_arr = np.clip(result, 0, 255).astype(np.uint8)
            Image.fromarray(out_arr).save(out_path, **save_kwargs(out_path))

    def _process(self, cmd: str, input_path: str, output_path: str | None, recursive: bool, blur: int, transform: int = 0, **kwargs) -> None:
        """Route to single or recursive processing."""
        in_path = Path(input_path).expanduser().resolve()

        if recursive:
            if not in_path.is_dir():
                console.print(f"[red]Not a directory: {in_path}[/red]")
                sys.exit(1)

            force_png = cmd == "rmbg"

            if output_path is None:
                out_dir = in_path.parent / f"{in_path.name}_{cmd}"
            else:
                out_dir = Path(output_path).expanduser().resolve()

            images = sorted(
                p for p in in_path.rglob("*")
                if p.is_file() and p.suffix.lower() in EXTENSIONS
            )
            if not images:
                console.print(f"[yellow]No images found in {in_path}[/yellow]")
                return

            console.print(f"[bold]Processing {len(images)} images[/bold] → {out_dir}\n")
            ok, fail = 0, 0

            for img_file in images:
                rel = img_file.relative_to(in_path)
                if force_png:
                    dst = out_dir / rel.with_suffix(".png")
                else:
                    dst = out_dir / rel
                try:
                    self._process_single(cmd, str(img_file), str(dst), blur, transform, **kwargs)
                    ok += 1
                    console.print(f"  [green]OK[/green]   {rel}")
                except Exception as e:
                    fail += 1
                    console.print(f"  [red]FAIL[/red] {rel}: {e}")

            console.print(f"\n[bold]Done:[/bold] {ok} processed, {fail} errors")
            if fail:
                raise SystemExit(1)

        else:
            if not in_path.is_file():
                console.print(f"[red]File not found: {in_path}[/red]")
                sys.exit(1)

            force_png = cmd == "rmbg"
            if output_path is None:
                out = self._auto_output_path(str(in_path), cmd, force_png=force_png)
            else:
                out = Path(output_path).expanduser().resolve()

            try:
                self._process_single(cmd, str(in_path), str(out), blur, transform, **kwargs)
                console.print(f"  [green]OK[/green]   {in_path.name} → {out}")
            except Exception as e:
                console.print(f"  [red]FAIL[/red] {in_path.name}: {e}")
                raise SystemExit(1)

    def mask(self, input_path: str, output_path: str | None = None, recursive: bool = False, transform: int = 0, blur: int = 0) -> None:
        """Extract foreground mask as grayscale image (white=foreground, black=background).

        Args:
            input_path:  Image file or directory (with --recursive).
            output_path: Output file or directory. Auto-generated if omitted.
            recursive:   Process all images in directory tree.
            transform:   Expand foreground (+N) or background (-N) by N pixels.
            blur:        Gaussian blur radius to apply to mask.
        """
        self._process("mask", input_path, output_path, recursive, blur, transform)

    def rmbg(self, input_path: str, output_path: str | None = None, recursive: bool = False, transform: int = 0, blur: int = 0) -> None:
        """Remove background (transparent). Always outputs PNG.

        Args:
            input_path:  Image file or directory (with --recursive).
            output_path: Output file or directory. Auto-generated if omitted.
            recursive:   Process all images in directory tree.
            transform:   Expand foreground (+N) or background (-N) by N pixels.
            blur:        Gaussian blur radius to apply to mask.
        """
        self._process("rmbg", input_path, output_path, recursive, blur, transform)

    def unibg(
        self,
        input_path: str,
        output_path: str | None = None,
        recursive: bool = False,
        transform: int = 0,
        blur: int = 0,
        color: str | None = None,
        strength: int = 75,
        keep_foreground: bool = False,
    ) -> None:
        """Uniformize background color.

        Background pixels close to the target color are set exactly to it;
        distant pixels are blended toward it.

        Args:
            input_path:  Image file or directory (with --recursive).
            output_path: Output file or directory. Auto-generated if omitted.
            recursive:   Process all images in directory tree.
            transform:   Expand foreground (+N) or background (-N) by N pixels.
            blur:        Gaussian blur radius to apply to mask.
            color:       Target color: 'white', 'black', '#RRGGBB', or None (auto-detect mean).
            strength:    Percentile threshold (0-100) for exact replacement vs blending.
            keep_foreground: Preserve original foreground by compositing it on top after uniformization.
        """
        self._process("unibg", input_path, output_path, recursive, blur, transform, color=color, strength=strength, keep_foreground=keep_foreground)

    def white(self, input_path: str, output_path: str | None = None, recursive: bool = False) -> None:
        """Shortcut: uniformize background to white with aggressive settings.

        Equivalent to: unibg --color white --strength 100 --blur 30 --transform -20 --keep_foreground
        """
        self.unibg(input_path, output_path, recursive, transform=-20, blur=30, color="white", strength=100, keep_foreground=True)

    def black(self, input_path: str, output_path: str | None = None, recursive: bool = False) -> None:
        """Shortcut: uniformize background to black with aggressive settings.

        Equivalent to: unibg --color black --strength 100 --blur 30 --transform -20 --keep_foreground
        """
        self.unibg(input_path, output_path, recursive, transform=-20, blur=30, color="black", strength=100, keep_foreground=True)


if __name__ == "__main__":
    fire.Fire(ImageBgTool)
