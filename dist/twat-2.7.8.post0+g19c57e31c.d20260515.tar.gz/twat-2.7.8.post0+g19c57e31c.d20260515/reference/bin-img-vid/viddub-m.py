#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "moviepy"]
# ///
# this_file: viddub-m.py

"""
Merge video and audio streams using MoviePy.

Combines video track from one file with audio track from another using
MoviePy's VideoFileClip and AudioFileClip. Re-encodes both streams,
which is slower but provides more flexibility for additional processing.

Examples:
    # Merge video.mp4 video with audio.mp3 (output: audio.mp4)
    viddub-m.py video.mp4 audio.mp3

    # Merge with custom output path
    viddub-m.py video.mp4 narration.wav --output-path final.mp4

    # Replace original audio
    viddub-m.py original.mp4 new_audio.mp3 --output-path dubbed.mp4

Comparison with other viddub scripts:
    - viddub-av.py: PyAV stream copy (fastest, no re-encoding)
    - viddub-ffm.py: FFmpeg, re-encodes audio only
    - viddub-m.py: MoviePy, re-encodes both (slowest but most flexible)

Use MoviePy version when you need additional video/audio processing.
"""

from pathlib import Path

import fire
from moviepy.editor import AudioFileClip, VideoFileClip


def merge_video_audio(video_path: str, audio_path: str, output_path: str = None):
    video_path = Path(video_path)
    audio_path = Path(audio_path)

    if not output_path:
        output_path = audio_path.with_name(f"{audio_path.stem}.{video_path.suffix}")
    else:
        output_path = Path(output_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    video = VideoFileClip(str(video_path))
    audio = AudioFileClip(str(audio_path))

    final_clip = video.set_audio(audio)
    final_clip.write_videofile(str(output_path))

    print(f"Output saved as: {output_path}")


if __name__ == "__main__":
    fire.Fire(merge_video_audio)
