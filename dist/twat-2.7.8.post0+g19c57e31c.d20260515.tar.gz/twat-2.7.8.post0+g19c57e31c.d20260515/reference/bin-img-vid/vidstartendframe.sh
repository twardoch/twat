#!/usr/bin/env bash
# this_file: vidstartendframe.sh
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <video_path>"
    exit 1
fi

video_path=$1
basename="${video_path##*/}"
basename="${basename%.*}"

# Extract the first frame
ffmpeg -i "$video_path" -vf "select=eq(n\,0)" -vsync vfr "${basename}-0.png"

# Extract the last frame
ffmpeg -sseof -1 -i "$video_path" -update 1 -q:v 1 "${basename}-n.png"
