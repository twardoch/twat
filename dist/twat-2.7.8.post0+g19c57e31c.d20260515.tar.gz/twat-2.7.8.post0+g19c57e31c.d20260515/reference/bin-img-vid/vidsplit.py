#!/usr/bin/env -S uv run -s
# /// script
# dependencies = ["fire", "loguru", "rich"]
# ///
# this_file: vidsplit.py

"""
Split a video into frame-count parts, fixed-second chunks, or fixed-frame chunks.

Exactly one split mode is allowed:
- `--parts N` splits into `N` parts equal by frame count
- `--seconds M` splits into chunks where all but the last are exactly `M` seconds
- `--frames O` splits into chunks where all but the last are exactly `O` frames

Audio is processed alongside video for each segment.

Examples:
    vidsplit.py --input_video clip.mp4 --parts 3
    vidsplit.py --input_video clip.mp4 --seconds 1.5
    vidsplit.py --input_video clip.mp4 --frames 240 --output_dir ./clip-240f
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Literal

import fire
from loguru import logger
from rich.console import Console

console = Console()

logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
)

SplitMode = Literal["parts", "seconds", "frames"]


@dataclass(frozen=True)
class MediaInfo:
    duration: Fraction
    fps: Fraction | None
    total_frames: int | None
    has_audio: bool


@dataclass(frozen=True)
class SegmentSpec:
    index: int
    total: int
    start_time: Fraction
    end_time: Fraction
    start_frame: int | None = None
    end_frame: int | None = None

    @property
    def duration(self) -> Fraction:
        return self.end_time - self.start_time


def check_ffmpeg_tools() -> None:
    missing = [tool for tool in ("ffmpeg", "ffprobe") if shutil.which(tool) is None]
    if missing:
        names = ", ".join(missing)
        raise RuntimeError(
            f"Missing required tool(s): {names}. Install FFmpeg first, for example with `brew install ffmpeg`."
        )


def validate_input_path(input_path: Path) -> None:
    if not input_path.exists():
        raise FileNotFoundError(f"Input video not found: {input_path}")
    if not input_path.is_file():
        raise ValueError(f"Input path is not a file: {input_path}")


def validate_positive_int(value: int | None, label: str) -> int | None:
    if value is None:
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be a positive integer") from exc
    if parsed <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return parsed


def validate_positive_seconds(
    value: float | int | str | None,
) -> tuple[Fraction | None, str | None]:
    if value is None:
        return None, None

    text = str(value).strip()
    if not text:
        raise ValueError("seconds must be a positive number")

    try:
        parsed_float = float(text)
    except (TypeError, ValueError) as exc:
        raise ValueError("seconds must be a positive number") from exc

    if parsed_float <= 0:
        raise ValueError("seconds must be a positive number")

    normalized_text = format(parsed_float, ".15g")
    fraction = Fraction(normalized_text)
    if fraction <= 0:
        raise ValueError("seconds must be a positive number")
    return fraction, normalized_text


@dataclass(frozen=True)
class SplitRequest:
    mode: SplitMode
    value: int | Fraction
    label: str


def resolve_split_request(
    parts: int | None,
    seconds: float | int | str | None,
    frames: int | None,
) -> SplitRequest:
    parts_value = validate_positive_int(parts, "parts")
    seconds_value, seconds_label = validate_positive_seconds(seconds)
    frames_value = validate_positive_int(frames, "frames")

    active = [
        SplitRequest(mode="parts", value=parts_value, label=str(parts_value))
        for _ in [0]
        if parts_value is not None
    ]
    if seconds_value is not None and seconds_label is not None:
        active.append(
            SplitRequest(mode="seconds", value=seconds_value, label=seconds_label)
        )
    if frames_value is not None:
        active.append(
            SplitRequest(mode="frames", value=frames_value, label=str(frames_value))
        )

    if len(active) != 1:
        raise ValueError(
            "Exactly one of --parts, --seconds, or --frames must be provided"
        )
    return active[0]


def parse_fraction(text: str, label: str) -> Fraction:
    stripped = text.strip()
    if not stripped or stripped.upper() == "N/A":
        raise ValueError(f"Missing {label}")
    try:
        value = Fraction(stripped)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"Invalid {label}: {text}") from exc
    if value <= 0:
        raise ValueError(f"Invalid {label}: {text}")
    return value


def probe_json(command: list[str], error_label: str) -> dict:
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() or str(exc)
        raise RuntimeError(f"{error_label}: {stderr}") from exc
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{error_label}: invalid ffprobe JSON output") from exc


def count_frames_if_needed(input_path: Path) -> int:
    command = [
        "ffprobe",
        "-v",
        "error",
        "-count_frames",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=nb_read_frames",
        "-of",
        "json",
        str(input_path),
    ]
    payload = probe_json(command, "Failed to count input frames")
    streams = payload.get("streams") or []
    if not streams:
        raise ValueError(f"No video stream found in input file: {input_path}")
    frame_text = str(streams[0].get("nb_read_frames", "")).strip()
    if not frame_text or frame_text.upper() == "N/A":
        raise ValueError(f"Unable to determine frame count for {input_path}")
    frame_count = int(frame_text)
    if frame_count <= 0:
        raise ValueError(f"Unable to determine frame count for {input_path}")
    return frame_count


def probe_media_info(input_path: Path, mode: SplitMode) -> MediaInfo:
    command = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration:stream=codec_type,avg_frame_rate,r_frame_rate,nb_frames",
        "-of",
        "json",
        str(input_path),
    ]
    payload = probe_json(command, "Failed to probe input media")
    streams = payload.get("streams") or []
    video_stream = next(
        (stream for stream in streams if stream.get("codec_type") == "video"),
        None,
    )
    if video_stream is None:
        raise ValueError(f"No video stream found in input file: {input_path}")

    duration_text = str((payload.get("format") or {}).get("duration", "")).strip()
    duration = parse_fraction(duration_text, "duration")

    has_audio = any(stream.get("codec_type") == "audio" for stream in streams)
    fps: Fraction | None = None
    total_frames: int | None = None

    if mode in {"parts", "frames"}:
        fps_text = str(video_stream.get("avg_frame_rate", "")).strip()
        if not fps_text or fps_text in {"0/0", "N/A"}:
            fps_text = str(video_stream.get("r_frame_rate", "")).strip()
        fps = parse_fraction(fps_text, "frame rate")

        frames_text = str(video_stream.get("nb_frames", "")).strip()
        if frames_text and frames_text.upper() != "N/A":
            total_frames = int(frames_text)
        else:
            total_frames = count_frames_if_needed(input_path)

        if total_frames <= 0:
            raise ValueError(f"Unable to determine frame count for {input_path}")

    return MediaInfo(
        duration=duration,
        fps=fps,
        total_frames=total_frames,
        has_audio=has_audio,
    )


def build_output_dir(
    input_path: Path,
    mode: SplitMode,
    label: str,
    output_dir: str | None,
) -> Path:
    if output_dir is not None:
        target = Path(output_dir).expanduser()
    else:
        suffix = {"parts": "p", "seconds": "s", "frames": "f"}[mode]
        target = input_path.with_name(f"{input_path.stem}-{label}{suffix}")
    if target.exists() and not target.is_dir():
        raise ValueError(f"Output directory path is not a directory: {target}")
    return target


def build_segment_filename(stem: str, index: int, total: int, suffix: str) -> str:
    pad = max(2, len(str(total)))
    return f"{stem}-{index:0{pad}d}-of-{total:0{pad}d}{suffix}"


def build_frame_segment(
    *,
    index: int,
    total: int,
    start_frame: int,
    end_frame: int,
    fps: Fraction,
) -> SegmentSpec:
    start_time = Fraction(start_frame, 1) / fps
    end_time = Fraction(end_frame, 1) / fps
    return SegmentSpec(
        index=index,
        total=total,
        start_time=start_time,
        end_time=end_time,
        start_frame=start_frame,
        end_frame=end_frame,
    )


def compute_segments(info: MediaInfo, request: SplitRequest) -> list[SegmentSpec]:
    segments: list[SegmentSpec] = []

    if request.mode == "parts":
        if info.fps is None or info.total_frames is None:
            raise ValueError("Parts mode requires frame rate and frame count metadata")

        part_count = int(request.value)
        if part_count > info.total_frames:
            raise ValueError("parts must not exceed the input video frame count")

        if info.total_frames % part_count != 0:
            raise ValueError(
                "parts must divide the input video frame count exactly for equal frame-count splits"
            )

        segment_size = info.total_frames // part_count
        start_frame = 0
        for offset in range(part_count):
            end_frame = start_frame + segment_size
            segments.append(
                build_frame_segment(
                    index=offset + 1,
                    total=part_count,
                    start_frame=start_frame,
                    end_frame=end_frame,
                    fps=info.fps,
                )
            )
            start_frame = end_frame
    elif request.mode == "seconds":
        chunk = Fraction(request.value)
        total = int((info.duration + chunk - Fraction(1, 10**9)) / chunk)
        if total <= 0:
            raise ValueError("seconds must produce at least one segment")
        for offset in range(total):
            start = chunk * offset
            end = min(info.duration, chunk * (offset + 1))
            segments.append(
                SegmentSpec(
                    index=offset + 1, total=total, start_time=start, end_time=end
                )
            )
    else:
        if info.fps is None or info.total_frames is None:
            raise ValueError("Frame mode requires frame rate and frame count metadata")
        chunk_frames = int(request.value)
        total = (info.total_frames + chunk_frames - 1) // chunk_frames
        for offset, start_frame in enumerate(range(0, info.total_frames, chunk_frames)):
            end_frame = min(info.total_frames, start_frame + chunk_frames)
            segments.append(
                build_frame_segment(
                    index=offset + 1,
                    total=total,
                    start_frame=start_frame,
                    end_frame=end_frame,
                    fps=info.fps,
                )
            )

    for segment in segments:
        if segment.duration <= 0:
            raise ValueError(
                "Computed an empty segment; check split arguments and media metadata"
            )
    return segments


def format_ffmpeg_time(value: Fraction) -> str:
    return f"{float(value):.6f}"


def build_filter_complex(segment: SegmentSpec, has_audio: bool) -> str:
    if segment.start_frame is not None and segment.end_frame is not None:
        video_trim = (
            f"[0:v:0]trim=start_frame={segment.start_frame}:end_frame={segment.end_frame},"
            f"setpts=PTS-STARTPTS[v]"
        )
    else:
        video_trim = (
            f"[0:v:0]trim=start={format_ffmpeg_time(segment.start_time)}:"
            f"end={format_ffmpeg_time(segment.end_time)},setpts=PTS-STARTPTS[v]"
        )

    if not has_audio:
        return video_trim

    audio_trim = (
        f"[0:a:0]atrim=start={format_ffmpeg_time(segment.start_time)}:"
        f"end={format_ffmpeg_time(segment.end_time)},asetpts=PTS-STARTPTS[a]"
    )
    return f"{video_trim};{audio_trim}"


def run_split_segment(
    input_path: Path,
    output_path: Path,
    segment: SegmentSpec,
    has_audio: bool,
    verbose: bool,
) -> None:
    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(input_path),
        "-filter_complex",
        build_filter_complex(segment, has_audio),
        "-map",
        "[v]",
        "-c:v",
        "libx264",
        "-preset",
        "medium",
        "-crf",
        "18",
        "-pix_fmt",
        "yuv420p",
    ]
    if has_audio:
        command.extend(["-map", "[a]", "-c:a", "aac", "-b:a", "192k"])
    else:
        command.append("-an")
    command.append(str(output_path))

    if verbose:
        logger.debug(f"Running command: {' '.join(command)}")

    try:
        subprocess.run(command, check=True, capture_output=not verbose, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() if exc.stderr else str(exc)
        raise RuntimeError(f"FFmpeg failed for {output_path.name}: {stderr}") from exc


def vidsplit(
    input_video: str,
    parts: int | None = None,
    seconds: float | int | str | None = None,
    frames: int | None = None,
    output_dir: str | None = None,
    verbose: bool = False,
) -> list[str]:
    if verbose:
        logger.remove()
        logger.add(
            sys.stderr,
            format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
            level="DEBUG",
        )

    check_ffmpeg_tools()
    input_path = Path(input_video).expanduser()
    validate_input_path(input_path)

    request = resolve_split_request(parts=parts, seconds=seconds, frames=frames)
    info = probe_media_info(input_path, request.mode)
    segments = compute_segments(info, request)

    output_path = build_output_dir(input_path, request.mode, request.label, output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Input: {input_path}")
    logger.info(f"Mode: {request.mode}={request.label}")
    logger.info(f"Duration: {float(info.duration):.3f}s")
    if info.fps is not None and info.total_frames is not None:
        logger.info(f"Frames: {info.total_frames} at {float(info.fps):.6f} fps")
    logger.info(f"Output directory: {output_path}")

    outputs: list[str] = []
    with console.status("Splitting video..."):
        for segment in segments:
            filename = build_segment_filename(
                input_path.stem,
                segment.index,
                segment.total,
                input_path.suffix,
            )
            segment_output = output_path / filename
            run_split_segment(
                input_path=input_path,
                output_path=segment_output,
                segment=segment,
                has_audio=info.has_audio,
                verbose=verbose,
            )
            outputs.append(str(segment_output))

    logger.success(f"Created {len(outputs)} segment(s) in {output_path}")
    return outputs


def main() -> int:
    try:
        fire.Fire(vidsplit)
    except Exception as exc:
        logger.error(f"Error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
