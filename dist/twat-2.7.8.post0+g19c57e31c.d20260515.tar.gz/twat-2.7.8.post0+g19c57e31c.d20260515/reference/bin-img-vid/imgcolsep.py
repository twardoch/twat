#!/usr/bin/env -S uv run
# /// script
# dependencies = ["Pillow", "numpy", "scikit-learn", "fire", "rich"]
# ///
# this_file: imgcolsep.py
"""
imgcolsep.py — Image Color Separation CLI Tool

Separates images into channel layers by RGB, CMYK, dominant colors, or
specified color targets. Outputs per-channel image files for compositing,
analysis, or artistic use.

Usage:
    imgcolsep.py rgb --input photo.png
    imgcolsep.py rgb --input photo.png --gray
    imgcolsep.py cmyk --input photo.jpg --alpha
    imgcolsep.py cmyk --input photo.jpg --alphaneg --gray
    imgcolsep.py dom --input photo.png --num 5
    imgcolsep.py dom --input photo.png --alpha --gray
    imgcolsep.py sep --input photo.png --spec "#ff0000,#00ff00,#0000ff"
    imgcolsep.py sep --input photo.png --spec "#ff0000" --alphaneg

New flags available on all commands:
    --gray      Force each separation into grayscale (modulation * 255 for all channels).
    --alpha     Output RGBA: flat separation color as RGB, modulation as alpha
                (darkest pixel = transparent A=0, lightest = opaque A=255).
    --alphaneg  Like --alpha but reversed: darkest = opaque A=255, lightest = transparent A=0.

--alpha and --alphaneg are mutually exclusive. --gray may combine with either or stand alone.
"""

import sys
from pathlib import Path

import fire
import numpy as np
from PIL import Image
from rich.console import Console
from rich.panel import Panel

console = Console()


# Maximum possible Euclidean distance in RGB space: sqrt(3 * 255^2)
MAX_RGB_DISTANCE = float(np.sqrt(3 * 255 ** 2))  # ≈ 441.67


def _load_image(input_path: str) -> tuple[Image.Image, Path, str]:
    """Load image from disk, returning PIL Image, resolved Path, and format."""
    p = Path(input_path).resolve()
    if not p.exists():
        console.print(f"[bold red]Error:[/bold red] File not found: {p}")
        sys.exit(1)
    raw = Image.open(p)
    original_format = raw.format or "PNG"
    img = raw.convert("RGB")
    return img, p, original_format


def _resolve_output_folder(output: str | None, input_path: Path) -> Path:
    """Resolve output folder, creating it if necessary."""
    if output is None:
        folder = input_path.parent
    else:
        folder = Path(output).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _output_path(
    folder: Path,
    stem: str,
    suffix: str,
    ext: str,
    alpha: bool,
    original_format: str,
) -> tuple[Path, str]:
    """
    Build output file path.

    If alpha is requested and the original format doesn't support it (e.g. JPEG),
    falls back to PNG and prints a warning.
    """
    fmt = original_format.upper()
    alpha_formats = {"PNG", "WEBP", "TIFF", "GIF"}

    if alpha and fmt not in alpha_formats:
        console.print(
            f"[yellow]Warning:[/yellow] Format '{fmt}' does not support alpha. "
            "Saving as PNG instead."
        )
        ext = ".png"
        fmt = "PNG"

    return folder / f"{stem}{suffix}{ext}", fmt


def _save(img_array: np.ndarray, path: Path, fmt: str) -> None:
    """Save a numpy array as an image."""
    mode = "RGBA" if img_array.shape[2] == 4 else "RGB"
    pil_img = Image.fromarray(img_array.astype(np.uint8), mode=mode)
    pil_img.save(path, format=fmt)
    console.print(f"  [green]Saved:[/green] {path.name}")


def _build_output(
    H: int,
    W: int,
    modulation: np.ndarray,
    color: tuple[int, int, int],
    gray: bool,
    alpha: bool,
    alphaneg: bool,
) -> np.ndarray:
    """
    Build output image array from modulation map and separation color.

    Args:
        H: Image height in pixels.
        W: Image width in pixels.
        modulation: (H, W) float array in [0.0, 1.0] — per-pixel intensity.
        color: Separation color as (R, G, B) uint8 tuple.
        gray: If True, force grayscale output (all three RGB channels equal).
        alpha: If True, push modulation into alpha; RGB = flat color (or black if gray).
        alphaneg: If True, like alpha but alpha channel is inverted (1 - modulation).

    Returns:
        uint8 ndarray of shape (H, W, 4) if alpha/alphaneg, else (H, W, 3).
    """
    uses_alpha = alpha or alphaneg

    if uses_alpha:
        out = np.zeros((H, W, 4), dtype=np.uint8)
        if not gray:
            out[:, :, 0] = color[0]
            out[:, :, 1] = color[1]
            out[:, :, 2] = color[2]
        # gray=True leaves RGB as (0,0,0) — already zeroed

        alpha_val = (modulation * 255).clip(0, 255).astype(np.uint8)
        if alphaneg:
            alpha_val = 255 - alpha_val
        out[:, :, 3] = alpha_val
    else:
        out = np.zeros((H, W, 3), dtype=np.uint8)
        if gray:
            g = (modulation * 255).clip(0, 255).astype(np.uint8)
            out[:, :, 0] = g
            out[:, :, 1] = g
            out[:, :, 2] = g
        else:
            for ch_i in range(3):
                out[:, :, ch_i] = (modulation * color[ch_i]).clip(0, 255).astype(np.uint8)

    return out


def _check_alpha_flags(alpha: bool, alphaneg: bool) -> None:
    """Exit with an error if both alpha and alphaneg are requested."""
    if alpha and alphaneg:
        console.print(
            "[bold red]Error:[/bold red] --alpha and --alphaneg are mutually exclusive. "
            "Use one or the other."
        )
        sys.exit(1)


class ImgColSep:
    """Image Color Separation — split images into per-channel layers."""

    def rgb(
        self,
        input: str,
        output: str | None = None,
        alpha: bool = False,
        alphaneg: bool = False,
        gray: bool = False,
    ) -> None:
        """
        Separate image into red, green, and blue channel images.

        Without alpha/alphaneg: each output is a full RGB image with only that
        channel populated (e.g. red: R=original_R, G=0, B=0). With --gray,
        outputs grayscale: all three channels = channel intensity.

        With --alpha: RGBA where RGB = flat channel color and A = channel intensity
        (transparent where dark, opaque where bright). With --gray, RGB = black.

        With --alphaneg: like --alpha but alpha is inverted (opaque where dark).

        Args:
            input: Path to input image.
            output: Output folder (default: same folder as input).
            alpha: Output RGBA with channel intensity as alpha.
            alphaneg: Output RGBA with inverted channel intensity as alpha.
            gray: Force grayscale output (modulation * 255 for all RGB channels).
        """
        _check_alpha_flags(alpha, alphaneg)

        img, in_path, fmt = _load_image(input)
        folder = _resolve_output_folder(output, in_path)
        stem = in_path.stem
        ext = in_path.suffix

        arr = np.array(img)  # shape (H, W, 3), dtype uint8
        H, W, _ = arr.shape

        uses_alpha = alpha or alphaneg
        console.print(
            Panel(
                f"RGB separation — [cyan]{in_path.name}[/cyan] "
                f"({W}×{H}), alpha={alpha}, alphaneg={alphaneg}, gray={gray}",
                style="bold blue",
            )
        )

        channels = [
            ("_red",   0, (255, 0,   0)),
            ("_green", 1, (0,   255, 0)),
            ("_blue",  2, (0,   0,   255)),
        ]

        for suffix, ch_idx, color in channels:
            ch = arr[:, :, ch_idx]  # (H, W) uint8
            modulation = ch.astype(np.float32) / 255.0  # (H, W) in [0,1]

            out = _build_output(H, W, modulation, color, gray, alpha, alphaneg)

            path, save_fmt = _output_path(folder, stem, suffix, ext, uses_alpha, fmt)
            _save(out, path, save_fmt)

    def cmyk(
        self,
        input: str,
        output: str | None = None,
        alpha: bool = False,
        alphaneg: bool = False,
        gray: bool = False,
    ) -> None:
        """
        Convert image to CMYK and separate into four ink channel images.

        Conversion formula (from RGB normalised 0..1):
            C = 1 - R,  M = 1 - G,  Y = 1 - B
            K = min(C, M, Y)
            C = (C - K) / (1 - K),  M = (M - K) / (1 - K),  Y = (Y - K) / (1 - K)
            (pure-black pixels where K=1 are handled explicitly)

        Default (no flags): tinted white-to-ink blend for C/M/Y, gray scale for K.
        With --gray (no alpha): grayscale where intensity = ink density * 255.
        With --alpha: RGBA — flat ink color as RGB, density as alpha.
        With --alphaneg: like --alpha but alpha inverted.
        With --gray + alpha/alphaneg: RGB = black, density as alpha.

        Args:
            input: Path to input image.
            output: Output folder (default: same folder as input).
            alpha: Output RGBA with ink density as alpha.
            alphaneg: Output RGBA with inverted ink density as alpha.
            gray: Force grayscale output when not using alpha modes.
        """
        _check_alpha_flags(alpha, alphaneg)

        img, in_path, fmt = _load_image(input)
        folder = _resolve_output_folder(output, in_path)
        stem = in_path.stem
        ext = in_path.suffix

        arr = np.array(img, dtype=np.float32) / 255.0  # (H, W, 3) in [0,1]
        H, W, _ = arr.shape

        uses_alpha = alpha or alphaneg
        console.print(
            Panel(
                f"CMYK separation — [cyan]{in_path.name}[/cyan] "
                f"({W}×{H}), alpha={alpha}, alphaneg={alphaneg}, gray={gray}",
                style="bold blue",
            )
        )

        R, G, B = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]

        # CMY from RGB
        C_raw = 1.0 - R
        M_raw = 1.0 - G
        Y_raw = 1.0 - B

        K = np.minimum(np.minimum(C_raw, M_raw), Y_raw)  # (H, W)

        denom = 1.0 - K  # will be 0 where K=1 (pure black)
        safe_denom = np.where(denom == 0, 1.0, denom)  # avoid div-by-zero

        C = np.where(denom == 0, 0.0, (C_raw - K) / safe_denom)
        M = np.where(denom == 0, 0.0, (M_raw - K) / safe_denom)
        Y = np.where(denom == 0, 0.0, (Y_raw - K) / safe_denom)
        # K stays as-is

        # Ink definitions: (suffix, density_map, ink_rgb_0_255)
        inks = [
            ("_cyan",    C, (0,   255, 255)),
            ("_magenta", M, (255, 0,   255)),
            ("_yellow",  Y, (255, 255, 0)),
            ("_key",     K, (0,   0,   0)),
        ]

        for suffix, density, ink_rgb in inks:
            d = density  # (H, W) in [0,1]

            if not gray and not uses_alpha:
                # Default tinted rendering — keep original behavior
                out = np.zeros((H, W, 3), dtype=np.uint8)
                if suffix == "_key":
                    # Black ink: grey = (1-K)*255 → lighter = less ink
                    grey = ((1.0 - d) * 255).clip(0, 255).astype(np.uint8)
                    out[:, :, 0] = grey
                    out[:, :, 1] = grey
                    out[:, :, 2] = grey
                else:
                    # Coloured ink: white background tinted by ink density
                    # white * (1-d) + ink_colour * d
                    for ch_i, ink_val in enumerate(ink_rgb):
                        out[:, :, ch_i] = (
                            (255 * (1.0 - d) + ink_val * d)
                            .clip(0, 255)
                            .astype(np.uint8)
                        )
            else:
                out = _build_output(H, W, d, ink_rgb, gray, alpha, alphaneg)

            path, save_fmt = _output_path(folder, stem, suffix, ext, uses_alpha, fmt)
            _save(out, path, save_fmt)

    def dom(
        self,
        input: str,
        num: int = 5,
        output: str | None = None,
        alpha: bool = False,
        alphaneg: bool = False,
        gray: bool = False,
    ) -> None:
        """
        Find NUM dominant colours via KMeans and create one channel per cluster.

        Each output image shows how strongly each pixel belongs to that
        dominant colour (soft Gaussian membership over pixel-to-centroid distance).

        Default: RGB image with dominant colour weighted by closeness.
        With --gray: grayscale where intensity = closeness * 255.
        With --alpha: RGBA — flat dominant color, closeness as alpha.
        With --alphaneg: like --alpha but alpha inverted.
        With --gray + alpha/alphaneg: RGB = black, closeness as alpha.

        Args:
            input: Path to input image.
            num: Number of dominant colours / clusters (default 5).
            output: Output folder (default: same folder as input).
            alpha: Output RGBA with Gaussian closeness as alpha.
            alphaneg: Output RGBA with inverted closeness as alpha.
            gray: Force grayscale output.
        """
        _check_alpha_flags(alpha, alphaneg)

        from sklearn.cluster import KMeans  # local import — heavy dependency

        img, in_path, fmt = _load_image(input)
        folder = _resolve_output_folder(output, in_path)
        stem = in_path.stem
        ext = in_path.suffix

        arr = np.array(img, dtype=np.float32)  # (H, W, 3)
        H, W, _ = arr.shape

        uses_alpha = alpha or alphaneg
        console.print(
            Panel(
                f"Dominant colour separation — [cyan]{in_path.name}[/cyan] "
                f"({W}×{H}), num={num}, alpha={alpha}, alphaneg={alphaneg}, gray={gray}",
                style="bold blue",
            )
        )

        pixels = arr.reshape(-1, 3)  # (N, 3)

        n_pixels = H * W
        if n_pixels < num:
            console.print(
                f"[bold red]Error:[/bold red] Image has {n_pixels} pixel(s) but "
                f"--num={num} clusters requested. Reduce --num."
            )
            sys.exit(1)

        console.print(f"  Running KMeans with {num} clusters…")
        km = KMeans(n_clusters=num, random_state=42, n_init="auto")
        labels = km.fit_predict(pixels)  # (N,)
        centers = km.cluster_centers_   # (num, 3)

        # Sort clusters by size, largest first
        cluster_sizes = np.bincount(labels, minlength=num)
        order = np.argsort(cluster_sizes)[::-1]  # descending

        # Sigma for soft assignment: ~10% of max distance
        sigma = MAX_RGB_DISTANCE * 0.1

        for rank, cluster_idx in enumerate(order, start=1):
            center = centers[cluster_idx]  # (3,) float
            suffix = f"_dom{rank}"

            # Euclidean distance from every pixel to this centre
            diff = pixels - center  # (N, 3)
            dist = np.linalg.norm(diff, axis=1)  # (N,)

            # Soft membership: 1 when dist=0, decays with distance
            closeness = np.exp(-(dist ** 2) / (2 * sigma ** 2))  # (N,) in [0,1]
            closeness_img = closeness.reshape(H, W)  # (H, W)

            c = center.clip(0, 255).astype(np.uint8)
            ink_rgb = (int(c[0]), int(c[1]), int(c[2]))

            out = _build_output(H, W, closeness_img, ink_rgb, gray, alpha, alphaneg)

            path, save_fmt = _output_path(folder, stem, suffix, ext, uses_alpha, fmt)
            _save(out, path, save_fmt)

    def sep(
        self,
        input: str,
        spec: str = "",
        output: str | None = None,
        alpha: bool = False,
        alphaneg: bool = False,
        gray: bool = False,
    ) -> None:
        """
        Separate image by specified target colours.

        SPEC is a comma-separated list of hex colours, e.g. '#ff0000,#00ff00'.

        For each colour, an output image shows how close each pixel is to that
        target colour (closeness = 1 - distance / max_distance).

        Default: RGB image with target colour weighted by closeness.
        With --gray: grayscale where intensity = closeness * 255.
        With --alpha: RGBA — flat target color, closeness as alpha.
        With --alphaneg: like --alpha but alpha inverted.
        With --gray + alpha/alphaneg: RGB = black, closeness as alpha.

        Args:
            input: Path to input image.
            spec: Comma-separated hex colours, e.g. '#ff0000,#00ff00,#0000ff'.
            output: Output folder (default: same folder as input).
            alpha: Output RGBA with closeness as alpha.
            alphaneg: Output RGBA with inverted closeness as alpha.
            gray: Force grayscale output.
        """
        _check_alpha_flags(alpha, alphaneg)

        if not spec:
            console.print(
                "[bold red]Error:[/bold red] --spec is required. "
                "Provide comma-separated hex colours, e.g. '#ff0000,#00ff00'."
            )
            sys.exit(1)

        # Parse colour spec
        raw_colors = [c.strip() for c in spec.split(",") if c.strip()]
        if not raw_colors:
            console.print("[bold red]Error:[/bold red] --spec contains no valid colours.")
            sys.exit(1)
        parsed = []
        for raw in raw_colors:
            hex_val = raw.lstrip("#").lower()
            if len(hex_val) != 6 or not all(c in "0123456789abcdef" for c in hex_val):
                console.print(
                    f"[bold red]Error:[/bold red] Invalid hex colour: '{raw}'. "
                    "Expected format: #rrggbb"
                )
                sys.exit(1)
            r = int(hex_val[0:2], 16)
            g = int(hex_val[2:4], 16)
            b = int(hex_val[4:6], 16)
            parsed.append((hex_val, np.array([r, g, b], dtype=np.float32)))

        img, in_path, fmt = _load_image(input)
        folder = _resolve_output_folder(output, in_path)
        stem = in_path.stem
        ext = in_path.suffix

        arr = np.array(img, dtype=np.float32)  # (H, W, 3)
        H, W, _ = arr.shape
        pixels = arr.reshape(-1, 3)  # (N, 3)

        uses_alpha = alpha or alphaneg
        console.print(
            Panel(
                f"Colour spec separation — [cyan]{in_path.name}[/cyan] "
                f"({W}×{H}), {len(parsed)} colour(s), "
                f"alpha={alpha}, alphaneg={alphaneg}, gray={gray}",
                style="bold blue",
            )
        )

        for hex_val, target in parsed:
            suffix = f"_sep_{hex_val}"
            t = target.astype(np.uint8)
            ink_rgb = (int(t[0]), int(t[1]), int(t[2]))

            diff = pixels - target  # (N, 3)
            dist = np.linalg.norm(diff, axis=1)  # (N,)

            closeness = np.clip(1.0 - dist / MAX_RGB_DISTANCE, 0.0, 1.0)  # (N,)
            closeness_img = closeness.reshape(H, W)  # (H, W)

            out = _build_output(H, W, closeness_img, ink_rgb, gray, alpha, alphaneg)

            path, save_fmt = _output_path(folder, stem, suffix, ext, uses_alpha, fmt)
            _save(out, path, save_fmt)


if __name__ == "__main__":
    fire.Fire(ImgColSep)
