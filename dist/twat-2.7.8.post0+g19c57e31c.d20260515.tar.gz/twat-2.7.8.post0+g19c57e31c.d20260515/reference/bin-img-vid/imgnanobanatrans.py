#!/usr/bin/env -S uv run -s
# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "fire",
#     "google-genai",
# ]
# ///

import mimetypes
import os
import sys
import fire
from google import genai
from google.genai import types

def save_binary_file(file_name: str, data: bytes):
    with open(file_name, "wb") as f:
        f.write(data)
    print(f"File saved to: {file_name}")

def read_image_as_part(file_path: str):
    """Reads a local image and returns a google.genai.types.Part object."""
    if not os.path.exists(file_path):
        print(f"Error: Image file not found: {file_path}")
        sys.exit(1)
        
    mime_type, _ = mimetypes.guess_type(file_path)
    if not mime_type or not mime_type.startswith("image/"):
        mime_type = "image/jpeg"  # Default fallback
        
    with open(file_path, "rb") as f:
        data = f.read()
        
    return types.Part.from_bytes(
        mime_type=mime_type,
        data=data,
    )

def transform_image(
    input_image: str,
    reference_image: str,
    output_image: str | None = None,
    model: str = "flash31",
    thinking: str = "MINIMAL",
    quality: str = "4K",
    aspect: str = "9:16",
    prompt: str | None = None,
):
    """
    Transform an input image to match the lighting/style of a reference image using Gemini image generation.

    Args:
        input_image: Path to the input image to be transformed.
        reference_image: Path to the reference image providing the target lighting/style.
        output_image: Optional path to save the generated image. Auto-generated if not provided.
        model: Model short name or full model ID. Short names: flash25, pro3, flash31 (default).
        thinking: Thinking level for the model. Valid values: NONE, MINIMAL, LOW, MEDIUM, HIGH.
        quality: Image output size. Valid values: 1K, 2K, 4K (default).
        aspect: Aspect ratio for the output image. e.g. 9:16 (default), 16:9, 1:1, 3:4, 4:3.
        prompt: Optional custom prompt. If not provided, an optimized default prompt is used.
    """
    api_key = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY"))
    if not api_key:
        print("Error: GEMINI_API_KEY environment variable is not set.")
        sys.exit(1)

    client = genai.Client(api_key=api_key)

    model_map = {
        "flash25": "gemini-2.5-flash-preview-image-generation",
        "pro3": "gemini-3-pro-image-preview",
        "flash31": "gemini-3.1-flash-image-preview",
    }
    model_id = model_map.get(model, model)

    # Default optimized prompt based on best practices for identity preservation and lighting transfer
    if not prompt:
        prompt = (
            "Create a new image of the person from Image 1 (Subject). "
            "IDENTITY LOCK: Keep the Subject’s exact same identity, identical body pose, same emotional expression, identical face pose, exact same facial features, identical body position, and exact same hairstyle from the Subject image. Zoom out to make sure the Subject’s hands are fully visible in frame. But change the clothing to be smooth, wrinkle-free, aesthetically pleasing, and a nice light gray color."
            "LIGHTING TRANSFER: Apply ONLY the lighting direction, color temperature, and ambient mood from Image 2 (Style Reference), so that the two images look like they were taken during the same photoshoot. "
            "Do NOT reproduce the Style Reference image. Do NOT change the person. "
            "Keep the background purely white."
        )

    print(f"Loading input image: {input_image}")
    input_part = read_image_as_part(input_image)

    print(f"Loading reference image: {reference_image}")
    reference_part = read_image_as_part(reference_image)

    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_text(text="Image 1 (Subject — Keep the Subject’s exact same identity, identical body pose, same emotional expression, identical face pose, exact same facial features, identical body position, and exact same hairstyle from the Subject image. Zoom out to make sure the Subject’s hands are fully visible in frame. But change the shirt and trousers to be smooth, wrinkle-free, aesthetically pleasing, and a nice light gray color.) :"),
                input_part,
                types.Part.from_text(text="Image 2 (Style and lighting reference — use only the lighting and ambient mood from this image, so that the two images look like they were taken during the same photoshoot):"),
                reference_part,
                types.Part.from_text(text=prompt),
            ],
        ),
    ]

    # Models that do not support thinking config
    no_thinking_models = {"gemini-3-pro-image-preview"}

    config_kwargs = dict(
        image_config=types.ImageConfig(
            aspect_ratio=aspect,
            image_size=quality.upper(),
        ),
        response_modalities=["IMAGE", "TEXT"],
    )

    if model_id not in no_thinking_models:
        config_kwargs["thinking_config"] = types.ThinkingConfig(
            thinking_level=thinking,
        )

    generate_content_config = types.GenerateContentConfig(**config_kwargs)

    print(f"Sending request to {model_id}...")
    
    file_index = 0
    generated_any_image = False
    
    try:
        for chunk in client.models.generate_content_stream(
            model=model_id,
            contents=contents,
            config=generate_content_config,
        ):
            if chunk.parts is None:
                continue
                
            for part in chunk.parts:
                if part.inline_data and part.inline_data.data:
                    generated_any_image = True
                    
                    # Determine output filename
                    if output_image and file_index == 0:
                        file_name = output_image
                    else:
                        base_name = os.path.splitext(os.path.basename(input_image))[0]
                        file_extension = mimetypes.guess_extension(part.inline_data.mime_type) or ".jpg"
                        
                        if output_image:
                            # If multiple images are returned but a specific output was given, append index
                            out_base, out_ext = os.path.splitext(output_image)
                            file_name = f"{out_base}_{file_index}{out_ext}"
                        else:
                            file_name = f"{base_name}_transformed_{file_index}{file_extension}"
                            
                    file_index += 1
                    
                    data_buffer = part.inline_data.data
                    save_binary_file(file_name, data_buffer)
                elif part.text:
                    print(f"Model response: {part.text}")
                    
        if not generated_any_image:
            print("Warning: The model completed the request but did not return any images.")
            
    except Exception as e:
        print(f"Error during generation: {e}")
        sys.exit(1)

def main():
    fire.Fire(transform_image)

if __name__ == "__main__":
    main()
