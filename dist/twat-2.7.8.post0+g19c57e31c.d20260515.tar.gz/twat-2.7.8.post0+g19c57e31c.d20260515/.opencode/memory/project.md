---
description: >-
  The project block: Stores durable, high-signal information about this codebase: commands, architecture notes,
  conventions, and gotchas.
label: project
limit: 5000
read_only: false
---
twat: Python plugin ecosystem (host + 17 plugins in plugins/repos/)
Each plugin is its own git repo. Git commands must run inside plugin dirs.

STATUS: Phases 0, 1, 2, 3.1, 3.2, 3.3 COMPLETE. Phase 3.4 next.
All committed. twat_cache Phase 3.3 commit: 415d914, host: 83fe174
Test results: 82 passed, 6 failed (pre-existing), 1 error (pre-existing)

NEXT: Phase 3.4 — twat_cache CacheConfig Consolidation (spec 24)

TOOL CONSTRAINTS:
- edit tool's replace_lines/insert_between FAIL. Use write or set_line.
- Python REPL best for batch file mods.
- explore agents fail (Gemini unavailable). Use manual search.

KEY FACTS:
- Python 3.10+, ruff + mypy strict, loguru, hatch builds
- twat_coding uses Apache-2.0 (all others MIT)
- CacheConfig has extra="forbid" — no unknown fields
- twat_fs ruff: 0 errors. twat_fs/search/genai mypy: 0 errors.
- Pre-commit hooks in twat_search (isort, ruff etc.)
- 3 files in twat_llm/examples/ have syntax errors (pre-existing)

RUFF CONFIG (all plugins):
select: A,ARG,B,C,DTZ,E,EM,F,FBT,I,ICN,ISC,N,PLC,PLE,PLR,PLW,Q,RUF,S,T,TID,UP,W,YTT
Many rules ignored (see pyproject.toml per plugin)
